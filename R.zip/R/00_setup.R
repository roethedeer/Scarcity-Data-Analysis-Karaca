# =============================================================================
# Does Scarcity Impede Cognitive Function? Five Preregistered Experiments
# Analysis code (R) -- 00_setup.R
#
# Loads packages, defines paths and the helper functions shared by all scripts.
# Run every script from the project root (the folder that contains R/, python/,
# data/ and output/), e.g.  Rscript R/run_all.R
# =============================================================================

suppressPackageStartupMessages({
  library(readr)      # reading the raw CSV exports
  library(dplyr)      # data manipulation
  library(tidyr)
  library(purrr)
  library(stringr)
  library(car)        # Type III ANOVA
  library(psych)      # Cronbach's alpha
  library(metafor)    # meta-analysis (used in 03_meta_analysis.R)
  library(ggplot2)    # figures
})

options(dplyr.summarise.inform = FALSE, warn = 1)

# ---- paths ------------------------------------------------------------------
PROJECT_ROOT <- normalizePath(".", winslash = "/")
if (!dir.exists(file.path(PROJECT_ROOT, "R"))) {
  stop("Run this script from the project root (the folder containing R/ and data/).")
}
DIR_RAW       <- PROJECT_ROOT                                  # St1.csv ... St5.csv
DIR_PROCESSED <- file.path(PROJECT_ROOT, "data", "processed")
DIR_TABLES    <- file.path(PROJECT_ROOT, "output", "tables")
DIR_FIGURES   <- file.path(PROJECT_ROOT, "output", "figures")
DIR_CHECKS    <- file.path(PROJECT_ROOT, "output", "checks")
for (d in c(DIR_PROCESSED, DIR_TABLES, DIR_FIGURES, DIR_CHECKS)) dir.create(d, recursive = TRUE, showWarnings = FALSE)

# ---- study design constants -------------------------------------------------
# Every high- versus low-scarcity comparison that the paper tests
# (18 comparisons across the five studies; Tables 2 to 6).
COMPARISONS <- tribble(
  ~study, ~technique,            ~high,                      ~low,
  1,      "Lottery",             "Lottery high",             "Lottery low",
  1,      "Scale",               "Scale high",               "Scale low",
  1,      "Recall",              "Recall high",              "Recall low",
  1,      "Consequences",        "Consequences high",        "Consequences low",
  2,      "Recall",              "Recall high",              "Recall low",
  2,      "Scenario",            "Scenario high",            "Scenario low",
  2,      "Generic pictures",    "Generic pictures high",    "Pictures low",
  2,      "COVID-19 pictures",   "COVID-19 pictures high",   "Pictures low",
  3,      "Generic pictures",    "Generic pictures high",    "Pictures low",
  3,      "COVID-19 pictures",   "COVID-19 pictures high",   "Pictures low",
  4,      "Recall",              "Recall high",              "Recall low",
  4,      "Scenario",            "Scenario high",            "Scenario low",
  4,      "Generic pictures",    "Generic pictures high",    "Pictures low",
  4,      "COVID-19 pictures",   "COVID-19 pictures high",   "Pictures low",
  5,      "Recall",              "Recall high",              "Recall low",
  5,      "Scenario",            "Scenario high",            "Scenario low",
  5,      "COVID-19 pictures",   "COVID-19 pictures high",   "COVID-19 pictures low",
  5,      "Picture imagination", "Picture imagination high", "Picture imagination low"
)

# Outcome measures: column in the processed data, label used in the paper,
# and the predicted direction of the high - low difference.
MEASURES <- tribble(
  ~measure,      ~label,                  ~direction,
  "concerns",    "Scarcity concerns",     "greater",   # high scarcity -> more concerns
  "crs",         "Cognitive reflection",  "less",      # high scarcity -> lower scores
  "fis",         "Fluid intelligence",    "less",
  "reflection",  "Reflection score",      "less"
)

concern_label <- function(study) {
  if (study == 3) "Resource scarcity concerns" else "Financial concerns"
}

# ---- helper functions -------------------------------------------------------

# Cohen's d: mean(x) - mean(y) divided by the pooled SD (Student's t version).
cohens_d <- function(x, y) {
  nx <- length(x); ny <- length(y)
  sp <- sqrt(((nx - 1) * var(x) + (ny - 1) * var(y)) / (nx + ny - 2))
  (mean(x) - mean(y)) / sp
}

# Hedges' g (small-sample corrected d) and its sampling variance.
hedges_g <- function(x, y) {
  nx <- length(x); ny <- length(y)
  d  <- cohens_d(x, y)
  J  <- 1 - 3 / (4 * (nx + ny) - 9)          # Hedges (1981) correction
  g  <- J * d
  vg <- (nx + ny) / (nx * ny) + g^2 / (2 * (nx + ny))
  list(g = g, vi = vg, n1 = nx, n2 = ny)
}

# One-tailed p value for a t statistic in the predicted direction.
p_one_tailed <- function(t, df, direction) {
  if (direction == "greater") pt(t, df, lower.tail = FALSE) else pt(t, df, lower.tail = TRUE)
}

# Student's t test of condition `high` versus condition `low` on `outcome`
# (equal variances, as preregistered), with Cohen's d and the one-tailed p
# value in the predicted direction. `data` must contain `condition` and
# the outcome column.
contrast_test <- function(data, outcome, high, low, direction) {
  x <- data[[outcome]][data$condition == high]
  y <- data[[outcome]][data$condition == low]
  x <- x[!is.na(x)]; y <- y[!is.na(y)]
  tt <- t.test(x, y, var.equal = TRUE)
  t  <- unname(tt$statistic); df <- unname(tt$parameter)
  tibble(
    n_high = length(x), n_low = length(y),
    m_high = mean(x), sd_high = sd(x), m_low = mean(y), sd_low = sd(y),
    d = cohens_d(x, y), t = t, df = df,
    p_one_tailed = p_one_tailed(t, df, direction),
    p_two_tailed = tt$p.value
  )
}

# Condition x income-group interaction for one pair of conditions:
# lm(outcome ~ scarcity * low_income) on the participants in `high` and `low`.
# The interaction coefficient is the (high - low) effect among low-income
# participants minus the same effect among high-income participants.
# One-tailed p in the direction that means "larger effect among low-income
# participants": positive for concerns, negative for cognitive measures.
interaction_test <- function(data, outcome, high, low, direction) {
  d <- data[data$condition %in% c(high, low), ]
  d$scarcity_high <- as.numeric(d$condition == high)
  d$low_income    <- as.numeric(d$income_group == "Low")
  fit <- lm(reformulate(c("scarcity_high", "low_income", "scarcity_high:low_income"), outcome), data = d)
  co  <- summary(fit)$coefficients["scarcity_high:low_income", ]
  t   <- unname(co["t value"]); df <- fit$df.residual
  tibble(
    b_interaction = unname(co["Estimate"]), t_interaction = t, df_interaction = df,
    p_interaction_one_tailed = p_one_tailed(t, df, direction),
    p_interaction_two_tailed = unname(co["Pr(>|t|)"])
  )
}

# Type III ANOVA (sum-to-zero contrasts, as SPSS does) with partial eta squared.
anova_type3 <- function(formula, data) {
  fit <- lm(formula, data = data, contrasts = make_sum_contrasts(formula, data))
  tab <- car::Anova(fit, type = 3)
  tab <- tab[!rownames(tab) %in% c("(Intercept)", "Residuals"), , drop = FALSE]
  ss_err <- car::Anova(fit, type = 3)["Residuals", "Sum Sq"]
  df_err <- car::Anova(fit, type = 3)["Residuals", "Df"]
  tibble(
    term = rownames(tab),
    df1 = tab$Df, df2 = df_err,
    F = tab$`F value`, p = tab$`Pr(>F)`,
    partial_eta2 = tab$`Sum Sq` / (tab$`Sum Sq` + ss_err)
  )
}

make_sum_contrasts <- function(formula, data) {
  vars <- all.vars(formula)[-1]
  vars <- vars[sapply(vars, function(v) is.factor(data[[v]]) || is.character(data[[v]]))]
  setNames(replicate(length(vars), "contr.sum", simplify = FALSE), vars)
}

# Cronbach's alpha of a set of item columns (already keyed in the right direction).
cronbach_alpha <- function(items) {
  suppressMessages(suppressWarnings(psych::alpha(as.data.frame(items), check.keys = FALSE)$total$raw_alpha))
}

# Two-tailed Student's t test comparing two groups (used for income groups).
group_test <- function(x, y) {
  x <- x[!is.na(x)]; y <- y[!is.na(y)]
  tt <- t.test(x, y, var.equal = TRUE)
  tibble(n_x = length(x), n_y = length(y), m_x = mean(x), sd_x = sd(x), m_y = mean(y), sd_y = sd(y),
         d = cohens_d(x, y), t = unname(tt$statistic), df = unname(tt$parameter), p = tt$p.value)
}

fmt_p <- function(p) ifelse(p < .001, "< .001", sub("^0", "", formatC(p, format = "f", digits = 3)))
# Two decimals; a value that rounds to zero prints as 0.00, never -0.00.
fmt2 <- function(x) { s <- sprintf("%.2f", x); s[s == "-0.00"] <- "0.00"; s }

read_processed <- function(study) {
  read_csv(file.path(DIR_PROCESSED, sprintf("study%d.csv", study)), show_col_types = FALSE, guess_max = 5000) %>%
    mutate(condition = factor(condition), income_group = factor(income_group, levels = c("Low", "High")))
}
