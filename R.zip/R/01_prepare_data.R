# =============================================================================
# 01_prepare_data.R -- build the analysis data sets from the raw survey exports
#
# Input : St1.csv ... St5.csv (raw Qualtrics/Prolific exports, one per study)
# Output: data/processed/study1.csv ... study5.csv, all_studies.csv
#         output/checks/derived_vs_spss.csv (recomputed scores vs. the scores
#         stored in the SPSS files)
#
# Every score is recomputed from the item responses. The derived columns that
# the raw files already contain (FCS_total, CPT_total, Raven, Reflection,
# Income_shah, gr_income, Condition) are used only to verify the recomputation.
# Identifying information (Prolific IDs, IP addresses, locations, free text)
# is not carried into the processed files.
# =============================================================================

source("R/00_setup.R")

num <- function(x) suppressWarnings(as.numeric(x))

# Prolific demographic export: its missing-value markers become NA, and the
# mojibake of the income brackets ("\u00c2\u00a3" for the pound sign,
# "\u00e2\u20ac\u201c" for the dash) is repaired.
PROLIFIC_MISSING <- c("", "0", "DATA EXPIRED", "DATA_EXPIRED", "CONSENT REVOKED", "CONSENT_REVOKED")
pro <- function(x) { x <- trimws(x); x[is.na(x) | x %in% PROLIFIC_MISSING] <- NA; x }
fix_enc <- function(x) gsub("\u00e2\u20ac\u201c", "\u2013", gsub("\u00c2\u00a3", "\u00a3", x, fixed = TRUE), fixed = TRUE)

read_raw <- function(study) {
  read_csv(file.path(DIR_RAW, sprintf("St%d.csv", study)),
           col_types = cols(.default = col_character()), na = c(""),
           locale = locale(encoding = "UTF-8"), progress = FALSE, show_col_types = FALSE)
}

# ---- coding constants -------------------------------------------------------

# Household income after tax, 12 brackets. Studies 1-2 in GBP, Studies 3-5 in
# USD; the same bracket boundaries were used (the open top bracket is set to
# 150,000, as in the paper).
INCOME_MIDPOINT <- c(5000, 15000, 25000, 35000, 45000, 55000, 65000, 75000, 85000, 95000, 125000, 150000)
US_INCOME_LABELS <- c("Less than $10,000", "$10,000 - $19,999", "$20,000 - $29,999", "$30,000 - $39,999",
                      "$40,000 - $49,999", "$50,000 - $59,999", "$60,000 - $69,999", "$70,000 - $79,999",
                      "$80,000 - $89,999", "$90,000 - $99,999", "$100,000 - $149,999", "More than $150,000")
AGREE7 <- c("Strongly disagree", "Disagree", "Somewhat disagree", "Neither agree nor disagree",
            "Somewhat agree", "Agree", "Strongly agree")
EDUCATION_LABELS_US <- c("Some high school", "Graduated high school", "Some college (no degree)",
                         "Associate's degree or technical or vocational school", "Bachelor's degree",
                         "Some graduate or professional school", "Earned graduate or professional degree")

# Correct answers. In Studies 1, 2, 4 and 5 the response options are stored
# as numeric codes; in Study 3 as the option text.
KEY_NUMERIC <- c(crt1 = 1, crt2 = 1, crt3 = 1, belief_bias = 2, base_rate = 1, conjunction = 1,
                 raven_e6 = 5, raven_e8 = 6, raven_e9 = 3)
KEY_TEXT_STUDY3 <- c(crt1 = "5 pence", crt2 = "5 minutes", crt3 = "47 days", belief_bias = "No",
                     conjunction = "Claire is a bank teller")
FINLIT_KEY <- c(2, 3, 1, 4, 3)   # five-item financial literacy test (Studies 1, 2, 4)

# Condition labels used throughout the analysis.
CONDITION_MAP <- list(
  `1` = c(Control_Passive = "Passive control",
          Control_Lottery = "Lottery low",      Manipulation_Lottery = "Lottery high",
          Control_Frame   = "Scale low",        Manipulation_Frame   = "Scale high",
          Control_Recall  = "Recall low",       Manipulation_Recall  = "Recall high",
          Control_Prime   = "Consequences low", Manipulation_Prime   = "Consequences high"),
  `2` = c(Control = "Passive control", Recall_Low = "Recall low", Recall_High = "Recall high",
          Imagine_Low = "Scenario low", Imagine_High = "Scenario high",
          Picture_Low = "Pictures low", Picture_High = "Generic pictures high", Picture_Covid = "COVID-19 pictures high"),
  `3` = c(Picture_Low = "Pictures low", Picture_High = "Generic pictures high", Picture_Covid = "COVID-19 pictures high"),
  `4` = c(Control = "Passive control", Recall_Low = "Recall low", Recall_High = "Recall high",
          Imagine_Low = "Scenario low", Imagine_High = "Scenario high",
          Picture_Low = "Pictures low", Picture_High = "Generic pictures high", Picture_Covid = "COVID-19 pictures high"),
  `5` = c(Control = "Passive control", Recall_Low = "Recall low", Recall_High = "Recall high",
          Imagine_Low = "Scenario low", Imagine_High = "Scenario high",
          Picture_Low_A = "COVID-19 pictures low", Picture_High_A = "COVID-19 pictures high",
          Picture_Low_B = "Picture imagination low", Picture_High_B = "Picture imagination high")
)
TECHNIQUE_OF <- c("Passive control" = "Control", "Lottery" = "Lottery", "Scale" = "Scale", "Recall" = "Recall",
                  "Consequences" = "Consequences", "Scenario" = "Scenario", "Pictures" = "Pictures",
                  "Generic pictures" = "Generic pictures", "COVID-19 pictures" = "COVID-19 pictures",
                  "Picture imagination" = "Picture imagination")

PANAS_POSITIVE <- c("interested", "excited", "strong", "enthusiastic", "proud", "alert", "inspired", "determined", "attentive", "active")
PANAS_NEGATIVE <- c("distressed", "upset", "guilty", "scared", "hostile", "irritable", "ashamed", "nervous", "jittery", "afraid")

# ---- per-study extraction ---------------------------------------------------
# Each function returns one row per participant with harmonised column names,
# plus the SPSS-derived scores (prefixed "spss_") used for verification.

prep_study1 <- function() {
  r <- read_raw(1)
  tibble(
    study = 1L, id = as.integer(r$ID), treatment_raw = r$Treatment,
    fcs_1 = num(r$FCS_1), fcs_2 = num(r$FCS_2), fcs_3 = num(r$FCS_3), fcs_4 = num(r$FCS_4), fcs_5 = num(r$FCS_5),
    crt1_response = num(r$Q1_CRT1), crt2_response = num(r$Q2_CRT2), crt3_response = num(r$Q3_CRT3),
    belief_bias_response = num(r$Q4_Belief_Bias), base_rate_response = num(r$Q5_Base_rate_neglect),
    conjunction_response = num(r$Q6_Conjunction_Fall),
    income_bracket = num(r$Household_income), household_size = num(r$Household_size),
    age = num(r$Age), gender = num(r$Gender), education = num(r$Education), uk_us_resident = num(r$Residency),
    measure_order = ifelse(r$Order_FCS_First == "Financialconcernsscale|CognitivePerformanceQs", "Concerns first", "Cognitive test first"),
    scale_rating = coalesce(num(r$Nelson_S2_Prime), num(r$Nelson_S2_Control)),
    lottery_check_max_correct = case_when(r$Treatment == "Manipulation_Lottery" ~ as.numeric(num(r$Bonus_M_AC_Q1) == 2),
                                          r$Treatment == "Control_Lottery" ~ as.numeric(num(r$Bonus_C_AC_Q1) == 2)),
    lottery_check_actual_correct = case_when(r$Treatment == "Manipulation_Lottery" ~ as.numeric(num(r$Bonus_M_AC_Q2) == 1),
                                             r$Treatment == "Control_Lottery" ~ as.numeric(num(r$Bonus_C_AC_Q2) == 2)),
    panas_positive = rowSums(sapply(PANAS_POSITIVE, function(v) num(r[[v]]))),
    panas_negative = rowSums(sapply(PANAS_NEGATIVE, function(v) num(r[[v]]))),
    finlit_score = rowSums(sapply(1:5, function(k) as.numeric(num(r[[paste0("FinLit_Test_", k)]]) == FINLIT_KEY[k]))),
    finlit_self_rating = num(r$Fin_lit_perception),
    duration_seconds = num(r$Duration),
    spss_concerns = num(r$FCS_total), spss_crs = num(r$CPT_total), spss_effective_income = num(r$Income_shah),
    spss_income_group = num(r$gr_income), spss_condition_code = num(r$Condition),
    spss_panas_positive = num(r$Positive_Affect), spss_panas_negative = num(r$Negative_Affect), spss_finlit = num(r$FLS)
  )
}

prep_study2 <- function() {
  r <- read_raw(2)
  out <- tibble(
    study = 2L, id = as.integer(r$ID), treatment_raw = r$Treatment,
    crt1_response = num(r$Q1_CRT1), crt2_response = num(r$Q2_CRT2), crt3_response = num(r$Q3_CRT3),
    belief_bias_response = num(r$Q4_Belief_Bias), conjunction_response = num(r$Q5_Conjunction_Fall),
    raven_e6_response = num(r$E6), raven_e8_response = num(r$E8), raven_e9_response = num(r$E9),
    income_bracket = num(r$Household_income), household_size = num(r$Household_size),
    age = num(r$Age), gender = num(r$Gender), education = num(r$Education), uk_us_resident = num(r$Residency),
    panas_positive = rowSums(sapply(PANAS_POSITIVE, function(v) num(r[[v]]))),
    panas_negative = rowSums(sapply(PANAS_NEGATIVE, function(v) num(r[[v]]))),
    finlit_score = rowSums(sapply(1:5, function(k) as.numeric(num(r[[paste0("F", k)]]) == FINLIT_KEY[k]))),
    finlit_self_estimate = num(r$OC_Absolute), finlit_relative_estimate = num(r$OC_Relative),
    sleep_hours = num(r$Sleep), hours_since_meal = num(r$Hunger),
    covid_diagnosed = num(r$Self_Diagnosis), covid_risk_1 = num(r$Risk_perception_1), covid_risk_2 = num(r$Risk_perception_2),
    ideology = num(r$Ideology), religiosity = num(r$Religiosity),
    duration_seconds = num(r$Duration_in_seconds),
    prolific_age = num(r$KB), prolific_sex = pro(r$Sex), prolific_gender_identity = pro(r$Gender_identity),
    prolific_country_of_birth = pro(r$Country_of_Birth), prolific_country_of_residence = pro(r$Current_Country_of_Residence),
    prolific_nationality = pro(r$Nationality), prolific_first_language = pro(r$First_Language), prolific_fluent_languages = pro(r$Fluent_languages),
    prolific_employment_status = pro(r$Employment_Status), prolific_student_status = pro(r$Student_Status),
    prolific_household_income = pro(fix_enc(r$Household_Income_GBP)),
    spss_concerns = num(r$FCS_total), spss_crs = num(r$CPT_total), spss_fis = num(r$Raven), spss_reflection = num(r$Reflection),
    spss_effective_income = num(r$Income_shah), spss_income_group = num(r$gr_income), spss_condition_code = num(r$Condition),
    spss_panas_positive = num(r$Positive_Affect), spss_panas_negative = num(r$Negative_Affect), spss_finlit = num(r$FLS)
  )
  for (k in 1:15) out[[paste0("fcq_", k)]] <- num(r[[paste0("FCS_", k)]])
  out
}

prep_study3 <- function() {
  r <- read_raw(3)
  tibble(
    study = 3L, id = as.integer(r$ID), treatment_raw = r$Treatment,
    scs_1 = match(r$SCS_1, AGREE7), scs_2 = match(r$SCS_2, AGREE7), scs_3 = match(r$SCS_3, AGREE7), scs_4 = match(r$SCS_4, AGREE7),
    crt1_response_text = r$Q1_CRT1, crt2_response_text = r$Q2_CRT2, crt3_response_text = r$Q3_CRT3,
    belief_bias_response_text = r$Q4_Belief_Bias, conjunction_response_text = r$Q5_Conjunction_Fall,
    raven_e6_response = num(r$E6), raven_e8_response = num(r$E8), raven_e9_response = num(r$E9),
    income_bracket = match(r$Household_income, US_INCOME_LABELS), household_size = num(r$Household_size_s),
    age = num(r$Age), gender = match(r$gender, c("Female", "Male", "Other")),
    education = match(r$Education, EDUCATION_LABELS_US),
    uk_us_resident = ifelse(r$Residency == "No", 2, 1),   # exported label of the "yes" option reads "UK"; see codebook
    affect_arousal = num(r$AQ1_Arousal), affect_pleasure = num(r$AQ2_Pleasure),
    sleep_hours = num(r$Sleep), hours_since_meal = ifelse(r$Hunger == "More than 10", 11, num(r$Hunger)),
    covid_diagnosed = ifelse(r$Self_Diagnosis == "Yes", 1, 2), covid_risk_1 = num(r$Risk_perception_1), covid_risk_2 = num(r$Risk_perception_2),
    duration_seconds = num(r$Duration_in_seconds),
    prolific_age = num(r[["@GE"]]), prolific_sex = pro(r$Sex), prolific_gender_identity = pro(r$Gender_identity),
    prolific_country_of_birth = pro(r$Country_of_Birth), prolific_country_of_residence = pro(r$Current_Country_of_Residence),
    prolific_nationality = pro(r$Nationality), prolific_first_language = pro(r$First_Language), prolific_fluent_languages = pro(r$Fluent_languages),
    prolific_employment_status = pro(r$Employment_Status), prolific_student_status = pro(r$Student_Status),
    spss_concerns = num(r$SCS_total), spss_crs = num(r$CPT_total), spss_fis = num(r$Raven), spss_reflection = num(r$Reflection),
    spss_effective_income = num(r$Income_shah), spss_income_group = num(r$gr_income), spss_condition_code = num(r$Condition)
  )
}

prep_study4 <- function() {
  r <- read_raw(4)
  out <- tibble(
    study = 4L, id = as.integer(r$ID), treatment_raw = r$Treatment,
    crt1_response = num(r$Q1_CRT1), crt2_response = num(r$Q2_CRT2), crt3_response = num(r$Q3_CRT3),
    belief_bias_response = num(r$Q4_Belief_Bias), conjunction_response = num(r$Q5_Conjunction_Fall),
    raven_e6_response = num(r$E6), raven_e8_response = num(r$E8), raven_e9_response = num(r$E9),
    income_bracket = num(r$Household_income), household_size = num(r$Household_size),
    age = num(r$Age), gender = num(r$gender), education = num(r$Education), uk_us_resident = num(r$Residency),
    affect_arousal = num(r$Q1_1), affect_pleasure = num(r$Q2_1),
    finlit_score = rowSums(sapply(1:5, function(k) as.numeric(num(r[[paste0("F", k)]]) == FINLIT_KEY[k]))),
    finlit_self_estimate = num(r$OC_Absolute), finlit_relative_estimate = num(r$OC_Relative_12),
    sleep_hours = num(r$Sleep), hours_since_meal = num(r$Hunger),
    covid_diagnosed = num(r$Self_Diagnosis), covid_risk_1 = num(r$Risk_perception_1), covid_risk_2 = num(r$Risk_perception_2),
    ideology = num(r$Ideology), religiosity = num(r$Religiosity),
    duration_seconds = num(r$Duration_in_seconds), finished = num(r$Finished),
    prolific_age = num(r$KH), prolific_sex = pro(r$Sex), prolific_gender_identity = pro(r$Gender_identity),
    prolific_country_of_birth = pro(r$Country_of_Birth), prolific_country_of_residence = pro(r$Current_Country_of_Residence),
    prolific_nationality = pro(r$Nationality), prolific_first_language = pro(r$First_Language), prolific_fluent_languages = pro(r$Fluent_languages),
    prolific_employment_status = pro(r$Employment_Status), prolific_student_status = pro(r$Student_Status),
    prolific_household_income = pro(fix_enc(r$Household_Income_USD_US_parti)),
    spss_concerns = num(r$FCS_total), spss_crs = num(r$CPT_total), spss_fis = num(r$Raven), spss_reflection = num(r$Reflection),
    spss_effective_income = num(r$Income_shah), spss_income_group = num(r$gr_income), spss_condition_code = num(r$Condition),
    spss_finlit = num(r$FLS)
  )
  for (k in 1:15) out[[paste0("fcq_", k)]] <- num(r[[paste0("FCS_", k)]])
  out
}

prep_study5 <- function() {
  r <- read_raw(5)
  # The Prolific block of this export mixes two export formats. In rows from the
  # screened pools (September 2022) the "Approval rate" column is numeric and
  # every field sits under its own header; in rows from the full-income-range
  # pool (November 2022) the export had no "Total rejections" and "Approval
  # rate" fields, so every demographic value sits two columns to the left.
  layout_a <- grepl("^[0-9]+$", r$Approvalrate)
  pick <- function(a, b) ifelse(layout_a, a, b)
  out <- tibble(
    study = 5L, id = seq_len(nrow(r)),           # the ID column of the Study 5 export is empty
    treatment_raw = r$Treatment,
    crt1_response = num(r$Q1CRT1), crt2_response = num(r$Q2CRT2), crt3_response = num(r$Q3CRT3),
    belief_bias_response = num(r$Q4BeliefBias), conjunction_response = num(r$Q5ConjunctionFall),
    raven_e6_response = num(r$E6), raven_e8_response = num(r$E8), raven_e9_response = num(r$E9),
    income_bracket = num(r$Income), household_size = num(r$Household),
    age = num(r$age), gender = num(r$gender), education = num(r$Education), uk_us_resident = num(r$Residency),
    affect_arousal = num(r$Q1_1), affect_pleasure = num(r$Q2_1),
    sleep_hours = num(r$Sleep), hours_since_meal = num(r$Hunger),
    covid_diagnosed = num(r$SelfDiagnosis), covid_risk_1 = num(r$Riskperception_1), covid_risk_2 = num(r$Riskperception_2),
    ideology = num(r$Ideology), religiosity = num(r$Religiosity),
    sample_pool = ifelse(num(r$PART) == 1, "Screened income pools", "Full income range"),
    duration_seconds = num(r$Durationinseconds), finished = num(r$Finished),
    prolific_age = num(pick(r$Age_A, r$Fluentlanguages)), prolific_sex = pro(pick(r$Sex, r$Householdincomeusdusparti)),
    prolific_gender_identity = pro(pick(r$Genderidentity, r$Totalrejections)), prolific_ethnicity = pro(pick(r$Ethnicitysimplified, r$Age_A)),
    prolific_country_of_birth = pro(pick(r$Countryofbirth, r$Sex)), prolific_country_of_residence = pro(pick(r$Countryofresidence, r$Ethnicitysimplified)),
    prolific_nationality = pro(pick(r$Nationality, r$Countryofbirth)), prolific_first_language = pro(pick(r$Language, r$Countryofresidence)),
    prolific_fluent_languages = pro(pick(r$Fluentlanguages, r$Approvalrate)), prolific_employment_status = pro(pick(r$Employmentstatus, r$Language)),
    prolific_student_status = pro(pick(r$Studentstatus, r$Nationality)), prolific_household_income = pro(fix_enc(pick(r$Householdincomeusdusparti, r$Genderidentity))),
    spss_concerns = num(r$FCS_total), spss_crs = num(r$CPT_total), spss_fis = num(r$Raven),
    spss_effective_income = num(r$Income_shah), spss_income_group = num(r$gr_income), spss_condition_code = num(r$Condition)
  )
  for (k in 1:15) out[[paste0("fcq_", k)]] <- num(r[[paste0("FCS_", k)]])
  out
}

# ---- scoring (identical for every study) ------------------------------------

score_study <- function(d) {
  s <- d$study[1]
  d$condition <- unname(CONDITION_MAP[[as.character(s)]][d$treatment_raw])
  stopifnot(!any(is.na(d$condition)))
  d$technique <- ifelse(d$condition == "Passive control", "Control", sub(" (high|low)$", "", d$condition))
  d$scarcity  <- case_when(str_detect(d$condition, " high$") ~ "High", str_detect(d$condition, " low$") ~ "Low", TRUE ~ "Control")

  # -- cognitive items: correct = 1, incorrect = 0
  if (s == 3) {
    d$crt1_correct        <- as.numeric(d$crt1_response_text == KEY_TEXT_STUDY3["crt1"])
    d$crt2_correct        <- as.numeric(d$crt2_response_text == KEY_TEXT_STUDY3["crt2"])
    d$crt3_correct        <- as.numeric(d$crt3_response_text == KEY_TEXT_STUDY3["crt3"])
    d$belief_bias_correct <- as.numeric(d$belief_bias_response_text == KEY_TEXT_STUDY3["belief_bias"])
    d$conjunction_correct <- as.numeric(d$conjunction_response_text == KEY_TEXT_STUDY3["conjunction"])
  } else {
    d$crt1_correct        <- as.numeric(d$crt1_response == KEY_NUMERIC["crt1"])
    d$crt2_correct        <- as.numeric(d$crt2_response == KEY_NUMERIC["crt2"])
    d$crt3_correct        <- as.numeric(d$crt3_response == KEY_NUMERIC["crt3"])
    d$belief_bias_correct <- as.numeric(d$belief_bias_response == KEY_NUMERIC["belief_bias"])
    d$conjunction_correct <- as.numeric(d$conjunction_response == KEY_NUMERIC["conjunction"])
    if (s == 1) d$base_rate_correct <- as.numeric(d$base_rate_response == KEY_NUMERIC["base_rate"])
  }
  # Cognitive reflection score: all CPT items of the study (6 in Study 1, 5 otherwise)
  # and the five items common to all studies (crs5; identical to crs in Studies 2-5).
  d$crs5 <- d$crt1_correct + d$crt2_correct + d$crt3_correct + d$belief_bias_correct + d$conjunction_correct
  d$crs  <- if (s == 1) d$crs5 + d$base_rate_correct else d$crs5
  if (s >= 2) {
    d$raven_e6_correct <- as.numeric(d$raven_e6_response == KEY_NUMERIC["raven_e6"])
    d$raven_e8_correct <- as.numeric(d$raven_e8_response == KEY_NUMERIC["raven_e8"])
    d$raven_e9_correct <- as.numeric(d$raven_e9_response == KEY_NUMERIC["raven_e9"])
    d$fis        <- d$raven_e6_correct + d$raven_e8_correct + d$raven_e9_correct
    d$reflection <- d$crs + d$fis
  }

  # -- scarcity concerns (manipulation check), summed; reverse-keyed items: 8 - x
  if (s == 1) {
    d$concerns <- (8 - d$fcs_1) + (8 - d$fcs_2) + d$fcs_3 + (8 - d$fcs_4) + d$fcs_5
  } else if (s == 3) {
    d$concerns <- d$scs_1 + d$scs_2 + d$scs_3 + d$scs_4
  } else {
    rev <- c(1, 2, 4, 7, 8, 13)
    d$concerns <- rowSums(sapply(1:15, function(k) if (k %in% rev) 8 - d[[paste0("fcq_", k)]] else d[[paste0("fcq_", k)]]))
  }

  # -- income: effective income = bracket midpoint / sqrt(household size);
  #    preregistered median split, participants at the median -> high-income group.
  d$income_midpoint   <- INCOME_MIDPOINT[d$income_bracket]
  d$effective_income  <- d$income_midpoint / sqrt(d$household_size)
  med <- median(d$effective_income)
  d$income_group          <- ifelse(d$effective_income >= med, "High", "Low")
  d$income_group_ties_low <- ifelse(d$effective_income >  med, "High", "Low")   # sensitivity analysis
  attr(d, "income_median") <- med
  d
}

# ---- verification against the SPSS-derived columns --------------------------

verify_study <- function(d) {
  s <- d$study[1]
  chk <- function(name, a, b, tol = 1e-6) tibble(study = s, variable = name, n = sum(!is.na(a) | !is.na(b)),
                                     n_mismatch = sum(!(is.na(a) & is.na(b)) & (is.na(a) | is.na(b) | abs(a - b) > tol)))
  code_map <- setNames(seq_along(CONDITION_MAP[[as.character(s)]]) - 1, names(CONDITION_MAP[[as.character(s)]]))
  rows <- list(
    chk("concerns", d$concerns, d$spss_concerns),
    chk("crs", d$crs, d$spss_crs),
    chk("effective_income", d$effective_income, d$spss_effective_income, tol = 0.01),  # SPSS export rounds to 5 decimals
    chk("income_group", as.numeric(d$income_group == "High"), d$spss_income_group)
  )
  if (s >= 2) rows <- c(rows, list(chk("fis", d$fis, d$spss_fis)))
  if (s %in% 2:4) rows <- c(rows, list(chk("reflection", d$reflection, d$spss_reflection)))
  if (s %in% c(1, 2)) rows <- c(rows, list(chk("panas_positive", d$panas_positive, d$spss_panas_positive),
                                           chk("panas_negative", d$panas_negative, d$spss_panas_negative)))
  if (s %in% c(1, 2, 4)) rows <- c(rows, list(chk("finlit_score", d$finlit_score, d$spss_finlit)))
  bind_rows(rows)
}

# ---- run --------------------------------------------------------------------

studies <- list(prep_study1(), prep_study2(), prep_study3(), prep_study4(), prep_study5())
studies <- lapply(studies, score_study)
checks  <- bind_rows(lapply(studies, verify_study))
write_csv(checks, file.path(DIR_CHECKS, "derived_vs_spss.csv"))
cat("Recomputed scores versus SPSS-derived scores (n_mismatch should be 0 everywhere):\n")
print(as.data.frame(checks))
stopifnot(all(checks$n_mismatch == 0))

FIRST_COLS <- c("study", "id", "condition", "technique", "scarcity", "concerns", "crs", "crs5", "fis", "reflection",
                "income_group", "effective_income", "income_bracket", "income_midpoint", "household_size",
                "income_group_ties_low", "age", "gender", "education")
for (d in studies) {
  s <- d$study[1]
  d <- d %>% select(-starts_with("spss_"))
  d <- d[, c(FIRST_COLS[FIRST_COLS %in% names(d)], setdiff(names(d), FIRST_COLS))]
  write_csv(d, file.path(DIR_PROCESSED, sprintf("study%d.csv", s)), na = "")
  cat(sprintf("Study %d: N = %d, income median = %.2f, conditions: %s\n", s, nrow(d), attr(studies[[s]], "income_median"),
              paste(sprintf("%s (%d)", names(table(d$condition)), table(d$condition)), collapse = "; ")))
}
all_studies <- bind_rows(lapply(studies, function(d) select(d, -starts_with("spss_"))))
all_studies <- all_studies[, c(FIRST_COLS[FIRST_COLS %in% names(all_studies)], setdiff(names(all_studies), FIRST_COLS))]
write_csv(all_studies, file.path(DIR_PROCESSED, "all_studies.csv"), na = "")
cat(sprintf("All studies: N = %d rows, %d columns -> %s\n", nrow(all_studies), ncol(all_studies), file.path(DIR_PROCESSED, "all_studies.csv")))
