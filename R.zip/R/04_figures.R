# =============================================================================
# 04_figures.R -- figures
#
#   figure1_forest_reflection.png   Figure 1 of the paper: Hedges' g for the
#                                   Reflection score, all participants and
#                                   low-income participants, with pooled estimates
#   figure2_forest_all_measures.png All 18 comparisons on the four measures
#   figure3_condition_means_concerns.png / figure3_condition_means_cognition.png
#                                   Means (95% CI) by condition and income group
#   figure4_income_groups.png       Income-group differences per study and pooled
#   figure5_effective_income.png    Distribution of effective income and the
#                                   preregistered median split
#
# Requires the tables written by 02_study_analyses.R and 03_meta_analysis.R.
# =============================================================================

source("R/00_setup.R")
invisible(suppressWarnings(Sys.setlocale("LC_CTYPE", "en_US.UTF-8")))   # so that the plus-minus sign renders under Rscript

COL_ALL  <- "#2a78d6"   # blue: all participants / high-income group
COL_LOW  <- "#eb6834"   # orange: low-income group
COL_MID  <- "#52514e"   # grey: pooled estimates, reference lines
theme_pub <- function(base_size = 11) {
  theme_minimal(base_size = base_size) +
    theme(panel.grid.minor = element_blank(), panel.grid.major.y = element_blank(),
          panel.grid.major.x = element_line(colour = "grey88", linewidth = 0.3),
          strip.text = element_text(face = "bold", hjust = 0), legend.position = "top",
          plot.title.position = "plot", plot.caption.position = "plot",
          plot.caption = element_text(colour = COL_MID, hjust = 0, size = rel(0.8)),
          axis.title.y = element_blank(), text = element_text(colour = "#0b0b0b"))
}
save_fig <- function(p, name, w, h) {
  ggsave(file.path(DIR_FIGURES, paste0(name, ".png")), p, width = w, height = h, dpi = 300, bg = "white")
  ggsave(file.path(DIR_FIGURES, paste0(name, ".pdf")), p, width = w, height = h, bg = "white")
}
MEASURE_LABELS <- c(concerns = "Scarcity concerns", crs = "Cognitive reflection", fis = "Fluid intelligence", reflection = "Reflection score")

es <- read_csv(file.path(DIR_TABLES, "meta_effect_sizes.csv"), show_col_types = FALSE) %>%
  mutate(ci_lb = yi - qnorm(.975) * sqrt(vi), ci_ub = yi + qnorm(.975) * sqrt(vi),
         comparison = sprintf("Study %d: %s", study, technique),
         comparison = factor(comparison, levels = rev(unique(comparison))))
t7 <- read_csv(file.path(DIR_TABLES, "meta_table7_pooled_effects.csv"), show_col_types = FALSE)

# ---- Figure 1: forest plot of the Reflection score --------------------------
f1 <- es %>% filter(measure == "reflection", sample %in% c("All", "Low")) %>%
  mutate(sample = factor(ifelse(sample == "All", "All participants", "Low-income participants"),
                         levels = c("All participants", "Low-income participants")))
pooled1 <- t7 %>% filter(measure == "Reflection score") %>%
  transmute(`All participants` = g_all, lb_all = ci_lb_all, ub_all = ci_ub_all, `Low-income participants` = g_low, lb_low = ci_lb_low, ub_low = ci_ub_low)
diamonds <- tibble(sample = factor(c("All participants", "Low-income participants"), levels = levels(f1$sample)),
                   g = c(pooled1$`All participants`, pooled1$`Low-income participants`),
                   lb = c(pooled1$lb_all, pooled1$lb_low), ub = c(pooled1$ub_all, pooled1$ub_low)) %>%
  rowwise() %>% reframe(sample = sample, x = c(lb, g, ub, g), y = c(0, 0.35, 0, -0.35))
p1 <- ggplot(f1, aes(x = yi, y = comparison)) +
  annotate("rect", xmin = -0.2, xmax = 0.2, ymin = -Inf, ymax = Inf, fill = "grey94", alpha = 0.6) +
  geom_vline(xintercept = 0, colour = COL_MID, linewidth = 0.4) +
  geom_vline(xintercept = c(-0.2, 0.2), colour = COL_MID, linetype = "dashed", linewidth = 0.3) +
  geom_errorbar(aes(xmin = ci_lb, xmax = ci_ub, colour = sample), width = 0, linewidth = 0.5, orientation = "y") +
  geom_point(aes(colour = sample), size = 2.2) +
  geom_polygon(data = diamonds, aes(x = x, y = y, group = sample), fill = COL_MID, inherit.aes = FALSE) +
  scale_y_discrete(expand = expansion(add = c(1.2, 0.6))) +
  scale_colour_manual(values = c("All participants" = COL_ALL, "Low-income participants" = COL_LOW), guide = "none") +
  facet_wrap(~ sample) +
  labs(x = "Hedges' g (high minus low scarcity), 95% CI", title = "Effects of high- versus low-scarcity manipulations on the Reflection score",
       caption = "Diamonds: pooled multilevel estimates (REML). Dashed lines: equivalence bounds of g = \u00b10.20. Study 1 did not measure fluid intelligence.") +
  theme_pub()
save_fig(p1, "figure1_forest_reflection", 9, 5.5)

# ---- Figure 2: all comparisons, all measures, full sample -------------------
f2 <- es %>% filter(sample == "All") %>% mutate(measure = factor(MEASURE_LABELS[measure], levels = MEASURE_LABELS))
pooled2 <- t7 %>% filter(measure != "Scarcity concerns, without Study 3") %>%
  transmute(measure = factor(c("Scarcity concerns", "Cognitive reflection", "Fluid intelligence", "Reflection score"), levels = MEASURE_LABELS), g = g_all, lb = ci_lb_all, ub = ci_ub_all)
p2 <- ggplot(f2, aes(x = yi, y = comparison)) +
  annotate("rect", xmin = -0.2, xmax = 0.2, ymin = -Inf, ymax = Inf, fill = "grey94", alpha = 0.6) +
  geom_vline(xintercept = 0, colour = COL_MID, linewidth = 0.4) +
  geom_rect(data = pooled2, aes(xmin = lb, xmax = ub, ymin = -Inf, ymax = Inf), inherit.aes = FALSE, fill = COL_ALL, alpha = 0.12) +
  geom_vline(data = pooled2, aes(xintercept = g), colour = COL_ALL, linewidth = 0.5) +
  geom_errorbar(aes(xmin = ci_lb, xmax = ci_ub), width = 0, linewidth = 0.45, colour = COL_ALL, orientation = "y") +
  geom_point(size = 1.9, colour = COL_ALL) +
  facet_wrap(~ measure, nrow = 1) +
  labs(x = "Hedges' g (high minus low scarcity), 95% CI", title = "The 18 high- versus low-scarcity comparisons, all participants",
       caption = "Vertical line and band: pooled multilevel estimate with 95% CI (concerns: all studies). Grey region: equivalence bounds \u00b10.20. Scarcity concerns were measured with the FCS (Study 1), FCQ (Studies 2, 4, 5) and SCS (Study 3).") +
  theme_pub(10) + theme(panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.25))
save_fig(p2, "figure2_forest_all_measures", 13, 6)

# ---- Figure 3: condition means by income group ------------------------------
all_data <- bind_rows(lapply(1:5, read_processed))
cond_levels <- c("Passive control", "Lottery low", "Lottery high", "Scale low", "Scale high", "Recall low", "Recall high",
                 "Consequences low", "Consequences high", "Scenario low", "Scenario high", "Pictures low", "Generic pictures high",
                 "COVID-19 pictures low", "COVID-19 pictures high", "Picture imagination low", "Picture imagination high")
means <- all_data %>% mutate(cognition = ifelse(study == 1, crs, reflection)) %>%
  group_by(study, condition, income_group) %>%
  summarise(across(c(concerns, cognition), list(m = ~mean(.x), se = ~sd(.x) / sqrt(n())), .names = "{.col}_{.fn}"), n = n()) %>%
  ungroup() %>% mutate(condition = factor(condition, levels = rev(cond_levels)), income_group = factor(income_group, levels = c("Low", "High"), labels = c("Low income", "High income")),
                       study_label = sprintf("Study %d (%s)", study, c("FCS, 5-35", "FCQ, 15-105", "SCS, 4-28", "FCQ, 15-105", "FCQ, 15-105")[study]))
p3a <- ggplot(means, aes(x = concerns_m, y = condition, colour = income_group)) +
  geom_errorbar(aes(xmin = concerns_m - 1.96 * concerns_se, xmax = concerns_m + 1.96 * concerns_se), width = 0, linewidth = 0.5, position = position_dodge(width = 0.5), orientation = "y") +
  geom_point(size = 2, position = position_dodge(width = 0.5)) +
  facet_wrap(~ study_label, scales = "free", nrow = 1) +
  scale_colour_manual(values = c("Low income" = COL_LOW, "High income" = COL_ALL), name = NULL) +
  labs(x = "Scarcity concerns, mean and 95% CI", title = "Scarcity concerns by condition and income group",
       caption = "Scales differ between studies (FCS: Financial Concerns Scale; FCQ: Financial Concerns Questionnaire; SCS: Scarcity Concerns Scale).") +
  theme_pub(10) + theme(panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.25))
save_fig(p3a, "figure3_condition_means_concerns", 14, 5.5)
p3b <- ggplot(means %>% mutate(study_label = sprintf("Study %d (%s)", study, ifelse(study == 1, "cognitive reflection, 0-6", "Reflection score, 0-8"))),
              aes(x = cognition_m, y = condition, colour = income_group)) +
  geom_errorbar(aes(xmin = cognition_m - 1.96 * cognition_se, xmax = cognition_m + 1.96 * cognition_se), width = 0, linewidth = 0.5, position = position_dodge(width = 0.5), orientation = "y") +
  geom_point(size = 2, position = position_dodge(width = 0.5)) +
  facet_wrap(~ study_label, scales = "free", nrow = 1) +
  scale_colour_manual(values = c("Low income" = COL_LOW, "High income" = COL_ALL), name = NULL) +
  labs(x = "Cognitive performance, mean and 95% CI", title = "Cognitive performance by condition and income group",
       caption = "Study 1: cognitive reflection score (six CPT items). Studies 2-5: Reflection score (five CPT items + three Raven items).") +
  theme_pub(10) + theme(panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.25))
save_fig(p3b, "figure3_condition_means_cognition", 14, 5.5)

# ---- Figure 4: income-group differences per study and pooled ----------------
inc_es <- read_csv(file.path(DIR_TABLES, "meta_income_group_effect_sizes.csv"), show_col_types = FALSE) %>%
  mutate(ci_lb = yi - qnorm(.975) * sqrt(vi), ci_ub = yi + qnorm(.975) * sqrt(vi), label = sprintf("Study %d", study))
inc_pooled <- read_csv(file.path(DIR_TABLES, "meta_income_and_cognition.csv"), show_col_types = FALSE) %>%
  transmute(measure, yi = g_high_minus_low_income, ci_lb, ci_ub, label = "Pooled (REML, Knapp-Hartung)")
f4 <- bind_rows(inc_es %>% select(measure, yi, ci_lb, ci_ub, label), inc_pooled) %>%
  mutate(measure = factor(MEASURE_LABELS[measure], levels = MEASURE_LABELS), label = factor(label, levels = rev(c(paste("Study", 1:5), "Pooled (REML, Knapp-Hartung)"))),
         pooled = str_detect(label, "Pooled"))
p4 <- ggplot(f4, aes(x = yi, y = label)) +
  geom_vline(xintercept = 0, colour = COL_MID, linewidth = 0.4) +
  geom_errorbar(aes(xmin = ci_lb, xmax = ci_ub, colour = pooled), width = 0, linewidth = 0.5, orientation = "y") +
  geom_point(aes(colour = pooled, shape = pooled), size = 2.4) +
  scale_colour_manual(values = c(`FALSE` = COL_ALL, `TRUE` = COL_MID), guide = "none") + scale_shape_manual(values = c(`FALSE` = 16, `TRUE` = 18), guide = "none") +
  facet_wrap(~ measure, nrow = 1, scales = "free_x") +
  labs(x = "Hedges' g (high minus low income), 95% CI", title = "High- versus low-income participants on each measure") +
  theme_pub(10)
save_fig(p4, "figure4_income_groups", 12, 3.8)

# ---- Figure 5: effective income and the median split ------------------------
inc <- all_data %>% mutate(study_label = sprintf("Study %d (%s)", study, ifelse(study <= 2, "GBP", "USD")))
meds <- inc %>% group_by(study_label) %>% summarise(median = median(effective_income))
p5 <- ggplot(inc, aes(x = effective_income / 1000, fill = income_group)) +
  geom_histogram(binwidth = 5, boundary = 0, colour = "white", linewidth = 0.2) +
  geom_vline(data = meds, aes(xintercept = median / 1000), colour = COL_MID, linetype = "dashed") +
  facet_wrap(~ study_label, nrow = 1) +
  scale_fill_manual(values = c("Low" = COL_LOW, "High" = COL_ALL), name = "Income group (preregistered median split; ties to High)") +
  labs(x = "Effective income (household income after tax / sqrt(household size)), thousands", y = "Participants",
       title = "Effective income and the median split in each study") +
  theme_pub(10) + theme(axis.title.y = element_text(), panel.grid.major.y = element_line(colour = "grey92", linewidth = 0.25))
save_fig(p5, "figure5_effective_income", 13, 4)

cat("Figures written to", DIR_FIGURES, "\n")
