# =============================================================================
# 02_study_analyses.R -- per-study analyses (Studies 1 to 5)
#
# Reproduces, from the processed data, every statistic reported in the Results
# sections and in Tables 2 to 6 of the paper:
#   * reliabilities (Cronbach's alpha)
#   * omnibus ANOVAs (Type III sums of squares, partial eta squared)
#   * income-group differences (two-tailed Student's t, Cohen's d)
#   * preregistered high- versus low-scarcity contrasts (one-tailed Student's
#     t in the predicted direction, Cohen's d) in the full sample and within
#     each income group, and the condition x income interaction for each pair
#     of conditions
#
# Output: output/tables/study<k>_*.csv and output/tables/all_contrasts.csv
# =============================================================================

source("R/00_setup.R")

# ---- reliability ------------------------------------------------------------
reliability_table <- function(d, s) {
  items <- list()
  if (s == 1) {
    items[["Scarcity concerns (FCS, 5 items)"]] <- tibble(8 - d$fcs_1, 8 - d$fcs_2, d$fcs_3, 8 - d$fcs_4, d$fcs_5)
    items[["Cognitive reflection (CPT, 6 items)"]] <- d[, c("crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "base_rate_correct", "conjunction_correct")]
    items[["Cognitive reflection (5 common items)"]] <- d[, c("crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "conjunction_correct")]
  } else {
    if (s == 3) {
      items[["Scarcity concerns (SCS, 4 items)"]] <- d[, paste0("scs_", 1:4)]
    } else {
      rev <- c(1, 2, 4, 7, 8, 13)
      items[["Scarcity concerns (FCQ, 15 items)"]] <- as_tibble(sapply(1:15, function(k) if (k %in% rev) 8 - d[[paste0("fcq_", k)]] else d[[paste0("fcq_", k)]]))
    }
    cpt <- c("crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "conjunction_correct")
    rav <- c("raven_e6_correct", "raven_e8_correct", "raven_e9_correct")
    items[["Cognitive reflection (CPT, 5 items)"]] <- d[, cpt]
    items[["Fluid intelligence (3 Raven items)"]]  <- d[, rav]
    items[["Reflection score (8 items)"]]          <- d[, c(cpt, rav)]
  }
  tibble(study = s, scale = names(items), k_items = sapply(items, ncol), alpha = sapply(items, cronbach_alpha))
}

# ---- one study --------------------------------------------------------------
run_study <- function(s) {
  d <- read_processed(s)
  measures <- MEASURES %>% filter(measure %in% names(d)) %>%
    mutate(label = ifelse(measure == "concerns", concern_label(s), label))
  comps <- COMPARISONS %>% filter(study == s)

  # Descriptives by condition and by condition x income group
  desc_cond <- d %>% group_by(condition) %>%
    summarise(income_group = "All", n = n(), across(all_of(measures$measure), list(mean = ~mean(.x), sd = ~sd(.x)), .names = "{.col}_{.fn}"))
  desc_inc <- d %>% group_by(condition, income_group) %>%
    summarise(n = n(), across(all_of(measures$measure), list(mean = ~mean(.x), sd = ~sd(.x)), .names = "{.col}_{.fn}")) %>%
    mutate(income_group = as.character(income_group))
  descriptives <- bind_rows(desc_cond, desc_inc) %>% mutate(study = s, .before = 1)

  # Sample description
  sample <- tibble(study = s, n = nrow(d), age_mean = mean(d$age, na.rm = TRUE), age_sd = sd(d$age, na.rm = TRUE),
                   n_women = sum(d$gender == 1, na.rm = TRUE), n_men = sum(d$gender == 2, na.rm = TRUE), n_other = sum(d$gender == 3, na.rm = TRUE),
                   income_median = median(d$effective_income),
                   n_low_income = sum(d$income_group == "Low"), n_high_income = sum(d$income_group == "High"),
                   income_low_mean = mean(d$effective_income[d$income_group == "Low"]), income_low_sd = sd(d$effective_income[d$income_group == "Low"]),
                   income_high_mean = mean(d$effective_income[d$income_group == "High"]), income_high_sd = sd(d$effective_income[d$income_group == "High"]))

  # Omnibus ANOVAs: condition (one-way) and condition x income group (two-way)
  anovas <- bind_rows(lapply(measures$measure, function(m) {
    bind_rows(
      anova_type3(reformulate("condition", m), d) %>% mutate(model = "condition"),
      anova_type3(reformulate(c("condition", "income_group", "condition:income_group"), m), d) %>% mutate(model = "condition x income group")
    ) %>% mutate(measure = m)
  })) %>% mutate(study = s, .before = 1) %>% select(study, measure, model, term, df1, df2, F, p, partial_eta2)

  # Income groups: high minus low (two-tailed)
  income <- bind_rows(lapply(measures$measure, function(m) {
    group_test(d[[m]][d$income_group == "High"], d[[m]][d$income_group == "Low"]) %>% mutate(measure = m)
  })) %>% rename(n_high_income = n_x, n_low_income = n_y, m_high_income = m_x, sd_high_income = sd_x, m_low_income = m_y, sd_low_income = sd_y) %>%
    mutate(study = s, .before = 1)

  # Preregistered contrasts (Tables 2 to 6)
  contrasts <- bind_rows(lapply(seq_len(nrow(comps)), function(i) {
    cp <- comps[i, ]
    bind_rows(lapply(seq_len(nrow(measures)), function(j) {
      m <- measures$measure[j]; dir <- measures$direction[j]
      all  <- contrast_test(d, m, cp$high, cp$low, dir)
      low  <- contrast_test(d[d$income_group == "Low", ],  m, cp$high, cp$low, dir)
      high <- contrast_test(d[d$income_group == "High", ], m, cp$high, cp$low, dir)
      int  <- interaction_test(d, m, cp$high, cp$low, dir)
      bind_rows(mutate(all, sample = "All"), mutate(low, sample = "Low income"), mutate(high, sample = "High income")) %>%
        mutate(study = s, technique = cp$technique, high_condition = cp$high, low_condition = cp$low,
               measure = m, measure_label = measures$label[j], direction = dir) %>%
        bind_cols(int[rep(1, 3), ])
    }))
  })) %>% select(study, technique, high_condition, low_condition, measure, measure_label, direction, sample, everything())

  # Paper-style table: d (one-tailed p) for All / Low / High and t (p) for the interaction
  table_ms <- contrasts %>%
    mutate(cell = sprintf("%s (%s)", fmt2(d), fmt_p(p_one_tailed))) %>%
    select(study, technique, measure_label, sample, cell, t_interaction, p_interaction_one_tailed, n_high, n_low) %>%
    pivot_wider(names_from = sample, values_from = c(cell, n_high, n_low)) %>%
    transmute(study, technique, n_high = n_high_All, n_low = n_low_All, measure = measure_label,
              all_participants = cell_All, low_income = `cell_Low income`, high_income = `cell_High income`,
              income_x_condition = sprintf("%s (%s)", fmt2(t_interaction), fmt_p(p_interaction_one_tailed)))

  # Study-specific checks
  extra <- NULL
  if (s == 1) {
    sc <- contrast_test(d, "scale_rating", "Scale high", "Scale low", "less")
    lot <- d %>% filter(technique == "Lottery") %>% group_by(condition) %>%
      summarise(pct_max_correct = 100 * mean(lottery_check_max_correct), pct_actual_correct = 100 * mean(lottery_check_actual_correct))
    extra <- list(scale_manipulation_check = sc, lottery_attention_checks = lot)
  }

  rel <- reliability_table(d, s)

  write_csv(descriptives, file.path(DIR_TABLES, sprintf("study%d_descriptives.csv", s)))
  write_csv(sample,       file.path(DIR_TABLES, sprintf("study%d_sample.csv", s)))
  write_csv(rel,          file.path(DIR_TABLES, sprintf("study%d_reliability.csv", s)))
  write_csv(anovas,       file.path(DIR_TABLES, sprintf("study%d_anova.csv", s)))
  write_csv(income,       file.path(DIR_TABLES, sprintf("study%d_income_groups.csv", s)))
  write_csv(contrasts,    file.path(DIR_TABLES, sprintf("study%d_contrasts.csv", s)))
  write_csv(table_ms,     file.path(DIR_TABLES, sprintf("study%d_table.csv", s)))
  if (!is.null(extra)) for (nm in names(extra)) write_csv(extra[[nm]], file.path(DIR_TABLES, sprintf("study%d_%s.csv", s, nm)))

  cat(sprintf("\n==================== Study %d (N = %d) ====================\n", s, nrow(d)))
  cat("Reliability:\n"); print(as.data.frame(rel[, c("scale", "k_items", "alpha")]), digits = 3)
  cat("\nANOVAs (Type III):\n"); print(as.data.frame(anovas %>% mutate(across(c(F, partial_eta2), ~round(.x, 3)), p = fmt_p(p)) %>% select(-study)), row.names = FALSE)
  cat("\nIncome groups (high minus low):\n"); print(as.data.frame(income %>% mutate(across(where(is.numeric), ~round(.x, 3))) %>% select(measure, m_high_income, m_low_income, t, df, p, d)), row.names = FALSE)
  cat("\nHigh- versus low-scarcity contrasts (d with one-tailed p; interaction t with one-tailed p):\n")
  print(as.data.frame(table_ms %>% select(-study)), row.names = FALSE)
  if (!is.null(extra)) { cat("\nStudy-specific checks:\n"); print(extra) }

  list(contrasts = contrasts, anovas = anovas, income = income, reliability = rel, sample = sample)
}

results <- lapply(1:5, run_study)
all_contrasts <- bind_rows(lapply(results, `[[`, "contrasts"))
write_csv(all_contrasts, file.path(DIR_TABLES, "all_contrasts.csv"))
write_csv(bind_rows(lapply(results, `[[`, "anovas")),      file.path(DIR_TABLES, "all_anovas.csv"))
write_csv(bind_rows(lapply(results, `[[`, "income")),      file.path(DIR_TABLES, "all_income_groups.csv"))
write_csv(bind_rows(lapply(results, `[[`, "reliability")), file.path(DIR_TABLES, "all_reliability.csv"))
write_csv(bind_rows(lapply(results, `[[`, "sample")),      file.path(DIR_TABLES, "all_samples.csv"))

# Recall completion across the four studies that used it (Limitations section):
# fewer participants completed the high- than the low-scarcity version.
rc <- all_contrasts %>% filter(technique == "Recall", measure == "concerns", sample == "All") %>% summarise(high = sum(n_high), low = sum(n_low))
bt <- binom.test(rc$high, rc$high + rc$low)
cat(sprintf("\nRecall completions, high vs low scarcity: %d vs %d, binomial p = %.3f\n", rc$high, rc$low, bt$p.value))
write_csv(tibble(n_recall_high = rc$high, n_recall_low = rc$low, binomial_p = bt$p.value), file.path(DIR_TABLES, "recall_completion_binomial.csv"))
