# =============================================================================
# run_all.R -- runs the complete R pipeline from the raw exports to the tables
# and figures. Run from the project root:   Rscript R/run_all.R
# (or open Analysis.Rproj in RStudio and source this file).
# =============================================================================
if (!dir.exists("R")) stop("Run from the project root (the folder containing R/ and data/).")
t0 <- Sys.time()
for (script in c("R/01_prepare_data.R", "R/02_study_analyses.R", "R/03_meta_analysis.R", "R/04_figures.R")) {
  cat("\n\n############################", script, "############################\n")
  source(script, echo = FALSE)
}
cat("\nFinished in", round(as.numeric(difftime(Sys.time(), t0, units = "mins")), 1), "minutes\n")
writeLines(capture.output(sessionInfo()), "output/checks/r_sessionInfo.txt")
