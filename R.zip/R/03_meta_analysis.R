# =============================================================================
# 03_meta_analysis.R -- meta-analyses of the 18 high- versus low-scarcity
# comparisons (paper section "Meta-Analysis", Tables 7 and 8, Figure 1)
#
# Follows the Method of the paper:
#   * Hedges' g (high minus low scarcity) with the small-sample correction, for
#     scarcity concerns, cognitive reflection (five items common to all
#     studies), fluid intelligence and the Reflection score, in the full sample
#     and within each income group
#   * covariance between effect sizes that share a low-scarcity group (generic
#     and COVID-19 pictures in Studies 2 to 4) via metafor::vcalc
#   * random-effects models with effect sizes nested in studies (REML, t tests
#     on k - p df); three-level models for income moderation; technique as a
#     categorical moderator for the techniques used in more than one study
#   * equivalence tests against g = +/-0.20; sensitivity analyses
#
# Output: output/tables/meta_*.csv
# =============================================================================

source("R/00_setup.R")

DATA <- lapply(1:5, read_processed)
names(DATA) <- 1:5

# ---- 1. effect sizes --------------------------------------------------------
# crs_var: "crs5" (five common items; main analyses) or "crs" (all items;
# sensitivity: six-item score for Study 1). income_var: the income split.
build_es <- function(crs_var = "crs5", income_var = "income_group") {
  rows <- list()
  for (i in seq_len(nrow(COMPARISONS))) {
    cp <- COMPARISONS[i, ]
    d  <- DATA[[cp$study]]
    d$inc <- d[[income_var]]
    for (m in c("concerns", "crs", "fis", "reflection")) {
      col <- if (m == "crs") crs_var else m
      if (!col %in% names(d)) next
      for (smp in c("All", "Low", "High")) {
        dd <- if (smp == "All") d else d[d$inc == smp, ]
        x <- dd[[col]][dd$condition == cp$high]; y <- dd[[col]][dd$condition == cp$low]
        g <- hedges_g(x, y)
        rows[[length(rows) + 1]] <- tibble(
          study = cp$study, technique = cp$technique, comparison_id = i,
          measure = m, sample = smp, yi = g$g, vi = g$vi, n_high = g$n1, n_low = g$n2,
          grp_high = cp$high, grp_low = cp$low)
      }
    }
  }
  bind_rows(rows) %>% mutate(row_id = row_number(), cluster = paste(study, sample),
                             income_group = factor(sample, levels = c("High", "Low", "All")))
}
ES <- build_es()
write_csv(ES, file.path(DIR_TABLES, "meta_effect_sizes.csv"))

# Variance-covariance matrix: effect sizes in the same study and sample that
# share their low-scarcity group (grp_low) are correlated (Gleser & Olkin, 2009).
make_V <- function(sub) {
  vcalc(vi, cluster = cluster, grp1 = grp_high, grp2 = grp_low, w1 = n_high, w2 = n_low, data = sub)
}

# ---- helpers ----------------------------------------------------------------
equivalence <- function(b, se, df, bound = 0.20) {
  p <- max(pt((b + bound) / se, df, lower.tail = FALSE), pt((b - bound) / se, df, lower.tail = TRUE))
  list(p_equiv = p, ci90_lb = b - qt(.95, df) * se, ci90_ub = b + qt(.95, df) * se)
}
i2_multilevel <- function(fit) {           # Higgins-type I2 for rma.mv (typical sampling variance)
  w <- 1 / diag(fit$V); k <- length(w)
  typical <- (k - 1) * sum(w) / (sum(w)^2 - sum(w^2))
  100 * sum(fit$sigma2) / (sum(fit$sigma2) + typical)
}
coef_row <- function(fit, name = 1) {
  i <- if (is.character(name)) which(rownames(fit$b) == name) else name
  tibble(estimate = fit$b[i], se = fit$se[i], ci_lb = fit$ci.lb[i], ci_ub = fit$ci.ub[i], t = fit$zval[i], df = fit$ddf[i], p = fit$pval[i])
}
fit_main <- function(sub) rma.mv(yi, make_V(sub), random = ~ 1 | study / row_id, data = sub, test = "t", method = "REML")
fit_income <- function(sub, mods) rma.mv(yi, make_V(sub), mods = mods, random = ~ 1 | study / comparison_id / row_id, data = sub, test = "t", method = "REML")
fmt_ci <- function(b, lb, ub) sprintf("%s [%s, %s]", fmt2(b), fmt2(lb), fmt2(ub))

# ---- 2. pooled effects (Table 7) --------------------------------------------
pooled_block <- function(es, m, label, exclude_study = NULL) {
  sub <- es %>% filter(measure == m, sample == "All", !(study %in% exclude_study))
  fit <- fit_main(sub)
  all <- coef_row(fit); eq <- equivalence(all$estimate, all$se, all$df)
  subI <- es %>% filter(measure == m, sample != "All", !(study %in% exclude_study)) %>% mutate(income_group = droplevels(income_group))
  fit_groups <- fit_income(subI, ~ 0 + income_group)         # pooled effect within each income group
  fit_diff   <- fit_income(subI, ~ income_group)             # b = low minus high income
  low <- coef_row(fit_groups, "income_groupLow"); high <- coef_row(fit_groups, "income_groupHigh"); diff <- coef_row(fit_diff, "income_groupLow")
  eq_low <- equivalence(low$estimate, low$se, low$df)
  tibble(measure = label, k = nrow(sub),
         g_all = all$estimate, ci_lb_all = all$ci_lb, ci_ub_all = all$ci_ub, p_all = all$p, df_all = all$df,
         p_equivalence_all = eq$p_equiv, ci90_lb_all = eq$ci90_lb, ci90_ub_all = eq$ci90_ub,
         g_low = low$estimate, ci_lb_low = low$ci_lb, ci_ub_low = low$ci_ub, p_low = low$p, p_equivalence_low = eq_low$p_equiv,
         g_high = high$estimate, ci_lb_high = high$ci_lb, ci_ub_high = high$ci_ub, p_high = high$p,
         b_low_minus_high = diff$estimate, ci_lb_diff = diff$ci_lb, ci_ub_diff = diff$ci_ub, p_diff = diff$p,
         Q = fit$QE, Q_df = fit$k - fit$p, Q_p = fit$QEp, I2 = i2_multilevel(fit),
         sigma2_study = fit$sigma2[1], sigma2_comparison = fit$sigma2[2],
         I2_single_level = rma(yi, vi, data = sub, method = "REML")$I2,
         cell_all = fmt_ci(all$estimate, all$ci_lb, all$ci_ub), cell_low = fmt_ci(low$estimate, low$ci_lb, low$ci_ub),
         cell_high = fmt_ci(high$estimate, high$ci_lb, high$ci_ub),
         cell_diff = sprintf("%s (%s)", fmt_ci(diff$estimate, diff$ci_lb, diff$ci_ub), fmt_p(diff$p)))
}
table7 <- bind_rows(
  pooled_block(ES, "concerns",   "Scarcity concerns, all studies"),
  pooled_block(ES, "concerns",   "Scarcity concerns, without Study 3", exclude_study = 3),
  pooled_block(ES, "crs",        "Cognitive reflection"),
  pooled_block(ES, "fis",        "Fluid intelligence"),
  pooled_block(ES, "reflection", "Reflection score")
)
write_csv(table7, file.path(DIR_TABLES, "meta_table7_pooled_effects.csv"))
cat("\n==== Table 7: pooled effects of high- versus low-scarcity manipulations (Hedges' g [95% CI]) ====\n")
print(as.data.frame(table7 %>% transmute(measure, k, all = cell_all, p = fmt_p(p_all), low = cell_low, high = cell_high, low_minus_high = cell_diff,
                                         I2 = sprintf("%.0f%%", I2), p_equiv = fmt_p(p_equivalence_all), ci90 = sprintf("[%.2f, %.2f]", ci90_lb_all, ci90_ub_all))), row.names = FALSE)

# Heterogeneity of the concerns model and the technique test without Study 3
sub <- ES %>% filter(measure == "concerns", sample == "All", study != 3)
fit_tech_concerns <- rma.mv(yi, make_V(sub), mods = ~ technique, random = ~ 1 | study / row_id, data = sub, test = "t")
cat(sprintf("\nConcerns without Study 3: techniques differ? F(%d, %d) = %.2f, p = %s\n", fit_tech_concerns$QMdf[1], fit_tech_concerns$QMdf[2], fit_tech_concerns$QM, fmt_p(fit_tech_concerns$QMp)))
fit_tech0 <- rma.mv(yi, make_V(sub), mods = ~ 0 + technique, random = ~ 1 | study / row_id, data = sub, test = "t")
sc <- coef_row(fit_tech0, "techniqueScale")
cat(sprintf("Scale task (Study 1 only) on concerns, model-based estimate: g = %.2f, 95%% CI [%.2f, %.2f]\n", sc$estimate, sc$ci_lb, sc$ci_ub))

# ---- 3. techniques used in more than one study (Table 8) --------------------
REPEATED <- c("Recall", "Scenario", "Generic pictures", "COVID-19 pictures")
technique_block <- function(es, m, label, exclude_study = NULL) {
  sub  <- es %>% filter(measure == m, sample == "All", !(study %in% exclude_study))
  fit  <- rma.mv(yi, make_V(sub), mods = ~ 0 + technique, random = ~ 1 | study / row_id, data = sub, test = "t")
  subI <- es %>% filter(measure == m, sample != "All", !(study %in% exclude_study)) %>%
    mutate(low_income = as.numeric(sample == "Low"), high_income = as.numeric(sample == "High"))
  fit_hi <- fit_income(subI, ~ 0 + technique + technique:low_income)    # technique = high-income effect; interaction = low - high
  fit_lo <- fit_income(subI, ~ 0 + technique + technique:high_income)   # technique = low-income effect
  # F test: do the repeated techniques differ from one another?
  present <- REPEATED[REPEATED %in% sub$technique]
  Lmat <- t(sapply(present[-1], function(tch) as.numeric(rownames(fit$b) == paste0("technique", present[1])) - as.numeric(rownames(fit$b) == paste0("technique", tch))))
  ftest <- anova(fit, X = Lmat)
  out <- bind_rows(lapply(present, function(tch) {
    a <- coef_row(fit, paste0("technique", tch)); eq <- equivalence(a$estimate, a$se, a$df)
    lo <- coef_row(fit_lo, paste0("technique", tch)); hi <- coef_row(fit_hi, paste0("technique", tch))
    df <- coef_row(fit_hi, paste0("technique", tch, ":low_income")); eq_lo <- equivalence(lo$estimate, lo$se, lo$df)
    tibble(technique = tch, measure = label, k = sum(sub$technique == tch),
           g_all = a$estimate, ci_lb_all = a$ci_lb, ci_ub_all = a$ci_ub, p_all = a$p, p_equivalence_all = eq$p_equiv,
           g_low = lo$estimate, ci_lb_low = lo$ci_lb, ci_ub_low = lo$ci_ub, p_low = lo$p, p_equivalence_low = eq_lo$p_equiv,
           g_high = hi$estimate, ci_lb_high = hi$ci_lb, ci_ub_high = hi$ci_ub, p_high = hi$p,
           b_low_minus_high = df$estimate, ci_lb_diff = df$ci_lb, ci_ub_diff = df$ci_ub, p_diff = df$p,
           techniques_differ_F = ftest$QM, F_df1 = ftest$QMdf[1], F_df2 = ftest$QMdf[2], techniques_differ_p = ftest$QMp,
           cell_all = fmt_ci(a$estimate, a$ci_lb, a$ci_ub), cell_low = fmt_ci(lo$estimate, lo$ci_lb, lo$ci_ub),
           cell_high = fmt_ci(hi$estimate, hi$ci_lb, hi$ci_ub), cell_diff = sprintf("%s (%s)", fmt_ci(df$estimate, df$ci_lb, df$ci_ub), fmt_p(df$p)))
  }))
  out
}
table8 <- bind_rows(
  technique_block(ES, "concerns",   "Scarcity concerns (without Study 3)", exclude_study = 3),
  technique_block(ES, "concerns",   "Scarcity concerns (all studies)"),
  technique_block(ES, "crs",        "Cognitive reflection"),
  technique_block(ES, "fis",        "Fluid intelligence"),
  technique_block(ES, "reflection", "Reflection score")
)
# Holm correction for the 12 low-income tests on cognitive outcomes
cog <- table8$measure %in% c("Cognitive reflection", "Fluid intelligence", "Reflection score")
table8$p_low_holm <- NA; table8$p_low_holm[cog] <- p.adjust(table8$p_low[cog], method = "holm")
write_csv(table8, file.path(DIR_TABLES, "meta_table8_techniques.csv"))
cat("\n==== Table 8: pooled effects of the techniques used in more than one study ====\n")
print(as.data.frame(table8 %>% arrange(technique) %>% transmute(technique, measure, k, all = cell_all, low = cell_low, high = cell_high, low_minus_high = cell_diff,
                                                                p_equiv_all = fmt_p(p_equivalence_all), p_low_holm = ifelse(is.na(p_low_holm), "", fmt_p(p_low_holm)),
                                                                techniques_differ = sprintf("F(%d, %d) = %.2f, p = %s", F_df1, F_df2, techniques_differ_F, fmt_p(techniques_differ_p)))), row.names = FALSE)

# Sensitivity: separate random-effects model per technique (t tests on k - 1 df)
# and a separate income model per technique (2k - 2 df)
sep <- bind_rows(lapply(REPEATED, function(tch) bind_rows(lapply(c("concerns", "crs", "fis", "reflection"), function(m) {
  sub <- ES %>% filter(technique == tch, measure == m, sample == "All", !(m == "concerns" & study == 3))
  if (nrow(sub) < 2) return(NULL)
  f <- rma(yi, vi, data = sub, method = "REML", test = "t")
  subI <- ES %>% filter(technique == tch, measure == m, sample != "All", !(m == "concerns" & study == 3)) %>% mutate(income_group = droplevels(income_group))
  fI <- rma.mv(yi, vi, mods = ~ income_group, random = ~ 1 | study / row_id, data = subI, test = "t")
  fL <- rma.mv(yi, vi, mods = ~ 0 + income_group, random = ~ 1 | study / row_id, data = subI, test = "t")
  tibble(technique = tch, measure = m, k = nrow(sub), g_all = f$b[1], ci_lb_all = f$ci.lb, ci_ub_all = f$ci.ub, p_all = f$pval, df_all = f$ddf,
         g_low = fL$b["income_groupLow", 1], ci_lb_low = fL$ci.lb[rownames(fL$b) == "income_groupLow"], ci_ub_low = fL$ci.ub[rownames(fL$b) == "income_groupLow"],
         p_low = fL$pval[rownames(fL$b) == "income_groupLow"],
         b_low_minus_high = fI$b["income_groupLow", 1], p_diff = fI$pval[rownames(fI$b) == "income_groupLow"], df_income_model = fI$ddf[1])
}))))
write_csv(sep, file.path(DIR_TABLES, "meta_table8_sensitivity_separate_models.csv"))

# ---- 4. manipulation strength -----------------------------------------------
# Comparisons whose manipulation check succeeded (one-tailed p < .05 on concerns in the full sample)
contr <- read_csv(file.path(DIR_TABLES, "all_contrasts.csv"), show_col_types = FALSE)
success <- contr %>% filter(measure == "concerns", sample == "All", p_one_tailed < .05) %>% select(study, technique)
cat(sprintf("\nComparisons with a successful manipulation check (k = %d): %s\n", nrow(success), paste(sprintf("%s (Study %d)", success$technique, success$study), collapse = "; ")))
succ <- bind_rows(lapply(c("crs", "reflection"), function(m) {
  sub <- ES %>% filter(measure == m, sample == "All") %>% semi_join(success, by = c("study", "technique"))
  f <- fit_main(sub); a <- coef_row(f)
  subI <- ES %>% filter(measure == m, sample != "All") %>% semi_join(success, by = c("study", "technique")) %>% mutate(income_group = droplevels(income_group))
  fL <- fit_income(subI, ~ 0 + income_group); lo <- coef_row(fL, "income_groupLow")
  tibble(measure = m, k = nrow(sub), g_all = a$estimate, ci_lb_all = a$ci_lb, ci_ub_all = a$ci_ub, p_all = a$p,
         g_low = lo$estimate, ci_lb_low = lo$ci_lb, ci_ub_low = lo$ci_ub, p_low = lo$p)
}))
write_csv(succ, file.path(DIR_TABLES, "meta_successful_manipulation_subset.csv"))
cat("Pooled cognitive effects in that subset:\n"); print(as.data.frame(succ %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)

# Meta-regression: effect on cognition as a function of the effect on concerns
conc <- ES %>% filter(measure == "concerns", sample == "All") %>% select(study, technique, g_concerns = yi)
mreg <- bind_rows(lapply(c("crs", "reflection"), function(m) bind_rows(lapply(c(FALSE, TRUE), function(drop3) {
  sub <- ES %>% filter(measure == m, sample == "All", !(drop3 & study == 3)) %>% inner_join(conc, by = c("study", "technique"))
  f <- rma.mv(yi, make_V(sub), mods = ~ g_concerns, random = ~ 1 | study / row_id, data = sub, test = "t")
  tibble(measure = m, without_study3 = drop3, k = nrow(sub), b = f$b[2], ci_lb = f$ci.lb[2], ci_ub = f$ci.ub[2], p = f$pval[2])
}))))
write_csv(mreg, file.path(DIR_TABLES, "meta_regression_concerns_on_cognition.csv"))
cat("\nMeta-regression slopes (cognitive effect on concerns effect):\n"); print(as.data.frame(mreg %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)

# ---- 5. sensitivity analyses ------------------------------------------------
# (a) leave one study out
loo <- bind_rows(lapply(c("crs", "reflection"), function(m) bind_rows(lapply(1:5, function(s) {
  sub <- ES %>% filter(measure == m, sample == "All", study != s); if (nrow(sub) == 0) return(NULL)
  f <- fit_main(sub); tibble(measure = m, study_left_out = s, k = nrow(sub), g = f$b[1], ci_lb = f$ci.lb, ci_ub = f$ci.ub, p = f$pval)
}))))
write_csv(loo, file.path(DIR_TABLES, "meta_leave_one_study_out.csv"))
cat("\nLeave-one-study-out (pooled g):\n"); print(as.data.frame(loo %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)

# (b) six-item cognitive reflection score for Study 1
ES6 <- build_es(crs_var = "crs")
f6 <- fit_main(ES6 %>% filter(measure == "crs", sample == "All"))
cat(sprintf("\nSix-item Study 1 score: cognitive reflection g = %.3f [%.3f, %.3f]\n", f6$b[1], f6$ci.lb, f6$ci.ub))

# (c) single-level random-effects models with Knapp-Hartung tests
kh <- bind_rows(lapply(c("concerns", "crs", "fis", "reflection"), function(m) {
  sub <- ES %>% filter(measure == m, sample == "All"); f <- rma(yi, vi, data = sub, method = "REML", test = "knha")
  tibble(measure = m, k = nrow(sub), g = f$b[1], ci_lb = f$ci.lb, ci_ub = f$ci.ub, p = f$pval, I2 = f$I2, tau2 = f$tau2)
}))
write_csv(kh, file.path(DIR_TABLES, "meta_single_level_knapp_hartung.csv"))
cat("\nSingle-level models (Knapp-Hartung):\n"); print(as.data.frame(kh %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)

# (d) participants at the median assigned to the low-income group
ES_alt <- build_es(income_var = "income_group_ties_low")
alt <- bind_rows(lapply(c("crs", "fis", "reflection"), function(m) {
  subI <- ES_alt %>% filter(measure == m, sample != "All") %>% mutate(income_group = droplevels(income_group))
  fd <- fit_income(subI, ~ income_group); fl <- fit_income(subI, ~ 0 + income_group)
  tibble(measure = m, g_low = fl$b["income_groupLow", 1], p_low = fl$pval[rownames(fl$b) == "income_groupLow"],
         b_low_minus_high = fd$b["income_groupLow", 1], ci_lb = fd$ci.lb[2], ci_ub = fd$ci.ub[2], p_diff = fd$pval[2])
}))
write_csv(alt, file.path(DIR_TABLES, "meta_income_ties_to_low.csv"))
cat("\nIncome moderation with participants at the median in the low-income group:\n"); print(as.data.frame(alt %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)
# ... and the per-study tests: how many of the 192 within-income-group tests change significance?
recompute_income_tests <- function(income_var) {
  bind_rows(lapply(1:5, function(s) {
    d <- DATA[[s]]; d$income_group <- factor(d[[income_var]], levels = c("Low", "High"))
    comps <- COMPARISONS %>% filter(study == s); ms <- MEASURES %>% filter(measure %in% names(d))
    bind_rows(lapply(seq_len(nrow(comps)), function(i) bind_rows(lapply(seq_len(nrow(ms)), function(j) {
      cp <- comps[i, ]; m <- ms$measure[j]; dir <- ms$direction[j]
      tibble(study = s, technique = cp$technique, measure = m,
             p_low = contrast_test(d[d$income_group == "Low", ], m, cp$high, cp$low, dir)$p_one_tailed,
             p_high = contrast_test(d[d$income_group == "High", ], m, cp$high, cp$low, dir)$p_one_tailed,
             p_int = interaction_test(d, m, cp$high, cp$low, dir)$p_interaction_one_tailed)
    }))))
  }))
}
t_main <- recompute_income_tests("income_group"); t_alt <- recompute_income_tests("income_group_ties_low")
changed <- (t_main[, c("p_low", "p_high", "p_int")] < .05) != (t_alt[, c("p_low", "p_high", "p_int")] < .05)
cat(sprintf("Within-study tests by income group whose significance changes with the alternative split: %d of %d\n", sum(changed), length(changed)))
chg <- bind_cols(t_main[, c("study", "technique", "measure")], as_tibble(changed) %>% rename_with(~paste0(.x, "_changed")),
                 t_main[, c("p_low", "p_high", "p_int")], t_alt[, c("p_low", "p_high", "p_int")] %>% rename_with(~paste0(.x, "_ties_low")))
write_csv(chg, file.path(DIR_TABLES, "meta_income_ties_to_low_per_study_tests.csv"))

# (e) the 96 one-tailed tests on cognitive reflection and fluid intelligence
cog_tests <- contr %>% filter(measure %in% c("crs", "fis"))
cat(sprintf("One-tailed tests on cognitive reflection and fluid intelligence: %d of %d significant in the predicted direction (%.1f%%)\n",
            sum(cog_tests$p_one_tailed < .05), nrow(cog_tests), 100 * mean(cog_tests$p_one_tailed < .05)))

# (f) The paper's analyses without the repeat participants of Studies 4
#     and 5 are not part of this package: the exports do not identify them
#     (see REPLICATION_REPORT.md).
cat("Analyses without repeat participants: not reproduced (repeat participants are not identified in the exports).\n")

# ---- 6. income and cognition, pooled across studies -------------------------
inc_es <- bind_rows(lapply(1:5, function(s) {
  d <- DATA[[s]]
  bind_rows(lapply(c("concerns", "crs5", "fis", "reflection"), function(m) {
    if (!m %in% names(d)) return(NULL)
    g <- hedges_g(d[[m]][d$income_group == "High"], d[[m]][d$income_group == "Low"])
    tibble(study = s, measure = ifelse(m == "crs5", "crs", m), yi = g$g, vi = g$vi)
  }))
}))
inc_pooled <- bind_rows(lapply(c("concerns", "crs", "fis", "reflection"), function(m) {
  f <- rma(yi, vi, data = inc_es %>% filter(measure == m), method = "REML", test = "knha")
  tibble(measure = m, k = f$k, g_high_minus_low_income = f$b[1], ci_lb = f$ci.lb, ci_ub = f$ci.ub, p = f$pval, I2 = f$I2)
}))
write_csv(inc_es, file.path(DIR_TABLES, "meta_income_group_effect_sizes.csv"))
write_csv(inc_pooled, file.path(DIR_TABLES, "meta_income_and_cognition.csv"))
cat("\nIncome groups pooled across studies (high minus low income, Hedges' g):\n"); print(as.data.frame(inc_pooled %>% mutate(across(where(is.numeric), ~round(.x, 3)))), row.names = FALSE)

# ---- 7. save pooled estimates for the forest plot ---------------------------
fig <- ES %>% filter(measure == "reflection", sample %in% c("All", "Low")) %>%
  mutate(ci_lb = yi - qnorm(.975) * sqrt(vi), ci_ub = yi + qnorm(.975) * sqrt(vi))
write_csv(fig, file.path(DIR_TABLES, "meta_figure1_effect_sizes.csv"))
write_csv(table7 %>% filter(measure == "Reflection score") %>% select(g_all, ci_lb_all, ci_ub_all, g_low, ci_lb_low, ci_ub_low),
          file.path(DIR_TABLES, "meta_figure1_pooled.csv"))
cat("\nDone. Tables written to", DIR_TABLES, "\n")
