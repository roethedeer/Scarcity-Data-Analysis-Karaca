"""
Does Scarcity Impede Cognitive Function? Five Preregistered Experiments
Analysis code (Python) -- prepare_data.py

Builds the analysis data sets from the raw survey exports (St1.csv ... St5.csv).
Mirrors R/01_prepare_data.R step for step; the two implementations must produce
identical processed files (checked by python/compare_r_python.py).

Run from the project root:  python3 python/prepare_data.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from setup import (DIR_PROCESSED, DIR_CHECKS, DIR_RAW, CONDITION_MAP, INCOME_MIDPOINT, US_INCOME_LABELS,
                   AGREE7, EDUCATION_LABELS_US, KEY_NUMERIC, KEY_TEXT_STUDY3, FINLIT_KEY,
                   PANAS_POSITIVE, PANAS_NEGATIVE, FIRST_COLS)


def num(x):
    return pd.to_numeric(x, errors="coerce")


# Prolific demographic export: missing-value markers become NA; the mojibake of
# the income brackets (pound sign and dash) is repaired.
PROLIFIC_MISSING = {"", "0", "DATA EXPIRED", "DATA_EXPIRED", "CONSENT REVOKED", "CONSENT_REVOKED"}


def pro(x):
    x = x.fillna("").astype(str).str.strip()
    return x.where(~x.isin(PROLIFIC_MISSING), np.nan)


def fix_enc(x):
    return x.fillna("").astype(str).str.replace("\u00c2\u00a3", "\u00a3", regex=False).str.replace("\u00e2\u20ac\u201c", "\u2013", regex=False)


def prolific_fields(r, age, sex, gender, birth, residence, nationality, first_language, fluent, employment, student, income=None, ethnicity=None):
    out = {"prolific_age": num(age), "prolific_sex": pro(sex), "prolific_gender_identity": pro(gender)}
    if ethnicity is not None:
        out["prolific_ethnicity"] = pro(ethnicity)
    out.update({"prolific_country_of_birth": pro(birth), "prolific_country_of_residence": pro(residence), "prolific_nationality": pro(nationality),
                "prolific_first_language": pro(first_language), "prolific_fluent_languages": pro(fluent),
                "prolific_employment_status": pro(employment), "prolific_student_status": pro(student)})
    if income is not None:
        out["prolific_household_income"] = pro(fix_enc(income))
    return out


def read_raw(study):
    return pd.read_csv(DIR_RAW / f"St{study}.csv", dtype=str, keep_default_na=False, na_values=[""], encoding="utf-8-sig")


def finlit(r, cols):
    return sum((num(r[c]) == FINLIT_KEY[k]).astype(float) for k, c in enumerate(cols))


# ---- per-study extraction ---------------------------------------------------

def prep_study1():
    r = read_raw(1)
    d = pd.DataFrame({
        "study": 1, "id": num(r["ID"]).astype(int), "treatment_raw": r["Treatment"],
        **{f"fcs_{k}": num(r[f"FCS_{k}"]) for k in range(1, 6)},
        "crt1_response": num(r["Q1_CRT1"]), "crt2_response": num(r["Q2_CRT2"]), "crt3_response": num(r["Q3_CRT3"]),
        "belief_bias_response": num(r["Q4_Belief_Bias"]), "base_rate_response": num(r["Q5_Base_rate_neglect"]),
        "conjunction_response": num(r["Q6_Conjunction_Fall"]),
        "income_bracket": num(r["Household_income"]), "household_size": num(r["Household_size"]),
        "age": num(r["Age"]), "gender": num(r["Gender"]), "education": num(r["Education"]), "uk_us_resident": num(r["Residency"]),
        "measure_order": np.where(r["Order_FCS_First"] == "Financialconcernsscale|CognitivePerformanceQs", "Concerns first", "Cognitive test first"),
        "scale_rating": num(r["Nelson_S2_Prime"]).fillna(num(r["Nelson_S2_Control"])),
        "lottery_check_max_correct": np.select([r["Treatment"] == "Manipulation_Lottery", r["Treatment"] == "Control_Lottery"],
                                               [(num(r["Bonus_M_AC_Q1"]) == 2).astype(float), (num(r["Bonus_C_AC_Q1"]) == 2).astype(float)], np.nan),
        "lottery_check_actual_correct": np.select([r["Treatment"] == "Manipulation_Lottery", r["Treatment"] == "Control_Lottery"],
                                                  [(num(r["Bonus_M_AC_Q2"]) == 1).astype(float), (num(r["Bonus_C_AC_Q2"]) == 2).astype(float)], np.nan),
        "panas_positive": sum(num(r[v]) for v in PANAS_POSITIVE), "panas_negative": sum(num(r[v]) for v in PANAS_NEGATIVE),
        "finlit_score": finlit(r, [f"FinLit_Test_{k}" for k in range(1, 6)]), "finlit_self_rating": num(r["Fin_lit_perception"]),
        "duration_seconds": num(r["Duration"]),
        "spss_concerns": num(r["FCS_total"]), "spss_crs": num(r["CPT_total"]), "spss_effective_income": num(r["Income_shah"]),
        "spss_income_group": num(r["gr_income"]), "spss_condition_code": num(r["Condition"]),
        "spss_panas_positive": num(r["Positive_Affect"]), "spss_panas_negative": num(r["Negative_Affect"]), "spss_finlit": num(r["FLS"]),
    })
    return d


def _common_2_4(r, study, gender_col, affect=None, oc_rel="OC_Relative"):
    d = pd.DataFrame({
        "study": study, "id": num(r["ID"]).astype(int), "treatment_raw": r["Treatment"],
        "crt1_response": num(r["Q1_CRT1"]), "crt2_response": num(r["Q2_CRT2"]), "crt3_response": num(r["Q3_CRT3"]),
        "belief_bias_response": num(r["Q4_Belief_Bias"]), "conjunction_response": num(r["Q5_Conjunction_Fall"]),
        "raven_e6_response": num(r["E6"]), "raven_e8_response": num(r["E8"]), "raven_e9_response": num(r["E9"]),
        "income_bracket": num(r["Household_income"]), "household_size": num(r["Household_size"]),
        "age": num(r["Age"]), "gender": num(r[gender_col]), "education": num(r["Education"]), "uk_us_resident": num(r["Residency"]),
    })
    if study == 2:
        d["panas_positive"] = sum(num(r[v]) for v in PANAS_POSITIVE)
        d["panas_negative"] = sum(num(r[v]) for v in PANAS_NEGATIVE)
    else:
        d["affect_arousal"] = num(r["Q1_1"]); d["affect_pleasure"] = num(r["Q2_1"])
    d["finlit_score"] = finlit(r, [f"F{k}" for k in range(1, 6)])
    d["finlit_self_estimate"] = num(r["OC_Absolute"]); d["finlit_relative_estimate"] = num(r[oc_rel])
    d["sleep_hours"] = num(r["Sleep"]); d["hours_since_meal"] = num(r["Hunger"])
    d["covid_diagnosed"] = num(r["Self_Diagnosis"]); d["covid_risk_1"] = num(r["Risk_perception_1"]); d["covid_risk_2"] = num(r["Risk_perception_2"])
    d["ideology"] = num(r["Ideology"]); d["religiosity"] = num(r["Religiosity"])
    d["duration_seconds"] = num(r["Duration_in_seconds"])
    if study == 4:
        d["finished"] = num(r["Finished"])
    for k, v in prolific_fields(r, r["KB" if study == 2 else "KH"], r["Sex"], r["Gender_identity"], r["Country_of_Birth"], r["Current_Country_of_Residence"],
                                r["Nationality"], r["First_Language"], r["Fluent_languages"], r["Employment_Status"], r["Student_Status"],
                                income=r["Household_Income_GBP" if study == 2 else "Household_Income_USD_US_parti"]).items():
        d[k] = v
    d["spss_concerns"] = num(r["FCS_total"]); d["spss_crs"] = num(r["CPT_total"]); d["spss_fis"] = num(r["Raven"]); d["spss_reflection"] = num(r["Reflection"])
    d["spss_effective_income"] = num(r["Income_shah"]); d["spss_income_group"] = num(r["gr_income"]); d["spss_condition_code"] = num(r["Condition"])
    if study == 2:
        d["spss_panas_positive"] = num(r["Positive_Affect"]); d["spss_panas_negative"] = num(r["Negative_Affect"])
    d["spss_finlit"] = num(r["FLS"])
    for k in range(1, 16):
        d[f"fcq_{k}"] = num(r[f"FCS_{k}"])
    return d


def prep_study2():
    return _common_2_4(read_raw(2), 2, "Gender")


def prep_study4():
    return _common_2_4(read_raw(4), 4, "gender", oc_rel="OC_Relative_12")


def prep_study3():
    r = read_raw(3)
    idx = lambda s, labels: s.map({lab: i + 1 for i, lab in enumerate(labels)}).astype(float)
    d = pd.DataFrame({
        "study": 3, "id": num(r["ID"]).astype(int), "treatment_raw": r["Treatment"],
        **{f"scs_{k}": idx(r[f"SCS_{k}"], AGREE7) for k in range(1, 5)},
        "crt1_response_text": r["Q1_CRT1"], "crt2_response_text": r["Q2_CRT2"], "crt3_response_text": r["Q3_CRT3"],
        "belief_bias_response_text": r["Q4_Belief_Bias"], "conjunction_response_text": r["Q5_Conjunction_Fall"],
        "raven_e6_response": num(r["E6"]), "raven_e8_response": num(r["E8"]), "raven_e9_response": num(r["E9"]),
        "income_bracket": idx(r["Household_income"], US_INCOME_LABELS), "household_size": num(r["Household_size_s"]),
        "age": num(r["Age"]), "gender": idx(r["gender"], ["Female", "Male", "Other"]),
        "education": idx(r["Education"], EDUCATION_LABELS_US),
        "uk_us_resident": np.where(r["Residency"] == "No", 2.0, 1.0),
        "affect_arousal": num(r["AQ1_Arousal"]), "affect_pleasure": num(r["AQ2_Pleasure"]),
        "sleep_hours": num(r["Sleep"]), "hours_since_meal": np.where(r["Hunger"] == "More than 10", 11.0, num(r["Hunger"])),
        "covid_diagnosed": np.where(r["Self_Diagnosis"] == "Yes", 1.0, 2.0),
        "covid_risk_1": num(r["Risk_perception_1"]), "covid_risk_2": num(r["Risk_perception_2"]),
        "duration_seconds": num(r["Duration_in_seconds"]),
        **prolific_fields(r, r["@GE"], r["Sex"], r["Gender_identity"], r["Country_of_Birth"], r["Current_Country_of_Residence"], r["Nationality"],
                          r["First_Language"], r["Fluent_languages"], r["Employment_Status"], r["Student_Status"]),
        "spss_concerns": num(r["SCS_total"]), "spss_crs": num(r["CPT_total"]), "spss_fis": num(r["Raven"]), "spss_reflection": num(r["Reflection"]),
        "spss_effective_income": num(r["Income_shah"]), "spss_income_group": num(r["gr_income"]), "spss_condition_code": num(r["Condition"]),
    })
    return d


def prep_study5():
    r = read_raw(5)
    # Two Prolific export formats are mixed in this file: where "Approvalrate"
    # is numeric every field sits under its own header (screened pools,
    # September 2022); otherwise the export lacked the "Total rejections" and
    # "Approval rate" fields and every demographic value sits two columns to
    # the left (full-income-range pool, November 2022).
    layout_a = r["Approvalrate"].str.match(r"^[0-9]+$").fillna(False).to_numpy()
    pick = lambda a, b: pd.Series(np.where(layout_a, r[a], r[b]), index=r.index)
    d = pd.DataFrame({
        "study": 5, "id": np.arange(1, len(r) + 1),      # the ID column of the Study 5 export is empty
        "treatment_raw": r["Treatment"],
        "crt1_response": num(r["Q1CRT1"]), "crt2_response": num(r["Q2CRT2"]), "crt3_response": num(r["Q3CRT3"]),
        "belief_bias_response": num(r["Q4BeliefBias"]), "conjunction_response": num(r["Q5ConjunctionFall"]),
        "raven_e6_response": num(r["E6"]), "raven_e8_response": num(r["E8"]), "raven_e9_response": num(r["E9"]),
        "income_bracket": num(r["Income"]), "household_size": num(r["Household"]),
        "age": num(r["age"]), "gender": num(r["gender"]), "education": num(r["Education"]), "uk_us_resident": num(r["Residency"]),
        "affect_arousal": num(r["Q1_1"]), "affect_pleasure": num(r["Q2_1"]),
        "sleep_hours": num(r["Sleep"]), "hours_since_meal": num(r["Hunger"]),
        "covid_diagnosed": num(r["SelfDiagnosis"]), "covid_risk_1": num(r["Riskperception_1"]), "covid_risk_2": num(r["Riskperception_2"]),
        "ideology": num(r["Ideology"]), "religiosity": num(r["Religiosity"]),
        "sample_pool": np.where(num(r["PART"]) == 1, "Screened income pools", "Full income range"),
        "duration_seconds": num(r["Durationinseconds"]), "finished": num(r["Finished"]),
        **prolific_fields(r, pick("Age_A", "Fluentlanguages"), pick("Sex", "Householdincomeusdusparti"), pick("Genderidentity", "Totalrejections"),
                          pick("Countryofbirth", "Sex"), pick("Countryofresidence", "Ethnicitysimplified"), pick("Nationality", "Countryofbirth"),
                          pick("Language", "Countryofresidence"), pick("Fluentlanguages", "Approvalrate"), pick("Employmentstatus", "Language"),
                          pick("Studentstatus", "Nationality"), income=pick("Householdincomeusdusparti", "Genderidentity"), ethnicity=pick("Ethnicitysimplified", "Age_A")),
        "spss_concerns": num(r["FCS_total"]), "spss_crs": num(r["CPT_total"]), "spss_fis": num(r["Raven"]),
        "spss_effective_income": num(r["Income_shah"]), "spss_income_group": num(r["gr_income"]), "spss_condition_code": num(r["Condition"]),
    })
    for k in range(1, 16):
        d[f"fcq_{k}"] = num(r[f"FCS_{k}"])
    return d


# ---- scoring (identical for every study) ------------------------------------

def score_study(d):
    s = int(d["study"].iloc[0])
    d["condition"] = d["treatment_raw"].map(CONDITION_MAP[s])
    assert d["condition"].notna().all(), "unmapped condition label"
    d["technique"] = np.where(d["condition"] == "Passive control", "Control", d["condition"].str.replace(r" (high|low)$", "", regex=True))
    d["scarcity"] = np.select([d["condition"].str.endswith(" high"), d["condition"].str.endswith(" low")], ["High", "Low"], "Control")

    if s == 3:
        for item in ["crt1", "crt2", "crt3", "belief_bias", "conjunction"]:
            d[f"{item}_correct"] = (d[f"{item}_response_text"] == KEY_TEXT_STUDY3[item]).astype(float)
    else:
        for item in ["crt1", "crt2", "crt3", "belief_bias", "conjunction"]:
            d[f"{item}_correct"] = (d[f"{item}_response"] == KEY_NUMERIC[item]).astype(float)
        if s == 1:
            d["base_rate_correct"] = (d["base_rate_response"] == KEY_NUMERIC["base_rate"]).astype(float)
    d["crs5"] = d[["crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "conjunction_correct"]].sum(axis=1)
    d["crs"] = d["crs5"] + d["base_rate_correct"] if s == 1 else d["crs5"]
    if s >= 2:
        for item in ["raven_e6", "raven_e8", "raven_e9"]:
            d[f"{item}_correct"] = (d[f"{item}_response"] == KEY_NUMERIC[item]).astype(float)
        d["fis"] = d[["raven_e6_correct", "raven_e8_correct", "raven_e9_correct"]].sum(axis=1)
        d["reflection"] = d["crs"] + d["fis"]

    if s == 1:
        d["concerns"] = (8 - d["fcs_1"]) + (8 - d["fcs_2"]) + d["fcs_3"] + (8 - d["fcs_4"]) + d["fcs_5"]
    elif s == 3:
        d["concerns"] = d[[f"scs_{k}" for k in range(1, 5)]].sum(axis=1)
    else:
        rev = {1, 2, 4, 7, 8, 13}
        d["concerns"] = sum((8 - d[f"fcq_{k}"]) if k in rev else d[f"fcq_{k}"] for k in range(1, 16))

    d["income_midpoint"] = d["income_bracket"].map(lambda b: INCOME_MIDPOINT[int(b) - 1])
    d["effective_income"] = d["income_midpoint"] / np.sqrt(d["household_size"])
    med = d["effective_income"].median()
    d["income_group"] = np.where(d["effective_income"] >= med, "High", "Low")
    d["income_group_ties_low"] = np.where(d["effective_income"] > med, "High", "Low")
    d.attrs["income_median"] = med
    return d


# ---- verification against the SPSS-derived columns --------------------------

def verify_study(d):
    s = int(d["study"].iloc[0])
    rows = []

    def chk(name, a, b, tol=1e-6):
        a, b = a.astype(float), b.astype(float)
        both_na = a.isna() & b.isna()
        mism = ~both_na & (a.isna() | b.isna() | ((a - b).abs() > tol))
        rows.append(dict(study=s, variable=name, n=int((a.notna() | b.notna()).sum()), n_mismatch=int(mism.sum())))

    chk("concerns", d["concerns"], d["spss_concerns"])
    chk("crs", d["crs"], d["spss_crs"])
    chk("effective_income", d["effective_income"], d["spss_effective_income"], tol=0.01)
    chk("income_group", (d["income_group"] == "High").astype(float), d["spss_income_group"])
    if s >= 2:
        chk("fis", d["fis"], d["spss_fis"])
    if s in (2, 3, 4):
        chk("reflection", d["reflection"], d["spss_reflection"])
    if s in (1, 2):
        chk("panas_positive", d["panas_positive"], d["spss_panas_positive"])
        chk("panas_negative", d["panas_negative"], d["spss_panas_negative"])
    if s in (1, 2, 4):
        chk("finlit_score", d["finlit_score"], d["spss_finlit"])
    return pd.DataFrame(rows)


def order_columns(d):
    first = [c for c in FIRST_COLS if c in d.columns]
    return d[first + [c for c in d.columns if c not in first]]


def main():
    studies = [score_study(f()) for f in (prep_study1, prep_study2, prep_study3, prep_study4, prep_study5)]
    checks = pd.concat([verify_study(d) for d in studies], ignore_index=True)
    checks.to_csv(DIR_CHECKS / "derived_vs_spss_python.csv", index=False)
    print("Recomputed scores versus SPSS-derived scores (n_mismatch should be 0 everywhere):")
    print(checks.to_string(index=False))
    assert (checks["n_mismatch"] == 0).all(), "recomputed scores differ from the SPSS-derived scores"

    out = []
    for d in studies:
        s = int(d["study"].iloc[0])
        dd = order_columns(d.drop(columns=[c for c in d.columns if c.startswith("spss_")]))
        dd.to_csv(DIR_PROCESSED / f"study{s}_python.csv", index=False)
        counts = dd["condition"].value_counts().sort_index()
        print(f"Study {s}: N = {len(dd)}, income median = {d.attrs['income_median']:.2f}, conditions: "
              + "; ".join(f"{k} ({v})" for k, v in counts.items()))
        out.append(dd)
    all_studies = order_columns(pd.concat(out, ignore_index=True))
    all_studies.to_csv(DIR_PROCESSED / "all_studies_python.csv", index=False)
    print(f"All studies: N = {len(all_studies)} rows, {all_studies.shape[1]} columns")


if __name__ == "__main__":
    main()
