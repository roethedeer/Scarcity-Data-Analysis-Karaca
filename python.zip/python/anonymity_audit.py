"""
anonymity_audit.py -- checks the processed data for identifying information
and writes the public release of the data.

1. Scans every column of data/processed/*.csv for identifier patterns:
   Prolific-style IDs (24 hexadecimal characters), IPv4 addresses, e-mail
   addresses, URLs, coordinates, dates/time stamps, and long free text.
2. Writes data/public/study1.csv ... study5.csv and all_studies.csv: the same
   rows and variables, with the export's participant number replaced by a new
   sequential number assigned after a seeded random shuffle, so that neither
   the number nor the row order can be linked to the raw survey export.

Output: output/checks/anonymity_audit.csv, data/public/*.csv
Run from the project root:  python3 python/anonymity_audit.py
"""
import re

import numpy as np
import pandas as pd

from setup import PROJECT_ROOT, DIR_PROCESSED, DIR_CHECKS

PUBLIC = PROJECT_ROOT / "data" / "public"
PUBLIC.mkdir(parents=True, exist_ok=True)

PATTERNS = {
    "prolific_id_24hex": re.compile(r"^[0-9a-f]{24}$", re.I),
    "ipv4": re.compile(r"^\d{1,3}(\.\d{1,3}){3}$"),
    "email": re.compile(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", re.I),
    "url": re.compile(r"https?://", re.I),
    "timestamp": re.compile(r"\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}"),
    "coordinate_pair": re.compile(r"^-?\d{1,3}\.\d{3,},\s*-?\d{1,3}\.\d{3,}$"),
}
IDENTIFIERS_REMOVED = [
    "Prolific IDs (PROLIFIC_PID, Prolific_ID, participant_id and equivalents)", "IP addresses", "latitude and longitude",
    "Prolific demographic exports (sex, age, nationality, country of birth and residence, language, employment, student status, ethnicity)",
    "survey start, end and recording time stamps", "free-text answers from the recall, consequences, scenario and picture tasks",
    "open comments at the end of the survey", "Qualtrics response IDs, distribution channel and user language",
]

rows = []
for s in range(1, 6):
    d = pd.read_csv(DIR_PROCESSED / f"study{s}.csv", low_memory=False)
    for c in d.columns:
        col = d[c].dropna().astype(str)
        hits = {name: int(col.str.contains(p).sum()) if name in ("email", "url", "timestamp") else int(col.str.match(p).sum())
                for name, p in PATTERNS.items()}
        longest = int(col.str.len().max()) if len(col) else 0
        free_text = int((col.str.len() > 60).sum())
        rows.append(dict(study=s, column=c, n_distinct=int(d[c].nunique()), longest_value=longest, values_over_60_chars=free_text, **hits))
audit = pd.DataFrame(rows)
audit.to_csv(DIR_CHECKS / "anonymity_audit.csv", index=False)
flagged = audit[(audit[list(PATTERNS)].sum(axis=1) > 0) | (audit["values_over_60_chars"] > 0)]
print(f"Scanned {len(audit)} study-columns; columns with identifier patterns or free text: {len(flagged)}")
if len(flagged):
    print(flagged.to_string(index=False))

# ---- public release: renumbered, shuffled -----------------------------------
rng = np.random.default_rng(20261111)
public_all = []
for s in range(1, 6):
    d = pd.read_csv(DIR_PROCESSED / f"study{s}.csv", low_memory=False)
    d = d.iloc[rng.permutation(len(d))].reset_index(drop=True)
    d = d.drop(columns=["id"])
    d.insert(1, "participant", np.arange(1, len(d) + 1))
    d.to_csv(PUBLIC / f"study{s}.csv", index=False)
    public_all.append(d)
    print(f"public study{s}.csv: {len(d)} rows, {d.shape[1]} columns")
all_pub = pd.concat(public_all, ignore_index=True)
all_pub.to_csv(PUBLIC / "all_studies.csv", index=False)
print(f"public all_studies.csv: {len(all_pub)} rows, {all_pub.shape[1]} columns")

# the public files must give the same results: check a few sufficient statistics
for s in range(1, 6):
    a = pd.read_csv(DIR_PROCESSED / f"study{s}.csv", low_memory=False)
    b = pd.read_csv(PUBLIC / f"study{s}.csv", low_memory=False)
    for col in ["concerns", "crs", "effective_income"]:
        ga = a.groupby(["condition", "income_group"])[col].agg(["mean", "std", "size"]).sort_index()
        gb = b.groupby(["condition", "income_group"])[col].agg(["mean", "std", "size"]).sort_index()
        assert np.allclose(ga.to_numpy(float), gb.to_numpy(float)), (s, col)
print("Public files reproduce the cell means, SDs and sizes of the processed files.")
