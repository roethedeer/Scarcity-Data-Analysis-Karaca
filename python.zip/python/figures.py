"""
figures.py -- figures, Python version (matplotlib). Mirrors R/04_figures.R.

Requires the tables written by study_analyses.py and meta_analysis.py.
Run from the project root:  python3 python/figures.py
"""
import subprocess

import numpy as np
import pandas as pd

# matplotlib lists macOS fonts through `system_profiler`, which fails in some
# shells (KeyError '_items'); skip that call and use the standard font folders.
_check_output = subprocess.check_output
subprocess.check_output = lambda cmd, *a, **k: (_ for _ in ()).throw(OSError("skipped")) if cmd and cmd[0] == "system_profiler" else _check_output(cmd, *a, **k)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
subprocess.check_output = _check_output
from scipy import stats

from setup import DIR_TABLES, DIR_FIGURES, read_processed

COL_ALL, COL_LOW, COL_MID = "#2a78d6", "#eb6834", "#52514e"
MEASURE_LABELS = {"concerns": "Scarcity concerns", "crs": "Cognitive reflection", "fis": "Fluid intelligence", "reflection": "Reflection score"}
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.spines.left": False,
                     "axes.edgecolor": "#888888", "axes.grid": True, "grid.color": "#e3e3e3", "grid.linewidth": 0.4,
                     "axes.axisbelow": True, "text.color": "#0b0b0b", "axes.labelcolor": "#0b0b0b"})


def save(fig, name):
    fig.savefig(DIR_FIGURES / f"{name}_python.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(DIR_FIGURES / f"{name}_python.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def forest(ax, labels, est, lb, ub, color, pooled=None, equivalence=True, marker_size=22):
    y = np.arange(len(labels))[::-1]
    if equivalence:
        ax.axvspan(-0.2, 0.2, color="#efefef", zorder=0)
        for b in (-0.2, 0.2):
            ax.axvline(b, color=COL_MID, linestyle="--", linewidth=0.7, zorder=1)
    ax.axvline(0, color=COL_MID, linewidth=0.9, zorder=1)
    ax.hlines(y, lb, ub, color=color, linewidth=1.2, zorder=2)
    ax.scatter(est, y, s=marker_size, color=color, zorder=3)
    if pooled is not None:
        g, l, u = pooled
        ax.fill([l, g, u, g], [-1.0, -0.65, -1.0, -1.35], color=COL_MID, zorder=3)
        ax.set_ylim(-1.8, len(labels) - 0.4)
    ax.set_yticks(y); ax.set_yticklabels(labels)
    ax.grid(axis="y", visible=False)


es = pd.read_csv(DIR_TABLES / "meta_effect_sizes_python.csv")
es["ci_lb"] = es["yi"] - stats.norm.ppf(.975) * np.sqrt(es["vi"]); es["ci_ub"] = es["yi"] + stats.norm.ppf(.975) * np.sqrt(es["vi"])
es["comparison"] = [f"Study {s}: {t}" for s, t in zip(es["study"], es["technique"])]
t7 = pd.read_csv(DIR_TABLES / "meta_table7_pooled_effects_python.csv").set_index("measure")

# ---- Figure 1 ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(9, 5.5), sharey=True)
r = t7.loc["Reflection score"]
for ax, smp, col, title, pooled in [(axes[0], "All", COL_ALL, "All participants", (r["g_all"], r["ci_lb_all"], r["ci_ub_all"])),
                                    (axes[1], "Low", COL_LOW, "Low-income participants", (r["g_low"], r["ci_lb_low"], r["ci_ub_low"]))]:
    sub = es[(es["measure"] == "reflection") & (es["sample"] == smp)]
    forest(ax, sub["comparison"].tolist(), sub["yi"], sub["ci_lb"], sub["ci_ub"], col, pooled=pooled)
    ax.set_title(title, loc="left", fontweight="bold", fontsize=9)
    ax.set_xlim(-0.5, 0.45)
fig.supxlabel("Hedges' g (high minus low scarcity), 95% CI", fontsize=9)
fig.suptitle("Effects of high- versus low-scarcity manipulations on the Reflection score", x=0.01, ha="left", fontsize=11)
fig.text(0.01, -0.02, "Diamonds: pooled multilevel estimates (REML). Dashed lines: equivalence bounds of g = \u00b10.20. Study 1 did not measure fluid intelligence.", fontsize=7, color=COL_MID)
fig.tight_layout()
save(fig, "figure1_forest_reflection")

# ---- Figure 2 ---------------------------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(13, 6), sharey=True)
pooled_rows = {"concerns": "Scarcity concerns, all studies", "crs": "Cognitive reflection", "fis": "Fluid intelligence", "reflection": "Reflection score"}
all_comps = es[es["sample"] == "All"]["comparison"].drop_duplicates().tolist()
for ax, (m, lab) in zip(axes, MEASURE_LABELS.items()):
    sub = es[(es["measure"] == m) & (es["sample"] == "All")].set_index("comparison").reindex(all_comps)
    y = np.arange(len(all_comps))[::-1]
    ax.axvspan(-0.2, 0.2, color="#efefef", zorder=0); ax.axvline(0, color=COL_MID, linewidth=0.9)
    p = t7.loc[pooled_rows[m]]
    ax.axvspan(p["ci_lb_all"], p["ci_ub_all"], color=COL_ALL, alpha=0.12, zorder=0); ax.axvline(p["g_all"], color=COL_ALL, linewidth=1)
    ok = sub["yi"].notna()
    ax.hlines(y[ok], sub["ci_lb"][ok], sub["ci_ub"][ok], color=COL_ALL, linewidth=1.1); ax.scatter(sub["yi"][ok], y[ok], s=16, color=COL_ALL, zorder=3)
    ax.set_yticks(y); ax.set_yticklabels(all_comps); ax.set_title(lab, loc="left", fontweight="bold", fontsize=9)
fig.supxlabel("Hedges' g (high minus low scarcity), 95% CI", fontsize=9)
fig.suptitle("The 18 high- versus low-scarcity comparisons, all participants", x=0.01, ha="left", fontsize=11)
fig.text(0.01, -0.02, "Vertical line and band: pooled multilevel estimate with 95% CI (concerns: all studies). Grey region: equivalence bounds \u00b10.20.", fontsize=7, color=COL_MID)
fig.tight_layout()
save(fig, "figure2_forest_all_measures")

# ---- Figure 3 ---------------------------------------------------------------
data = pd.concat([read_processed(s, "_python") for s in range(1, 6)], ignore_index=True)
data["cognition"] = np.where(data["study"] == 1, data["crs"], data["reflection"])
cond_levels = ["Passive control", "Lottery low", "Lottery high", "Scale low", "Scale high", "Recall low", "Recall high",
               "Consequences low", "Consequences high", "Scenario low", "Scenario high", "Pictures low", "Generic pictures high",
               "COVID-19 pictures low", "COVID-19 pictures high", "Picture imagination low", "Picture imagination high"]
scale_note = {1: "FCS, 5-35", 2: "FCQ, 15-105", 3: "SCS, 4-28", 4: "FCQ, 15-105", 5: "FCQ, 15-105"}
for var, name, xlabel, title, note in [("concerns", "figure3_condition_means_concerns", "Scarcity concerns, mean and 95% CI", "Scarcity concerns by condition and income group", scale_note),
                                       ("cognition", "figure3_condition_means_cognition", "Cognitive performance, mean and 95% CI", "Cognitive performance by condition and income group",
                                        {1: "cognitive reflection, 0-6", 2: "Reflection score, 0-8", 3: "Reflection score, 0-8", 4: "Reflection score, 0-8", 5: "Reflection score, 0-8"})]:
    fig, axes = plt.subplots(1, 5, figsize=(15, 5.5))
    for ax, s in zip(axes, range(1, 6)):
        d = data[data["study"] == s]
        conds = [c for c in cond_levels if c in set(d["condition"])]
        y = np.arange(len(conds))[::-1]
        for grp, col, off in [("Low", COL_LOW, -0.15), ("High", COL_ALL, 0.15)]:
            g = d[d["income_group"] == grp].groupby("condition", observed=True)[var].agg(["mean", "std", "size"]).reindex(conds)
            se = g["std"] / np.sqrt(g["size"])
            ax.hlines(y + off, g["mean"] - 1.96 * se, g["mean"] + 1.96 * se, color=col, linewidth=1.2)
            ax.scatter(g["mean"], y + off, s=18, color=col, zorder=3, label=f"{grp} income")
        ax.set_yticks(y); ax.set_yticklabels(conds); ax.set_title(f"Study {s} ({note[s]})", loc="left", fontweight="bold", fontsize=9)
        ax.grid(axis="y", visible=False)
    axes[0].legend(loc="lower left", bbox_to_anchor=(0, 1.04), ncol=2, frameon=False, fontsize=8)
    fig.supxlabel(xlabel, fontsize=9); fig.suptitle(title, x=0.01, ha="left", fontsize=11)
    fig.tight_layout()
    save(fig, name)

# ---- Figure 4 ---------------------------------------------------------------
inc = pd.read_csv(DIR_TABLES / "meta_income_group_effect_sizes_python.csv")
inc["ci_lb"] = inc["yi"] - stats.norm.ppf(.975) * np.sqrt(inc["vi"]); inc["ci_ub"] = inc["yi"] + stats.norm.ppf(.975) * np.sqrt(inc["vi"])
pooled = pd.read_csv(DIR_TABLES / "meta_income_and_cognition_python.csv").set_index("measure")
fig, axes = plt.subplots(1, 4, figsize=(12, 3.8), sharey=True)
labels = [f"Study {s}" for s in range(1, 6)] + ["Pooled (REML, Knapp-Hartung)"]
for ax, (m, lab) in zip(axes, MEASURE_LABELS.items()):
    sub = inc[inc["measure"] == m].set_index("study").reindex(range(1, 6))
    y = np.arange(6)[::-1]
    ax.axvline(0, color=COL_MID, linewidth=0.9)
    ok = sub["yi"].notna().to_numpy()
    ax.hlines(y[:5][ok], sub["ci_lb"][ok], sub["ci_ub"][ok], color=COL_ALL, linewidth=1.2); ax.scatter(sub["yi"][ok], y[:5][ok], s=20, color=COL_ALL, zorder=3)
    p = pooled.loc[m]
    ax.hlines(y[5], p["ci_lb"], p["ci_ub"], color=COL_MID, linewidth=1.2); ax.scatter(p["g_high_minus_low_income"], y[5], s=34, marker="D", color=COL_MID, zorder=3)
    ax.set_yticks(y); ax.set_yticklabels(labels); ax.set_title(lab, loc="left", fontweight="bold", fontsize=9); ax.grid(axis="y", visible=False)
fig.supxlabel("Hedges' g (high minus low income), 95% CI", fontsize=9)
fig.suptitle("High- versus low-income participants on each measure", x=0.01, ha="left", fontsize=11)
fig.tight_layout()
save(fig, "figure4_income_groups")

# ---- Figure 5 ---------------------------------------------------------------
fig, axes = plt.subplots(1, 5, figsize=(13, 4), sharey=True)
for ax, s in zip(axes, range(1, 6)):
    d = data[data["study"] == s]
    bins = np.arange(0, d["effective_income"].max() / 1000 + 5, 5)
    for grp, col in [("Low", COL_LOW), ("High", COL_ALL)]:
        ax.hist(d.loc[d["income_group"] == grp, "effective_income"] / 1000, bins=bins, color=col, edgecolor="white", linewidth=0.3, label=f"{grp} income")
    ax.axvline(d["effective_income"].median() / 1000, color=COL_MID, linestyle="--", linewidth=0.9)
    ax.set_title(f"Study {s} ({'GBP' if s <= 2 else 'USD'})", loc="left", fontweight="bold", fontsize=9)
axes[0].set_ylabel("Participants"); axes[0].legend(frameon=False, fontsize=8)
fig.supxlabel("Effective income (household income after tax / sqrt(household size)), thousands", fontsize=9)
fig.suptitle("Effective income and the preregistered median split in each study (ties to the high-income group)", x=0.01, ha="left", fontsize=11)
fig.tight_layout()
save(fig, "figure5_effective_income")
print("Figures written to", DIR_FIGURES)
