"""
compare_text_statistics.py -- checks the statistics reported in the text of
the paper's Results sections (not in the tables) against the recomputed
values from R (output/tables/*.csv) and Python (output/tables/*_python.csv):
sample descriptives, income-group sizes and means, reliabilities, omnibus
ANOVAs, income-group comparisons, and the Study 1 manipulation checks.

Reference values were transcribed from the paper. A value "agrees" when
the recomputed value rounds to the printed one (tolerance: half a unit of the
last printed digit, plus a small allowance for intermediate rounding).

Output: output/checks/replication_check_text_statistics.csv
Run from the project root:  python3 python/compare_text_statistics.py
"""
import numpy as np
import pandas as pd

from setup import DIR_TABLES, DIR_CHECKS

# (study, table, selector, column, paper value, decimals printed)
REF = []
# -- sample descriptives (Participants sections)
for s, (age_m, age_sd, w, m, o) in enumerate([(37.55, 13.22, 1212, 1224, 5), (38.22, 14.08, 1116, 1078, 4), (36.11, 13.96, 790, 774, 5),
                                              (35.60, 12.80, 1118, 1118, 6), (36.12, 13.20, 1054, 1087, 7)], start=1):
    REF += [(s, "samples", {}, "age_mean", age_m, 2), (s, "samples", {}, "age_sd", age_sd, 2),
            (s, "samples", {}, "n_women", w, 0), (s, "samples", {}, "n_men", m, 0), (s, "samples", {}, "n_other", o, 0)]
# -- income groups (Income sections): n and mean (SD) of effective income
for s, (med, nl, ml, sdl, nh, mh, sdh) in enumerate([(25000, 1199, 15028, 6713, 1242, 41875, 16199), (25000, 1091, 11971, 6305, 1107, 47992, 19748),
                                                     (37500, 758, 19199, 10104, 811, 64319, 20907), (45000, 1096, 23488, 12032, 1146, 72233, 19992),
                                                     (43301, 1055, 21782, 11565, 1093, 72184, 21793)], start=1):
    REF += [(s, "samples", {}, "income_median", med, 0), (s, "samples", {}, "n_low_income", nl, 0), (s, "samples", {}, "n_high_income", nh, 0),
            (s, "samples", {}, "income_low_mean", ml, 0), (s, "samples", {}, "income_low_sd", sdl, 0),
            (s, "samples", {}, "income_high_mean", mh, 0), (s, "samples", {}, "income_high_sd", sdh, 0)]
# -- reliabilities
alphas = {1: {"Scarcity concerns (FCS, 5 items)": .83, "Cognitive reflection (CPT, 6 items)": .67},
          2: {"Scarcity concerns (FCQ, 15 items)": .85, "Cognitive reflection (CPT, 5 items)": .70, "Fluid intelligence (3 Raven items)": .60, "Reflection score (8 items)": .73},
          3: {"Scarcity concerns (SCS, 4 items)": .81, "Cognitive reflection (CPT, 5 items)": .73, "Fluid intelligence (3 Raven items)": .63, "Reflection score (8 items)": .74},
          4: {"Scarcity concerns (FCQ, 15 items)": .86, "Cognitive reflection (CPT, 5 items)": .75, "Fluid intelligence (3 Raven items)": .63, "Reflection score (8 items)": .76},
          5: {"Scarcity concerns (FCQ, 15 items)": .86, "Cognitive reflection (CPT, 5 items)": .71, "Fluid intelligence (3 Raven items)": .60, "Reflection score (8 items)": .74}}
for s, d in alphas.items():
    for scale, a in d.items():
        REF.append((s, "reliability", {"scale": scale}, "alpha", a, 2))
# -- income-group comparisons (high minus low): means, t, d
inc = {1: {"concerns": (17.20, 20.65, -12.57, -0.51), "crs": (3.17, 2.79, 5.44, 0.22)},
       2: {"concerns": (57.82, 69.71, -20.21, -0.86), "crs": (2.44, 2.13, 4.53, 0.19), "fis": (1.52, 1.22, 6.28, 0.27), "reflection": (3.96, 3.35, 6.26, 0.27)},
       3: {"concerns": (16.24, 18.73, -9.57, -0.48), "crs": (2.33, 2.00, 4.04, 0.20), "fis": (1.36, 1.31, 1.00, 0.05), "reflection": (3.70, 3.30, 3.40, 0.17)},
       4: {"concerns": (60.28, 73.05, -21.07, -0.89), "crs": (2.46, 1.84, 8.71, 0.37), "fis": (1.44, 1.22, 4.55, 0.19), "reflection": (3.89, 3.06, 8.44, 0.36)},
       5: {"concerns": (64.70, 77.86, -21.43, -0.93), "crs": (2.15, 1.69, 6.70, 0.29), "fis": (1.24, 1.05, 4.07, 0.18), "reflection": (3.38, 2.74, 6.69, 0.29)}}
for s, d in inc.items():
    for m, (mh, ml, t, dd) in d.items():
        REF += [(s, "income", {"measure": m}, "m_high_income", mh, 2), (s, "income", {"measure": m}, "m_low_income", ml, 2),
                (s, "income", {"measure": m}, "t", t, 2), (s, "income", {"measure": m}, "d", dd, 2)]
REF.append((3, "income", {"measure": "fis"}, "p", .318, 3))
# -- omnibus ANOVAs: (measure, model, term) -> F, p, partial eta2 (p < .001 recorded as None)
anv = {1: [("concerns", "condition", "condition", 1.42, .185, .005), ("crs", "condition", "condition", 1.24, .270, .004),
           ("concerns", "condition x income group", "condition:income_group", 1.18, .308, .004), ("crs", "condition x income group", "condition:income_group", 0.51, .853, .002)],
       2: [("concerns", "condition x income group", "condition", 3.02, .004, .010), ("concerns", "condition x income group", "condition:income_group", 0.64, .719, .002),
           ("crs", "condition x income group", "condition:income_group", 1.57, .139, .005), ("fis", "condition x income group", "condition:income_group", 1.08, .377, .003),
           ("reflection", "condition x income group", "condition:income_group", 1.74, .096, .006)],
       3: [("concerns", "condition x income group", "condition", 24.49, None, .030), ("concerns", "condition x income group", "condition:income_group", 1.34, .263, .002),
           ("crs", "condition x income group", "condition:income_group", 0.38, .683, None), ("fis", "condition x income group", "condition:income_group", 0.49, .612, .001),
           ("reflection", "condition x income group", "condition:income_group", 0.09, .914, None)],
       4: [("concerns", "condition x income group", "condition", 3.87, None, .012), ("concerns", "condition x income group", "condition:income_group", 0.45, .871, .001),
           ("crs", "condition x income group", "condition:income_group", 1.46, .177, .005), ("fis", "condition x income group", "condition:income_group", 0.89, .512, .003),
           ("reflection", "condition x income group", "condition:income_group", 1.15, .329, .004)],
       5: [("concerns", "condition x income group", "condition", 4.16, None, .015), ("concerns", "condition x income group", "condition:income_group", 0.78, .618, .003),
           ("crs", "condition x income group", "condition:income_group", 0.73, .664, .003), ("fis", "condition x income group", "condition:income_group", 0.71, .683, .003),
           ("reflection", "condition x income group", "condition:income_group", 0.72, .678, .003)]}
for s, rows in anv.items():
    for m, model, term, F, p, eta in rows:
        sel = {"measure": m, "model": model, "term": term}
        REF.append((s, "anova", sel, "F", F, 2))
        if p is not None:
            REF.append((s, "anova", sel, "p", p, 3))
        if eta is not None:
            REF.append((s, "anova", sel, "partial_eta2", eta, 3))
# -- Study 1 manipulation checks
REF += [(1, "scale", {}, "t", -9.77, 2), (1, "scale", {}, "d", -0.83, 2), (1, "scale", {}, "m_high", 1.43, 2), (1, "scale", {}, "sd_high", 1.28, 2),
        (1, "scale", {}, "m_low", 3.51, 2), (1, "scale", {}, "sd_low", 3.30, 2),
        (1, "lottery", {"condition": "Lottery high"}, "pct_max_correct", 96.3, 1), (1, "lottery", {"condition": "Lottery high"}, "pct_actual_correct", 98.5, 1),
        (1, "lottery", {"condition": "Lottery low"}, "pct_max_correct", 99.6, 1), (1, "lottery", {"condition": "Lottery low"}, "pct_actual_correct", 99.6, 1)]

FILES = {"samples": "all_samples", "reliability": "all_reliability", "income": "all_income_groups", "anova": "all_anovas",
         "scale": "study1_scale_manipulation_check", "lottery": "study1_lottery_attention_checks"}
FILES_PY = {"samples": "all_sample_python", "reliability": "all_reliability_python", "income": "all_income_python", "anova": "all_anovas_python",
            "scale": "study1_scale_manipulation_check_python", "lottery": "study1_lottery_attention_checks_python"}


def lookup(tables, study, table, sel, col):
    t = tables[table]
    if "study" in t.columns:
        t = t[t["study"] == study]
    for k, v in sel.items():
        t = t[t[k] == v]
    if len(t) != 1:
        return np.nan
    return float(t.iloc[0][col])


def run(files, label):
    tables = {k: pd.read_csv(DIR_TABLES / f"{v}.csv") for k, v in files.items() if (DIR_TABLES / f"{v}.csv").exists()}
    rows = []
    for study, table, sel, col, ref, dec in REF:
        if table not in tables:
            rows.append(dict(study=study, table=table, selector=str(sel), statistic=col, paper=ref, recomputed=np.nan, agrees=False)); continue
        val = lookup(tables, study, table, sel, col)
        tol = 0.5 * 10 ** (-dec) + 0.1 * 10 ** (-dec)
        rows.append(dict(study=study, table=table, selector=str(sel), statistic=col, paper=ref, recomputed=round(val, dec + 2) if not np.isnan(val) else np.nan,
                         agrees=bool(not np.isnan(val) and abs(val - ref) <= tol)))
    res = pd.DataFrame(rows)
    res.to_csv(DIR_CHECKS / f"replication_check_text_statistics_{label}.csv", index=False)
    print(f"[{label}] {res['agrees'].sum()} of {len(res)} in-text statistics agree with the paper")
    bad = res[~res["agrees"]]
    if len(bad):
        pd.set_option("display.width", 200); print(bad.to_string(index=False))
    return res


if __name__ == "__main__":
    run(FILES, "R")
    run(FILES_PY, "python")
