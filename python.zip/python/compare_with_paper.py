"""
compare_with_paper.py -- automatic replication check

Compares the high- versus low-scarcity contrasts produced by the R code
(output/tables/all_contrasts.csv) and by the Python code
(output/tables/all_contrasts_python.csv) with the values printed in Tables 2
to 6 of the paper (output/checks/paper_tables_2_to_6.csv, extracted
from the Word file).

A cell "agrees" when the recomputed value, rounded as in the paper
(d to 2 decimals, p to 3 decimals, t to 2 decimals), equals the printed value,
allowing one unit in the last printed digit for rounding of intermediate
values.

Run from the project root:  python3 python/compare_with_paper.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
MS = pd.read_csv(ROOT / "output" / "checks" / "paper_tables_2_to_6.csv")

LABELS = {"concerns": "Scarcity concerns", "crs": "Cognitive reflection", "fis": "Fluid intelligence", "reflection": "Reflection score"}


def p_from_text(s):
    s = str(s).strip()
    if s.startswith(">"):
        return 0.9995, True     # printed as "> .999"
    return float(s), False


def compare(path, label):
    if not path.exists():
        print(f"[{label}] {path.name} not found; skipped")
        return None
    r = pd.read_csv(path)
    r["measure_key"] = r["measure"].map(lambda m: "concerns" if m == "concerns" else m)
    rows = []
    for _, m in MS.iterrows():
        meas = {"Financial concerns": "concerns", "Resource scarcity concerns": "concerns", "Cognitive reflection": "crs",
                "Fluid intelligence": "fis", "Reflection score": "reflection"}[m["measure"]]
        sub = r[(r["study"] == m["study"]) & (r["technique"] == m["technique"]) & (r["measure_key"] == meas)]
        if sub.empty:
            rows.append(dict(study=m["study"], technique=m["technique"], measure=m["measure"], status="MISSING"))
            continue
        rec = {}
        for samp, dcol, pcol in [("All", "d_all", "p_all"), ("Low income", "d_low", "p_low"), ("High income", "d_high", "p_high")]:
            x = sub[sub["sample"] == samp].iloc[0]
            pm, gt = p_from_text(m[pcol])
            rec[f"d_{samp}"] = (round(float(x["d"]), 2), float(m[dcol]))
            rec[f"p_{samp}"] = (round(float(x["p_one_tailed"]), 3), pm if not gt else None, gt, float(x["p_one_tailed"]))
        x = sub.iloc[0]
        pm, gt = p_from_text(m["p_int"])
        rec["t_int"] = (round(float(x["t_interaction"]), 2), float(m["t_int"]))
        rec["p_int"] = (round(float(x["p_interaction_one_tailed"]), 3), pm, gt, float(x["p_interaction_one_tailed"]))
        n_ok = (int(sub.iloc[0]["n_high"]) == m["n_high"]) and (int(sub.iloc[0]["n_low"]) == m["n_low"])
        out = dict(study=m["study"], technique=m["technique"], measure=m["measure"], n_match=n_ok)
        all_ok = n_ok
        for k, v in rec.items():
            if k.startswith("d_") or k.startswith("t_"):
                ok = abs(v[0] - v[1]) <= 0.011
                out[k] = f"{v[0]:.2f} vs {v[1]:.2f}" + ("" if ok else "  <-- DIFFERS")
            else:
                if v[2]:        # paper printed "> .999"
                    ok = v[3] > 0.9985
                    out[k] = f"{v[3]:.4f} vs > .999" + ("" if ok else "  <-- DIFFERS")
                else:
                    ok = abs(v[0] - v[1]) <= 0.0011
                    out[k] = f"{v[0]:.3f} vs {v[1]:.3f}" + ("" if ok else "  <-- DIFFERS")
            all_ok = all_ok and ok
        out["status"] = "OK" if all_ok else "CHECK"
        rows.append(out)
    res = pd.DataFrame(rows)
    res.to_csv(ROOT / "output" / "checks" / f"replication_check_{label}.csv", index=False)
    n_ok = (res["status"] == "OK").sum()
    print(f"[{label}] {n_ok} of {len(res)} table rows (each with 3 d, 3 p, 1 t and 1 p) reproduce the paper exactly")
    bad = res[res["status"] != "OK"]
    if len(bad):
        pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
        print(bad.to_string(index=False))
    return res


if __name__ == "__main__":
    compare(ROOT / "output" / "tables" / "all_contrasts.csv", "R")
    compare(ROOT / "output" / "tables" / "all_contrasts_python.csv", "python")
