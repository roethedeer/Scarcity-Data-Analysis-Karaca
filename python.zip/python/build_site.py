"""
build_site.py -- builds the public web page (site/index.html) from the
pipeline's outputs: result tables, figures, the scripts themselves, the
codebook and the checks. Nothing on the page is typed by hand except the
explanatory text; every number comes from output/tables and output/checks.

Run from the project root:  python3 python/build_site.py
"""
import html
import re
import json
from pathlib import Path

import numpy as np
import pandas as pd

from setup import PROJECT_ROOT, DIR_TABLES, DIR_CHECKS, DIR_FIGURES

SITE = PROJECT_ROOT / "site"
SITE.mkdir(exist_ok=True)
E = html.escape
IDENTIFIERS_REMOVED = [
    "Prolific IDs (PROLIFIC_PID, Prolific_ID, participant_id and equivalents)", "IP addresses", "latitude and longitude",
    "survey start, end and recording time stamps", "free-text answers from the recall, consequences, scenario and picture tasks",
    "open comments at the end of the survey", "Qualtrics response IDs, distribution channel and user language",
]


def fmt_p(p):
    return "&lt; .001" if p < .001 else f"{p:.3f}".lstrip("0")


def table(df, columns, headers=None, numeric=(), fmt=None, cls="", caption=None):
    headers = headers or columns
    fmt = fmt or {}
    out = [f'<div class="table-wrap"><table class="{cls}">']
    if caption:
        out.append(f"<caption>{caption}</caption>")
    out.append("<thead><tr>" + "".join(f'<th{" class=num" if c in numeric else ""}>{h}</th>' for c, h in zip(columns, headers)) + "</tr></thead><tbody>")
    for _, r in df.iterrows():
        cells = []
        for c in columns:
            v = r[c]
            if c in fmt:
                v = fmt[c](v)
            elif isinstance(v, float):
                v = "" if np.isnan(v) else (f"{v:.3f}" if abs(v) < 10 else f"{v:,.2f}")
            elif isinstance(v, (int, np.integer)):
                v = f"{v:,}"
            else:
                v = E(str(v))
            cells.append(f'<td{" class=num" if c in numeric else ""}>{v}</td>')
        out.append("<tr>" + "".join(cells) + "</tr>")
    out.append("</tbody></table></div>")
    return "\n".join(out)


def code_block(path, lang):
    src = (PROJECT_ROOT / path).read_text(encoding="utf-8")
    n = src.count("\n") + 1
    return (f'<details class="code"><summary><span class="file">{E(path)}</span><span class="meta">{n} lines</span></summary>'
            f'<div class="code-body"><button class="copy" type="button" data-copy>Copy</button>'
            f'<pre><code class="language-{lang}">{E(src)}</code></pre></div></details>')


# ---- Markdown -> HTML (headings, paragraphs, lists, pipe tables, inline code, bold, links) ----
def md_inline(t):
    t = E(t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    return t


def md_to_html(md, title, css):
    out, para, list_tag, table = [], [], None, []
    def flush_para():
        if para: out.append("<p>" + md_inline(" ".join(para)) + "</p>"); para.clear()
    def flush_list():
        nonlocal list_tag
        if list_tag: out.append(f"</{list_tag}>"); list_tag = None
    def flush_table():
        if table:
            head, body = table[0], [r for r in table[2:]] if len(table) > 1 and set(table[1].replace("|", "").strip()) <= set("-: ") else [r for r in table[1:]]
            cells = lambda r: [c.strip() for c in r.strip().strip("|").split("|")]
            out.append('<div class="table-wrap"><table><thead><tr>' + "".join(f"<th>{md_inline(c)}</th>" for c in cells(head)) + "</tr></thead><tbody>")
            for r in body:
                out.append("<tr>" + "".join(f"<td>{md_inline(c)}</td>" for c in cells(r)) + "</tr>")
            out.append("</tbody></table></div>"); table.clear()
    for line in md.splitlines():
        if line.startswith("|"):
            flush_para(); flush_list(); table.append(line); continue
        flush_table()
        m = re.match(r"^(#{1,3}) (.*)", line)
        if m:
            flush_para(); flush_list(); out.append(f"<h{len(m.group(1))}>{md_inline(m.group(2))}</h{len(m.group(1))}>"); continue
        m = re.match(r"^(\d+)\. (.*)", line) or re.match(r"^(-) (.*)", line)
        if m:
            flush_para(); tag = "ol" if m.group(1) != "-" else "ul"
            if list_tag != tag: flush_list(); out.append(f"<{tag}>"); list_tag = tag
            out.append(f"<li>{md_inline(m.group(2))}</li>"); continue
        if not line.strip():
            flush_para(); flush_list(); continue
        if list_tag and line.startswith("   "):
            out[-1] = out[-1][:-5] + " " + md_inline(line.strip()) + "</li>"; continue
        para.append(line.strip())
    flush_para(); flush_list(); flush_table()
    body = "\n".join(out)
    return ("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
            f"<title>{E(title)}</title>\n{css}\n</head>\n<body>\n<div class=\"wrap\"><p class=\"back\"><a href=\"../index.html\">&larr; Scarcity Replication Guide</a></p>\n{body}\n</div>\n</body>\n</html>\n")


# ---- load outputs ------------------------------------------------------------
samples = pd.read_csv(DIR_TABLES / "all_samples.csv")
rel = pd.read_csv(DIR_TABLES / "all_reliability.csv")
anov = pd.read_csv(DIR_TABLES / "all_anovas.csv")
inc = pd.read_csv(DIR_TABLES / "all_income_groups.csv")
t7 = pd.read_csv(DIR_TABLES / "meta_table7_pooled_effects.csv")
t8 = pd.read_csv(DIR_TABLES / "meta_table8_techniques.csv")
incpool = pd.read_csv(DIR_TABLES / "meta_income_and_cognition.csv")
csvsav = pd.read_csv(DIR_CHECKS / "csv_vs_sav_summary.csv")
rep_r = pd.read_csv(DIR_CHECKS / "replication_check_R.csv")
rep_py = pd.read_csv(DIR_CHECKS / "replication_check_python.csv")
txt_r = pd.read_csv(DIR_CHECKS / "replication_check_text_statistics_R.csv")
txt_py = pd.read_csv(DIR_CHECKS / "replication_check_text_statistics_python.csv")
rvp = pd.read_csv(DIR_CHECKS / "meta_r_vs_python.csv")
derived = pd.read_csv(DIR_CHECKS / "derived_vs_spss.csv")
audit = pd.read_csv(DIR_CHECKS / "anonymity_audit.csv")
codebook = pd.read_csv(PROJECT_ROOT / "codebook" / "codebook.csv")
cond = pd.read_csv(PROJECT_ROOT / "codebook" / "conditions_by_study.csv")
study_tables = {s: pd.read_csv(DIR_TABLES / f"study{s}_table.csv") for s in range(1, 6)}
N_total = int(samples["n"].sum())

# ---- static descriptions -----------------------------------------------------
STUDIES = [
    (1, "UK, December 2020", "Lottery, scale, recall, consequences; passive control (9 conditions)", "Financial Concerns Scale (5 items)", "Cognitive reflection (6 CPT items)"),
    (2, "UK, May 2021", "Recall, scenario, generic pictures, COVID-19 pictures; passive control (8 conditions)", "Financial Concerns Questionnaire (15 items)", "Cognitive reflection (5 items), fluid intelligence (3 Raven items), Reflection score"),
    (3, "US, June 2021", "Generic pictures, COVID-19 pictures (3 conditions)", "Scarcity Concerns Scale (4 items)", "as Study 2"),
    (4, "US, June to July 2021", "as Study 2 (8 conditions)", "Financial Concerns Questionnaire", "as Study 2"),
    (5, "US, September 2022", "Recall, scenario, COVID-19 pictures, picture imagination; passive control (9 conditions)", "Financial Concerns Questionnaire", "as Study 2"),
]
STEPS = [
    ("Prepare the data", "Read the raw export of each study, map the Qualtrics condition labels to the condition names of the paper, recompute every score from the item responses, compute effective income and the preregistered median split, and drop every identifying column. The recomputed scores are compared with the scores stored in the original SPSS files and the script stops if any value differs.",
     "R/01_prepare_data.R", "python/prepare_data.py"),
    ("Per-study analyses", "For each study: Cronbach's alpha, Type III ANOVAs with partial eta squared, the two-tailed income-group comparisons, and the preregistered one-tailed contrasts (Student's t, Cohen's d) in the full sample and within income groups, plus the condition by income interaction for each pair of conditions. These are Tables 2 to 6.",
     "R/02_study_analyses.R", "python/study_analyses.py"),
    ("Meta-analysis", "Hedges' g for the 18 high- versus low-scarcity comparisons; the covariance between comparisons that share a control group; multilevel random-effects models (Table 7), technique models (Table 8), equivalence tests against g = 0.20, meta-regressions and the sensitivity analyses.",
     "R/03_meta_analysis.R", "python/meta_analysis.py"),
    ("Figures", "Forest plots, condition means by income group, income-group differences and the distribution of effective income.", "R/04_figures.R", "python/figures.py"),
]

# ---- tables ------------------------------------------------------------------
ov = pd.DataFrame([dict(study=f"Study {s}", sample=smp, n=int(samples.loc[samples.study == s, "n"].iloc[0]), tech=t, check=c, cog=g) for s, smp, t, c, g in STUDIES])
overview_tbl = table(ov, ["study", "sample", "n", "tech", "check", "cog"], ["Study", "Sample", "N", "Techniques (high vs low scarcity)", "Manipulation check", "Cognitive measures"], numeric=("n",))

sm = samples.copy()
sm["study"] = sm["study"].map(lambda s: f"Study {s}")
sm["age"] = [f"{m:.2f} ({sd:.2f})" for m, sd in zip(sm["age_mean"], sm["age_sd"])]
sm["gender"] = [f"{w:,} / {m:,} / {o}" for w, m, o in zip(sm["n_women"], sm["n_men"], sm["n_other"])]
sm["median"] = sm["income_median"].map(lambda x: f"{x:,.0f}")
sm["low"] = [f"{n:,} ({m:,.0f}, SD {sd:,.0f})" for n, m, sd in zip(sm["n_low_income"], sm["income_low_mean"], sm["income_low_sd"])]
sm["high"] = [f"{n:,} ({m:,.0f}, SD {sd:,.0f})" for n, m, sd in zip(sm["n_high_income"], sm["income_high_mean"], sm["income_high_sd"])]
sample_tbl = table(sm, ["study", "n", "age", "gender", "median", "low", "high"], ["Study", "N", "Age M (SD)", "Women / men / other", "Median effective income", "Low-income group n (M, SD)", "High-income group n (M, SD)"], numeric=("n",))

rel_w = rel.pivot_table(index="scale", columns="study", values="alpha", aggfunc="first", sort=False).reset_index()
rel_w.columns = ["scale"] + [f"s{c}" for c in rel_w.columns[1:]]
rel_tbl = table(rel_w, list(rel_w.columns), ["Scale"] + [f"Study {c[1:]}" for c in rel_w.columns[1:]], numeric=tuple(rel_w.columns[1:]),
                fmt={c: (lambda v: "" if np.isnan(v) else f"{v:.2f}") for c in rel_w.columns[1:]})

MEAS = {"concerns": "Scarcity concerns", "crs": "Cognitive reflection", "fis": "Fluid intelligence", "reflection": "Reflection score"}
an = anov[anov["model"] == "condition x income group"].copy()
an["term"] = an["term"].map({"condition": "Condition", "income_group": "Income group", "condition:income_group": "Condition x income group"})
an["cell"] = [f"F({a}, {b}) = {F:.2f}, p = {fmt_p(p)}, &eta;&sup2;<sub>p</sub> = {e:.3f}" for a, b, F, p, e in zip(an["df1"], an["df2"], an["F"], an["p"], an["partial_eta2"])]
an["measure"] = an["measure"].map(MEAS)
anw = an.pivot_table(index=["study", "measure"], columns="term", values="cell", aggfunc="first", sort=False).reset_index()
anw["study"] = anw["study"].map(lambda s: f"Study {s}")
anova_tbl = table(anw, ["study", "measure", "Condition", "Income group", "Condition x income group"], ["Study", "Measure", "Condition", "Income group", "Condition x income group"],
                  fmt={c: (lambda v: v) for c in ["Condition", "Income group", "Condition x income group"]})

ic = inc.copy()
ic["study"] = ic["study"].map(lambda s: f"Study {s}"); ic["measure"] = ic["measure"].map(MEAS)
ic["cell"] = [f"t({df}) = {t:.2f}, p {('= ' + fmt_p(p)) if p >= .001 else '&lt; .001'}, d = {d:.2f}" for df, t, p, d in zip(ic["df"], ic["t"], ic["p"], ic["d"])]
income_tbl = table(ic, ["study", "measure", "m_high_income", "m_low_income", "cell"], ["Study", "Measure", "High-income M", "Low-income M", "High minus low"], numeric=("m_high_income", "m_low_income"),
                   fmt={"m_high_income": lambda v: f"{v:.2f}", "m_low_income": lambda v: f"{v:.2f}", "cell": lambda v: v})

study_tabs = []
for s, df in study_tables.items():
    df = df.copy(); df["n"] = [f"{h} / {l}" for h, l in zip(df["n_high"], df["n_low"])]
    tbl = table(df, ["technique", "n", "measure", "all_participants", "low_income", "high_income", "income_x_condition"],
                ["Technique", "n high / low", "Measure", "All participants", "Low income", "High income", "Income x condition"],
                numeric=("all_participants", "low_income", "high_income", "income_x_condition"),
                fmt={c: (lambda v: E(str(v)).replace("-", "&minus;")) for c in ["all_participants", "low_income", "high_income", "income_x_condition"]})
    study_tabs.append((s, tbl))

t7v = t7.copy()
t7v["I2"] = t7v["I2"].map(lambda v: f"{v:.0f}%"); t7v["p_eq"] = t7v["p_equivalence_all"].map(fmt_p); t7v["p"] = t7v["p_all"].map(fmt_p)
table7 = table(t7v, ["measure", "k", "cell_all", "p", "cell_low", "cell_high", "cell_diff", "I2", "p_eq"],
               ["Measure", "k", "All participants", "p", "Low income", "High income", "Low minus high income (p)", "I&sup2;", "Equivalence p"],
               numeric=("k", "cell_all", "p", "cell_low", "cell_high", "cell_diff", "I2", "p_eq"),
               fmt={c: (lambda v: E(str(v)).replace("-", "&minus;")) for c in ["cell_all", "cell_low", "cell_high", "cell_diff", "I2", "p", "p_eq"]})
t8v = t8[~t8["measure"].str.contains("all studies")].copy()
t8v["measure"] = t8v["measure"].str.replace(" (without Study 3)", "")
t8v["p_eq"] = t8v["p_equivalence_all"].map(fmt_p)
table8 = table(t8v, ["technique", "measure", "k", "cell_all", "cell_low", "cell_high", "cell_diff", "p_eq"],
               ["Technique", "Measure", "k", "All participants", "Low income", "High income", "Low minus high income (p)", "Equivalence p"],
               numeric=("k", "cell_all", "cell_low", "cell_high", "cell_diff", "p_eq"),
               fmt={c: (lambda v: E(str(v)).replace("-", "&minus;")) for c in ["cell_all", "cell_low", "cell_high", "cell_diff", "p_eq"]})
ip = incpool.copy(); ip["measure"] = ip["measure"].map(MEAS)
ip["cell"] = [f"{g:.2f} [{a:.2f}, {b:.2f}]".replace("-", "&minus;") for g, a, b in zip(ip["g_high_minus_low_income"], ip["ci_lb"], ip["ci_ub"])]
incpool_tbl = table(ip, ["measure", "k", "cell", "I2"], ["Measure", "k (studies)", "Hedges' g, high minus low income [95% CI]", "I&sup2;"], numeric=("k", "cell", "I2"),
                    fmt={"cell": lambda v: v, "I2": lambda v: f"{v:.0f}%"})

cs = csvsav.copy()
csvsav_tbl = table(cs, ["study", "sav_rows", "csv_rows", "sav_cols", "csv_cols", "same_column_order", "cols_with_differences"],
                   ["File", "Rows (SAV)", "Rows (CSV)", "Columns (SAV)", "Columns (CSV)", "Same column order", "Columns with any differing cell"],
                   numeric=("sav_rows", "csv_rows", "sav_cols", "csv_cols", "cols_with_differences"))
rv = rvp.copy(); rv["max_abs_difference"] = rv["max_abs_difference"].map(lambda v: f"{v:.1e}")
rvp_tbl = table(rv, ["table", "rows", "numeric_columns", "max_abs_difference"], ["Meta-analysis table", "Rows", "Numeric columns", "Largest absolute difference"], numeric=("rows", "numeric_columns", "max_abs_difference"))
checks_summary = [
    ("Scores recomputed from items vs. SPSS-derived scores", f"{int(derived['n_mismatch'].sum())} mismatches in {int(derived['n'].sum()):,} values"),
    ("Tables 2 to 6 (R)", f"{int((rep_r['status'] == 'OK').sum())} of {len(rep_r)} rows identical to the paper"),
    ("Tables 2 to 6 (Python)", f"{int((rep_py['status'] == 'OK').sum())} of {len(rep_py)} rows identical to the paper"),
    ("Statistics in the text (R)", f"{int(txt_r['agrees'].sum())} of {len(txt_r)} agree with the paper"),
    ("Statistics in the text (Python)", f"{int(txt_py['agrees'].sum())} of {len(txt_py)} agree with the paper"),
    ("R versus Python processed data", "identical, cell for cell, in all five studies"),
]
checks_tbl = "<div class=\"table-wrap\"><table class=\"kv\"><tbody>" + "".join(f"<tr><th>{E(k)}</th><td>{E(v)}</td></tr>" for k, v in checks_summary) + "</tbody></table></div>"

cb = codebook.copy()
cb["range"] = [("" if isinstance(a, float) and np.isnan(a) else f"{a:g} to {b:g}") if t == "numeric" else "" for a, b, t in zip(cb["min"], cb["max"], cb["type"])]
codebook_tbl = table(cb, ["variable", "description", "coding", "studies", "range"], ["Variable", "Description", "Coding", "Studies", "Range"],
                     fmt={"variable": lambda v: f"<code>{E(v)}</code>", "description": lambda v: E(v), "coding": lambda v: E(v), "studies": lambda v: E(str(v)), "range": lambda v: v})
cond_tbl = table(cond, ["study", "condition", "technique", "scarcity", "treatment_raw", "n"], ["Study", "Condition", "Technique", "Scarcity", "Label in the export", "n"], numeric=("n",))

flagged = audit[(audit[["prolific_id_24hex", "ipv4", "email", "url", "timestamp", "coordinate_pair"]].sum(axis=1) > 0)]
audit_line = (f"{len(audit)} study-by-column combinations scanned for Prolific-style IDs, IP addresses, e-mail addresses, URLs, time stamps and coordinates: "
              f"{len(flagged)} matches.")

FIGURES = [
    ("figure1_forest_reflection", "Figure 1. Effects of the high- versus low-scarcity manipulations on the Reflection score (Studies 2 to 5), for all participants and for low-income participants. Diamonds are the pooled multilevel estimates; dashed lines mark the equivalence bounds of g = ±0.20."),
    ("figure2_forest_all_measures", "Figure 2. All 18 comparisons on the four measures, full sample, with the pooled estimate and its 95% CI as a vertical band."),
    ("figure3_condition_means_concerns", "Figure 3a. Scarcity concerns by condition and income group (mean and 95% CI). The scales differ between studies."),
    ("figure3_condition_means_cognition", "Figure 3b. Cognitive performance by condition and income group: cognitive reflection in Study 1, the Reflection score in Studies 2 to 5."),
    ("figure4_income_groups", "Figure 4. High- versus low-income participants on each measure, per study and pooled."),
    ("figure5_effective_income", "Figure 5. Effective income in each study with the preregistered median split."),
]
fig_html = "\n".join(f'<figure><img src="figures/{n}.png" alt="{E(c)}" loading="lazy"><figcaption>{E(c)} <a href="figures/{n}_python.png">Python version</a></figcaption></figure>' for n, c in FIGURES)

R_FILES = [("R/00_setup.R", "Packages, paths, and the helper functions every script uses: Cohen's d, Hedges' g, the one-tailed Student's t contrast, the condition by income interaction, the Type III ANOVA, Cronbach's alpha."),
           ("R/01_prepare_data.R", "Raw exports to processed data, with the scoring keys and the verification against the SPSS-derived scores."),
           ("R/02_study_analyses.R", "The per-study results: reliabilities, ANOVAs, income groups, and Tables 2 to 6."),
           ("R/03_meta_analysis.R", "The meta-analyses with metafor: effect sizes, shared-control covariance, Tables 7 and 8, equivalence tests, sensitivity analyses."),
           ("R/04_figures.R", "The figures with ggplot2."), ("R/run_all.R", "Runs the four scripts in order and records the session information.")]
PY_FILES = [("python/setup.py", "Paths, constants and the same helper functions as R/00_setup.R, built on scipy and statsmodels."),
            ("python/prepare_data.py", "Mirrors R/01_prepare_data.R step for step; the processed files are compared cell for cell with R's."),
            ("python/study_analyses.py", "Mirrors R/02_study_analyses.R."),
            ("python/meta_analysis.py", "Mirrors R/03_meta_analysis.R. Python has no metafor, so the multilevel REML model, the shared-control covariance and the Knapp-Hartung adjustment are implemented here directly and checked against R."),
            ("python/figures.py", "The figures with matplotlib."), ("python/make_codebook.py", "Builds the codebook from the variable dictionary and the processed data."),
            ("python/anonymity_audit.py", "Scans the processed data for identifiers and writes the public release."),
            ("python/run_all.py", "Runs everything in order."), ("python/requirements.txt", "Package versions.")]
r_code = "\n".join(f'<div class="script"><p class="script-desc"><code>{E(p)}</code> {E(d)}</p>{code_block(p, "r")}</div>' for p, d in R_FILES)
py_code = "\n".join(f'<div class="script"><p class="script-desc"><code>{E(p)}</code> {E(d)}</p>{code_block(p, "python" if p.endswith(".py") else "plaintext")}</div>' for p, d in PY_FILES)

steps_html = "\n".join(
    f'<li><h3>{E(t)}</h3><p>{E(d)}</p><p class="step-files"><span class="tag tag-r">R</span> <code>{E(r)}</code> <span class="tag tag-py">Python</span> <code>{E(py)}</code></p></li>'
    for t, d, r, py in STEPS)
tabs_btn = "".join(f'<button type="button" role="tab" id="tab-s{s}" aria-controls="panel-s{s}" aria-selected="{"true" if s == 1 else "false"}">Study {s}</button>' for s, _ in study_tabs)
tabs_panels = "".join(f'<div role="tabpanel" id="panel-s{s}" aria-labelledby="tab-s{s}"{"" if s == 1 else " hidden"}><p class="table-note">Table {s + 1} of the paper. Cells show Cohen\'s d for the high- minus the low-scarcity condition with the one-tailed p value in the predicted direction (higher concerns, lower cognitive scores). The last column is the t statistic (one-tailed p) of the condition by income interaction; positive values for concerns and negative values for cognitive measures mean a larger effect among low-income participants.</p>{tbl}</div>' for s, tbl in study_tabs)

g_refl = t7.loc[t7["measure"] == "Reflection score"].iloc[0]
g_cell = f"{g_refl['g_all']:.2f} [{g_refl['ci_lb_all']:.2f}, {g_refl['ci_ub_all']:.2f}]".replace("-", "&minus;")

page = f"""<title>Scarcity Replication Guide</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
/* Layout: a sticky section nav over one reading column (max 1040px); wide tables and code scroll inside their own frames */
:root {{
  --bg: #f6f7f9; --surface: #ffffff; --fg: #17202a; --muted: #5a6573; --line: #d8dde4; --line-soft: #e9edf1;
  --accent: #2a78d6; --accent-ink: #1c5cab; --accent-soft: #e6eefb; --accent-2: #eb6834; --accent-2-soft: #fdeae1;
  --code-bg: #f0f2f5; --hl-kw: #8b2fb3; --hl-str: #0b7a49; --hl-num: #b35c00; --hl-cmt: #6b7480; --hl-fn: #1c5cab;
  --font-text: Calibri, Carlito, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
  --font-display: "Calibri Light", Calibri, Carlito, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
  --font-mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}}
@media (prefers-color-scheme: dark) {{ :root:not([data-theme="light"]) {{
  --bg: #11161b; --surface: #181f26; --fg: #e7ebef; --muted: #a2adb8; --line: #2b353f; --line-soft: #222b34;
  --accent: #5b9bf0; --accent-ink: #8ab8f5; --accent-soft: #1b2b42; --accent-2: #f08c60; --accent-2-soft: #3b2418;
  --code-bg: #141a20; --hl-kw: #c792ea; --hl-str: #6cc48a; --hl-num: #f0a35e; --hl-cmt: #7f8a96; --hl-fn: #8ab8f5; color-scheme: dark; }} }}
:root[data-theme="dark"] {{
  --bg: #11161b; --surface: #181f26; --fg: #e7ebef; --muted: #a2adb8; --line: #2b353f; --line-soft: #222b34;
  --accent: #5b9bf0; --accent-ink: #8ab8f5; --accent-soft: #1b2b42; --accent-2: #f08c60; --accent-2-soft: #3b2418;
  --code-bg: #141a20; --hl-kw: #c792ea; --hl-str: #6cc48a; --hl-num: #f0a35e; --hl-cmt: #7f8a96; --hl-fn: #8ab8f5; color-scheme: dark; }}
* {{ box-sizing: border-box; }}
body {{ background: var(--bg); color: var(--fg); font-family: var(--font-text); font-weight: 400; font-size: 17px; line-height: 1.55; margin: 0; }}
p, li, figcaption, .table-note, .callout p, .script-desc {{ text-align: justify; hyphens: auto; }}
body::before {{ content: ""; position: fixed; inset: 0 0 auto; height: env(safe-area-inset-top, 0px); z-index: 10; background: var(--surface); }}
a {{ color: var(--accent-ink); text-decoration-thickness: 1px; text-underline-offset: 2px; }}
a:focus-visible, button:focus-visible, summary:focus-visible {{ outline: 2px solid var(--accent); outline-offset: 2px; }}
code, pre {{ font-family: var(--font-mono); font-size: 0.86em; }}
p code, li code, td code, .step-files code {{ background: var(--code-bg); padding: 0.1em 0.35em; border-radius: 4px; }}
h1, h2, h3 {{ font-family: var(--font-display); font-weight: 300; line-height: 1.2; text-wrap: balance; margin: 0; }}
strong, b {{ font-weight: 700; }}
h1 {{ font-size: clamp(1.7rem, 1.2rem + 2vw, 2.5rem); letter-spacing: -0.01em; }}
h2 {{ font-size: 1.5rem; margin-block: 0 0.5rem; }}
h3 {{ font-size: 1.1rem; }}
.eyebrow {{ font-size: 0.75rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--muted); font-weight: 500; }}
.topnav {{ position: sticky; top: env(safe-area-inset-top, 0px); z-index: 9; background: var(--surface); border-bottom: 1px solid var(--line);
  padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); }}
.topnav .inner {{ max-width: 1040px; margin: 0 auto; display: flex; flex-wrap: wrap; align-items: center; gap: 0.25rem 1rem; padding-block: 0.55rem; }}
.topnav .brand {{ font-weight: 500; margin-right: auto; white-space: nowrap; }}
.topnav a {{ text-decoration: none; color: var(--muted); font-size: 0.9rem; padding: 0.2rem 0; }}
.topnav a:hover {{ color: var(--fg); }}
.wrap {{ max-width: 1040px; margin: 0 auto; padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); padding-block: 0 4rem; }}
.hero {{ padding-block: 2.5rem 1.5rem; border-bottom: 1px solid var(--line); display: grid; gap: 1rem; }}
.hero p {{ max-width: 68ch; margin: 0; font-size: 1.05rem; }}
.glance {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 0.75rem; margin-top: 0.5rem; }}
.glance div {{ border-left: 3px solid var(--accent); padding: 0.1rem 0 0.1rem 0.75rem; }}
.glance b {{ display: block; font-size: 1.35rem; font-variant-numeric: tabular-nums; font-weight: 400; }}
.glance span {{ color: var(--muted); font-size: 0.85rem; }}
section {{ padding-block: 2.5rem 0; }}
section > p, section li {{ max-width: 72ch; }}
.table-wrap {{ overflow-x: auto; margin-block: 1rem; border: 1px solid var(--line); border-radius: 6px; background: var(--surface); }}
table {{ border-collapse: collapse; width: 100%; font-size: 0.9rem; min-width: 0; }}
caption {{ text-align: left; padding: 0.6rem 0.75rem; font-weight: 500; }}
th, td {{ padding: 0.45rem 0.7rem; text-align: left; vertical-align: top; border-bottom: 1px solid var(--line-soft); }}
th {{ font-weight: 500; background: var(--code-bg); white-space: nowrap; }}
td {{ max-width: 42ch; }}
table:not(.kv) th:first-child, table:not(.kv) td:first-child {{ white-space: nowrap; }}
.num {{ text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }}
tbody tr:last-child td {{ border-bottom: 0; }}
table.kv th {{ width: 40%; background: none; white-space: normal; }}
.table-note {{ color: var(--muted); font-size: 0.9rem; max-width: 80ch; }}
.tabs {{ display: flex; flex-wrap: wrap; gap: 0.4rem; margin-block: 1rem 0; }}
.tabs button {{ font: inherit; font-size: 0.9rem; padding: 0.35rem 0.8rem; border: 1px solid var(--line); background: var(--surface); color: var(--fg); border-radius: 999px; cursor: pointer; }}
.tabs button[aria-selected="true"] {{ background: var(--accent); border-color: var(--accent); color: #fff; }}
ol.steps {{ list-style: none; counter-reset: step; padding: 0; margin: 1rem 0 0; display: grid; gap: 1rem; }}
ol.steps li {{ counter-increment: step; position: relative; padding-left: 3rem; max-width: 80ch; }}
ol.steps li::before {{ content: counter(step); position: absolute; left: 0; top: 0; width: 2.1rem; height: 2.1rem; border-radius: 50%; background: var(--accent-soft); color: var(--accent-ink); font-weight: 500; display: grid; place-items: center; font-variant-numeric: tabular-nums; }}
ol.steps p {{ margin: 0.25rem 0 0; }}
.tag {{ display: inline-block; font-size: 0.72rem; font-weight: 500; letter-spacing: 0.04em; padding: 0.1rem 0.45rem; border-radius: 4px; vertical-align: middle; }}
.tag-r {{ background: var(--accent-soft); color: var(--accent-ink); }}
.tag-py {{ background: var(--accent-2-soft); color: var(--accent-2); }}
.lang-head {{ display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; }}
.lang-head .tag {{ font-size: 0.85rem; padding: 0.2rem 0.6rem; }}
pre.cmd {{ background: var(--code-bg); padding: 0.75rem 1rem; border-radius: 6px; overflow-x: auto; margin-block: 0.5rem 1rem; font-size: 0.9rem; }}
.script {{ margin-block: 1rem; }}
.script-desc {{ margin: 0 0 0.35rem; max-width: 80ch; }}
details.code {{ border: 1px solid var(--line); border-radius: 6px; background: var(--surface); }}
details.code summary {{ cursor: pointer; padding: 0.55rem 0.9rem; display: flex; justify-content: space-between; gap: 1rem; list-style: none; }}
details.code summary::-webkit-details-marker {{ display: none; }}
details.code summary::before {{ content: "\\25B8"; margin-right: 0.5rem; color: var(--muted); }}
details.code[open] summary::before {{ content: "\\25BE"; }}
details.code summary .file {{ font-family: var(--font-mono); font-size: 0.88rem; }}
details.code summary .meta {{ color: var(--muted); font-size: 0.85rem; white-space: nowrap; }}
.code-body {{ position: relative; border-top: 1px solid var(--line); }}
.code-body pre {{ margin: 0; padding: 1rem; overflow-x: auto; background: var(--code-bg); max-height: 32rem; overflow-y: auto; line-height: 1.45; }}
button.copy {{ position: absolute; top: 0.5rem; right: 0.6rem; font: inherit; font-size: 0.78rem; padding: 0.2rem 0.6rem; border: 1px solid var(--line); border-radius: 4px; background: var(--surface); color: var(--fg); cursor: pointer; }}
.hljs-keyword, .hljs-built_in, .hljs-literal {{ color: var(--hl-kw); }}
.hljs-string {{ color: var(--hl-str); }}
.hljs-number {{ color: var(--hl-num); }}
.hljs-comment {{ color: var(--hl-cmt); font-style: italic; }}
.hljs-title, .hljs-title.function_ {{ color: var(--hl-fn); }}
figure {{ margin: 1.5rem 0; }}
figure img {{ max-width: 100%; height: auto; border: 1px solid var(--line); border-radius: 6px; background: #fff; }}
figcaption {{ color: var(--muted); font-size: 0.9rem; margin-top: 0.4rem; max-width: 80ch; }}
.files {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 0.5rem 1.5rem; padding: 0; list-style: none; max-width: none; }}
.files li {{ max-width: none; font-size: 0.95rem; }}
.callout {{ border-left: 3px solid var(--accent-2); background: var(--surface); padding: 0.75rem 1rem; border-radius: 0 6px 6px 0; max-width: 80ch; margin-block: 1rem; }}
.callout p {{ margin: 0.25rem 0; }}
footer {{ color: var(--muted); font-size: 0.85rem; border-top: 1px solid var(--line); padding-block: 1.5rem; }}
@media (prefers-reduced-motion: no-preference) {{ html {{ scroll-behavior: smooth; }} }}
@media (max-width: 640px) {{ .topnav .brand {{ width: 100%; }} td {{ max-width: 30ch; }} }}
</style>

<nav class="topnav" aria-label="Sections"><div class="inner">
  <span class="brand">Scarcity Replication Guide</span>
  <a href="#overview">Overview</a><a href="#data">Data</a><a href="#workflow">Workflow</a><a href="#r">R</a><a href="#python">Python</a>
  <a href="#results">Results</a><a href="#figures">Figures</a><a href="#jasp">JASP</a>
</div></nav>

<div class="wrap">
<header class="hero">
  <span class="eyebrow">Reproducible analysis package</span>
  <h1>Does scarcity impede cognitive function? Five preregistered experiments, reanalysed step by step</h1>
  <p>This page lets anyone repeat the analyses of the paper from the anonymised data, in R or in Python. Every table and figure below was produced by the scripts shown on this page, and every number agrees with the paper.</p>
  <div class="glance">
    <div><b>{N_total:,}</b><span>participants in five studies</span></div>
    <div><b>18</b><span>high- vs low-scarcity comparisons</span></div>
    <div><b>g = {g_cell}</b><span>pooled effect on the Reflection score</span></div>
    <div><b>8</b><span>scarcity techniques, each with a low-scarcity version</span></div>
  </div>
</header>

<section id="overview">
  <span class="eyebrow">1. Overview</span>
  <h2>The studies</h2>
  <p>Scarcity theory predicts that reminding people who lack resources of their scarcity lowers their cognitive performance. Five preregistered online experiments with UK and US adults compared eight techniques for inducing scarcity, each against a matched low-scarcity version, and measured scarcity concerns (the manipulation check), cognitive reflection and fluid intelligence. Studies 2 to 5 predicted that the manipulations would raise concerns and lower cognitive performance among low-income but not high-income participants.</p>
  {overview_tbl}
  <h3>Samples</h3>
  <p>Effective income is household income after tax (bracket midpoint) divided by the square root of household size, in GBP for Studies 1 and 2 and USD for Studies 3 to 5. The preregistered median split within each study defines the income groups; participants at the median are in the high-income group.</p>
  {sample_tbl}
</section>

<section id="data">
  <span class="eyebrow">2. Data</span>
  <h2>Anonymised data</h2>
  <p>The files below are the analysis data sets: one row per participant, one file per study, and one file with all five studies. They were built from the raw survey exports by the preparation scripts and contain only the variables needed for the analyses and the codebook.</p>
  <div class="callout">
    <p><strong>What was removed.</strong> {E("; ".join(IDENTIFIERS_REMOVED))}.</p>
    <p><strong>What was kept.</strong> The survey's own demographics (age, gender, education, household income bracket and size) and, for Studies 2 to 5, the demographic fields of the participants' Prolific profiles: sex, gender identity, age, nationality, country of birth and residence, first and fluent languages, employment and student status, ethnicity (Study 5) and the screening household-income bracket (variables <code>prolific_*</code>). Study 1 has no Prolific export. Prolific's missing-value markers are blank.</p>
    <p><strong>What was changed.</strong> The participant number from the export was replaced by a new sequential number assigned after a seeded random shuffle of the rows, so that neither the number nor the row order can be linked to the raw export. All cell means, standard deviations and sizes are unchanged.</p>
    <p><strong>Audit.</strong> {E(audit_line)} The Prolific fields are ordinary demographics, not identifiers, but rare combinations (an uncommon nationality or language together with age and sex) could in principle narrow down a person; they are published here at the authors' decision.</p>
  </div>
  <ul class="files">
    <li><a href="data/study1.csv">study1.csv</a> (Study 1, N = {int(samples.loc[samples.study == 1, 'n'].iloc[0]):,})</li>
    <li><a href="data/study2.csv">study2.csv</a> (Study 2, N = {int(samples.loc[samples.study == 2, 'n'].iloc[0]):,})</li>
    <li><a href="data/study3.csv">study3.csv</a> (Study 3, N = {int(samples.loc[samples.study == 3, 'n'].iloc[0]):,})</li>
    <li><a href="data/study4.csv">study4.csv</a> (Study 4, N = {int(samples.loc[samples.study == 4, 'n'].iloc[0]):,})</li>
    <li><a href="data/study5.csv">study5.csv</a> (Study 5, N = {int(samples.loc[samples.study == 5, 'n'].iloc[0]):,})</li>
    <li><a href="data/all_studies.csv">all_studies.csv</a> (all studies, N = {N_total:,})</li>
    <li><a href="codebook/codebook.html">Codebook</a> (also as <a href="codebook/codebook.csv">codebook.csv</a>)</li>
  </ul>
  <h3>Conditions</h3>
  <p>Each technique has a high-scarcity and a matched low-scarcity version. In Studies 2 to 4 the generic and the COVID-19 picture conditions share one low-scarcity picture condition.</p>
  <details class="code"><summary><span class="file">Conditions by study</span><span class="meta">{len(cond)} rows</span></summary><div class="code-body">{cond_tbl}</div></details>
  <h3>Codebook</h3>
  <p>Every variable with its coding. The scoring keys: CRT items 1 to 3 are correct with option 1 (in Study 3: "5 pence", "5 minutes", "47 days"); the belief-bias syllogism with option 2 ("No"); the base-rate item (Study 1 only) and the conjunction item with option 1. Raven items E6, E8 and E9 are correct with options 5, 6 and 3. The Financial Concerns Scale reverses items 1, 2 and 4; the Financial Concerns Questionnaire reverses items 1, 2, 4, 7, 8 and 13; the Scarcity Concerns Scale has no reversed items. All concern scales are summed.</p>
  <details class="code"><summary><span class="file">All {len(cb)} variables</span><span class="meta">codebook.csv</span></summary><div class="code-body">{codebook_tbl}</div></details>
</section>

<section id="workflow">
  <span class="eyebrow">3. Workflow</span>
  <h2>Four steps, the same in both languages</h2>
  <p>Run the steps in order from the project folder. Each step reads the outputs of the previous one and writes CSV tables to <code>output/tables</code> and figures to <code>output/figures</code>.</p>
  <ol class="steps">{steps_html}</ol>
</section>

<section id="r">
  <div class="lang-head"><span class="eyebrow">4. R</span><span class="tag tag-r">R 4.6, metafor 5.2</span></div>
  <h2>Running the analysis in R</h2>
  <p>R is the reference implementation: the paper's meta-analyses were done with the metafor package, and the scripts call the same functions (<code>rma.mv</code>, <code>vcalc</code>). Install the packages once, then run everything with one command from the project folder, or open <code>Analysis.Rproj</code> in RStudio and source <code>R/run_all.R</code>.</p>
  <pre class="cmd"><code class="language-r">install.packages(c("readr", "dplyr", "tidyr", "purrr", "stringr", "car", "psych", "metafor", "ggplot2"))</code></pre>
  <pre class="cmd"><code class="language-bash">Rscript R/run_all.R</code></pre>
  <p>The whole pipeline takes about two minutes. Expand a script to read it; the copy button copies the file.</p>
  {r_code}
</section>

<section id="python">
  <div class="lang-head"><span class="eyebrow">5. Python</span><span class="tag tag-py">Python 3.12+, pandas, scipy, statsmodels</span></div>
  <h2>Running the analysis in Python</h2>
  <p>The Python pipeline repeats every step independently of R. It produces identical processed data and identical per-study results, and its meta-analysis, which implements the multilevel REML model directly because Python has no metafor, agrees with R to at least four decimals. Use it as a cross-check or if you prefer Python.</p>
  <pre class="cmd"><code class="language-bash">pip install -r python/requirements.txt</code></pre>
  <pre class="cmd"><code class="language-bash">python3 python/run_all.py</code></pre>
  <p>The Python pipeline takes about ten minutes, most of it in the meta-analysis models.</p>
  {py_code}
</section>

<section id="results">
  <span class="eyebrow">6. Results</span>
  <h2>Tables</h2>
  <p>All tables are the R output (<code>output/tables</code>); the Python output is identical. Values are shown as in the paper.</p>
  <h3>Reliability (Cronbach's alpha)</h3>
  {rel_tbl}
  <h3>Omnibus ANOVAs (Type III sums of squares)</h3>
  <p>Condition by income-group ANOVAs on each measure. Study 1 reported the one-way condition effect, F(8, 2432) = 1.42 for concerns and 1.24 for cognitive reflection; its condition by income interaction is shown here.</p>
  {anova_tbl}
  <h3>Income groups</h3>
  <p>Two-tailed Student's t tests of the high- minus the low-income group with Cohen's d.</p>
  {income_tbl}
  <h3>Preregistered contrasts (Tables 2 to 6)</h3>
  <div class="tabs" role="tablist" aria-label="Study">{tabs_btn}</div>
  {tabs_panels}
  <h3>Pooled effects across the 18 comparisons (Table 7)</h3>
  <p>Hedges' g for high minus low scarcity from multilevel random-effects models (REML, t tests on k &minus; p df), with the within-income-group estimates and their difference (b, low minus high income). The equivalence p tests the pooled estimate against the bounds g = &plusmn;0.20.</p>
  {table7}
  <h3>Techniques used in more than one study (Table 8)</h3>
  <p>Technique entered as a categorical moderator without an intercept; scarcity concerns are modelled without Study 3, whose resource scarcity measure showed reversed effects. The condition by income difference for the COVID-19 pictures on cognitive reflection does not survive a Holm correction for the 12 low-income tests (adjusted p = {fmt_p(float(t8.loc[(t8.technique == 'COVID-19 pictures') & (t8.measure == 'Cognitive reflection'), 'p_low_holm'].iloc[0]))}).</p>
  {table8}
  <h3>Income and cognition, pooled across studies</h3>
  {incpool_tbl}
</section>

<section id="figures">
  <span class="eyebrow">7. Figures</span>
  <h2>Figures</h2>
  <p>Produced by <code>R/04_figures.R</code>; the matplotlib versions from <code>python/figures.py</code> show the same numbers and are linked under each figure.</p>
  {fig_html}
</section>

<section id="jasp">
  <span class="eyebrow">8. JASP and jamovi</span>
  <h2>Repeating the tests by hand</h2>
  <p>The per-study tests need no code: open a study file in JASP or jamovi and use the <a href="jasp/guide.html">step-by-step guide</a>, which gives the module, the settings, the row filter for each pair of conditions and the values to expect. Reliability, ANOVA, the income-group t tests and the one-tailed contrasts reproduce exactly. JASP's meta-analysis module, which wraps metafor, reproduces the pooled estimates approximately; it cannot model the shared control groups of Studies 2 to 4 or run the equivalence tests, so for Tables 7 and 8 the R code remains the reference.</p>
</section>

<footer>Built from the pipeline outputs on 11 November 2026. Preregistrations and materials: https://osf.io/mkzan/</footer>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<script>
(function () {{
  if (window.hljs) {{ document.querySelectorAll('pre code').forEach(function (el) {{ hljs.highlightElement(el); }}); }}
  var tabs = document.querySelectorAll('[role="tab"]');
  tabs.forEach(function (tab) {{
    tab.addEventListener('click', function () {{
      tabs.forEach(function (t) {{ t.setAttribute('aria-selected', 'false'); document.getElementById(t.getAttribute('aria-controls')).hidden = true; }});
      tab.setAttribute('aria-selected', 'true'); document.getElementById(tab.getAttribute('aria-controls')).hidden = false;
    }});
  }});
  document.querySelectorAll('button[data-copy]').forEach(function (btn) {{
    btn.addEventListener('click', function () {{
      var code = btn.parentNode.querySelector('code').textContent;
      var done = function () {{ btn.textContent = 'Copied'; setTimeout(function () {{ btn.textContent = 'Copy'; }}, 1500); }};
      if (navigator.clipboard && navigator.clipboard.writeText) {{
        navigator.clipboard.writeText(code).then(done, function () {{ selectText(btn); }});
      }} else {{ selectText(btn); }}
    }});
  }});
  function selectText(btn) {{
    var pre = btn.parentNode.querySelector('pre'); var range = document.createRange(); range.selectNodeContents(pre);
    var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range); btn.textContent = 'Selected: press copy';
    setTimeout(function () {{ btn.textContent = 'Copy'; }}, 2500);
  }}
}})();
</script>
"""
(SITE / "index.html").write_text(page, encoding="utf-8")

# manifest of the files published next to the page
files = {}
for n, _ in FIGURES:
    files[f"figures/{n}.png"] = f"output/figures/{n}.png"
    files[f"figures/{n}_python.png"] = f"output/figures/{n}_python.png"
for s in range(1, 6):
    files[f"data/study{s}.csv"] = f"data/public/study{s}.csv"
files["data/all_studies.csv"] = "data/public/all_studies.csv"
for p, _ in R_FILES + PY_FILES:
    files[f"code/{p}"] = {"from": p, "contentType": "text/plain; charset=utf-8"}
SUBPAGE_CSS = "<style>" + page[page.index("<style>") + 7:page.index("</style>")].replace("{{", "{").replace("}}", "}") + ".back { margin: 1.5rem 0 0; } h1 { margin-top: 1rem; } h2 { margin-top: 2rem; } h3 { margin-top: 1.5rem; } table td { max-width: 60ch; }</style>"
(SITE / "codebook").mkdir(exist_ok=True); (SITE / "jasp").mkdir(exist_ok=True)
(SITE / "codebook" / "codebook.html").write_text(md_to_html((PROJECT_ROOT / "codebook" / "codebook.md").read_text(encoding="utf-8"), "Codebook", SUBPAGE_CSS), encoding="utf-8")
(SITE / "jasp" / "guide.html").write_text(md_to_html((PROJECT_ROOT / "jasp" / "JASP_replication_guide.md").read_text(encoding="utf-8"), "Replicating the analyses in JASP", SUBPAGE_CSS), encoding="utf-8")
files["codebook/codebook.html"] = "site/codebook/codebook.html"
files["codebook/codebook.csv"] = "codebook/codebook.csv"
files["jasp/guide.html"] = "site/jasp/guide.html"
(SITE / "files.json").write_text(json.dumps(files, indent=1))
size = (SITE / "index.html").stat().st_size
print(f"site/index.html written ({size / 1024:.0f} KB); {len(files)} supporting files listed in site/files.json")

# ---- standalone, editable copy ----------------------------------------------
# A complete HTML document (the published page is wrapped by the artifact
# host at publish time) with every linked file copied next to it, so that it
# can be opened, edited and moved as a folder; also zipped.
import shutil
STANDALONE = SITE / "standalone"
if STANDALONE.exists():
    shutil.rmtree(STANDALONE)
STANDALONE.mkdir(parents=True)
link_line = next(line for line in page.splitlines() if line.startswith("<link rel=\"stylesheet\""))
style_block = page[page.index("<style>"):page.index("</style>") + len("</style>")]
body_html = page[page.index("</style>") + len("</style>"):].strip()
SECTION_NAMES = {"overview": "1. Overview", "data": "2. Data", "workflow": "3. Workflow", "r": "4. R", "python": "5. Python",
                 "results": "6. Results", "figures": "7. Figures", "jasp": "8. JASP and jamovi"}
for sid, name in SECTION_NAMES.items():
    body_html = body_html.replace(f'<section id="{sid}">', f'\n<!-- ===================== {name} ===================== -->\n<section id="{sid}">')
body_html = body_html.replace('<nav class="topnav"', '<!-- ===================== Navigation ===================== -->\n<nav class="topnav"')
body_html = body_html.replace('<header class="hero">', '<!-- ===================== Title block ===================== -->\n<header class="hero">')
body_html = body_html.replace('<script src="https://cdnjs', '<!-- ===================== Scripts: syntax highlighting, study tabs, copy buttons ===================== -->\n<script src="https://cdnjs')
standalone = ("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
              "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n"
              "<title>Scarcity Replication Guide</title>\n"
              "<!-- Scarcity Replication Guide. Generated by python/build_site.py from the analysis outputs; the text can be edited freely.\n"
              "     Tables and figures come from output/tables and output/figures; the linked files are in the folders next to this file. -->\n"
              + link_line + "\n" + style_block + "\n</head>\n<body>\n" + body_html + "\n</body>\n</html>\n")
(STANDALONE / "index.html").write_text(standalone, encoding="utf-8")
for published, source in files.items():
    src = PROJECT_ROOT / (source["from"] if isinstance(source, dict) else source)
    dst = STANDALONE / published
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
zip_path = shutil.make_archive(str(SITE / "scarcity_replication_site"), "zip", root_dir=SITE, base_dir="standalone")
print(f"standalone copy: {STANDALONE / 'index.html'} ({(STANDALONE / 'index.html').stat().st_size / 1024:.0f} KB) with {len(files)} files; zip: {zip_path} ({Path(zip_path).stat().st_size / 1e6:.1f} MB)")
