"""
study_analyses.py -- per-study analyses (Studies 1 to 5), Python version

Mirrors R/02_study_analyses.R: reliabilities, Type III ANOVAs, income-group
differences, and the preregistered high- versus low-scarcity contrasts in
the full sample and within income groups, with the condition x income
interaction for each pair of conditions (Tables 2 to 6 of the paper).

Output: output/tables/study<k>_*_python.csv and all_contrasts_python.csv
Run from the project root:  python3 python/study_analyses.py
"""
import numpy as np
import pandas as pd
from scipy import stats

from setup import (DIR_TABLES, COMPARISONS, MEASURES, concern_label, contrast_test, interaction_test,
                   anova_type3, cronbach_alpha, group_test, fmt_p, fmt2, read_processed)

pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 40)


def reliability_table(d, s):
    items = {}
    if s == 1:
        items["Scarcity concerns (FCS, 5 items)"] = pd.DataFrame({"1": 8 - d["fcs_1"], "2": 8 - d["fcs_2"], "3": d["fcs_3"], "4": 8 - d["fcs_4"], "5": d["fcs_5"]})
        items["Cognitive reflection (CPT, 6 items)"] = d[["crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "base_rate_correct", "conjunction_correct"]]
        items["Cognitive reflection (5 common items)"] = d[["crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "conjunction_correct"]]
    else:
        if s == 3:
            items["Scarcity concerns (SCS, 4 items)"] = d[[f"scs_{k}" for k in range(1, 5)]]
        else:
            rev = {1, 2, 4, 7, 8, 13}
            items["Scarcity concerns (FCQ, 15 items)"] = pd.DataFrame({f"i{k}": (8 - d[f"fcq_{k}"]) if k in rev else d[f"fcq_{k}"] for k in range(1, 16)})
        cpt = ["crt1_correct", "crt2_correct", "crt3_correct", "belief_bias_correct", "conjunction_correct"]
        rav = ["raven_e6_correct", "raven_e8_correct", "raven_e9_correct"]
        items["Cognitive reflection (CPT, 5 items)"] = d[cpt]
        items["Fluid intelligence (3 Raven items)"] = d[rav]
        items["Reflection score (8 items)"] = d[cpt + rav]
    return pd.DataFrame([dict(study=s, scale=k, k_items=v.shape[1], alpha=cronbach_alpha(v)) for k, v in items.items()])


def run_study(s):
    d = read_processed(s)
    measures = MEASURES[MEASURES["measure"].isin(d.columns)].copy()
    measures["label"] = [concern_label(s) if m == "concerns" else lab for m, lab in zip(measures["measure"], measures["label"])]
    comps = COMPARISONS[COMPARISONS["study"] == s]
    mcols = list(measures["measure"])

    # Descriptives
    agg = {m: ["mean", "std"] for m in mcols}
    desc_cond = d.groupby("condition", observed=True).agg(n=("id", "size"), **{f"{m}_{f}": (m, f) for m in mcols for f in ("mean", "std")}).reset_index()
    desc_cond.insert(1, "income_group", "All")
    desc_inc = d.groupby(["condition", "income_group"], observed=True).agg(n=("id", "size"), **{f"{m}_{f}": (m, f) for m in mcols for f in ("mean", "std")}).reset_index()
    descriptives = pd.concat([desc_cond, desc_inc], ignore_index=True)
    descriptives.insert(0, "study", s)
    descriptives.columns = [c.replace("_std", "_sd") for c in descriptives.columns]

    # Sample description
    lo, hi = d[d["income_group"] == "Low"], d[d["income_group"] == "High"]
    sample = pd.DataFrame([dict(study=s, n=len(d), age_mean=d["age"].mean(), age_sd=d["age"].std(),
                                n_women=int((d["gender"] == 1).sum()), n_men=int((d["gender"] == 2).sum()), n_other=int((d["gender"] == 3).sum()),
                                income_median=d["effective_income"].median(), n_low_income=len(lo), n_high_income=len(hi),
                                income_low_mean=lo["effective_income"].mean(), income_low_sd=lo["effective_income"].std(),
                                income_high_mean=hi["effective_income"].mean(), income_high_sd=hi["effective_income"].std())])

    # ANOVAs
    rows = []
    for m in mcols:
        a = anova_type3(f"{m} ~ condition", d); a["model"] = "condition"
        b = anova_type3(f"{m} ~ condition * income_group", d); b["model"] = "condition x income group"
        t = pd.concat([a, b]); t["measure"] = m; rows.append(t)
    anovas = pd.concat(rows, ignore_index=True); anovas.insert(0, "study", s)
    anovas = anovas[["study", "measure", "model", "term", "df1", "df2", "F", "p", "partial_eta2"]]

    # Income groups (high minus low, two-tailed)
    income = pd.DataFrame([dict(measure=m, **group_test(hi[m], lo[m])) for m in mcols])
    income = income.rename(columns=dict(n_x="n_high_income", n_y="n_low_income", m_x="m_high_income", sd_x="sd_high_income", m_y="m_low_income", sd_y="sd_low_income"))
    income.insert(0, "study", s)

    # Preregistered contrasts
    rows = []
    for _, cp in comps.iterrows():
        for _, mm in measures.iterrows():
            m, direction = mm["measure"], mm["direction"]
            inter = interaction_test(d, m, cp["high"], cp["low"], direction)
            for samp, sub in [("All", d), ("Low income", lo), ("High income", hi)]:
                res = contrast_test(sub, m, cp["high"], cp["low"], direction)
                rows.append(dict(study=s, technique=cp["technique"], high_condition=cp["high"], low_condition=cp["low"],
                                 measure=m, measure_label=mm["label"], direction=direction, sample=samp, **res, **inter))
    contrasts = pd.DataFrame(rows)

    # Paper-style table
    tab = contrasts.copy()
    tab["cell"] = [f"{fmt2(x)} ({fmt_p(p)})" for x, p in zip(tab["d"], tab["p_one_tailed"])]
    wide = tab.pivot_table(index=["study", "technique", "measure_label"], columns="sample", values="cell", aggfunc="first", sort=False)
    first = tab[tab["sample"] == "All"].set_index(["study", "technique", "measure_label"])
    table_ms = pd.DataFrame({
        "n_high": first["n_high"], "n_low": first["n_low"],
        "all_participants": wide["All"], "low_income": wide["Low income"], "high_income": wide["High income"],
        "income_x_condition": [f"{fmt2(t)} ({fmt_p(p)})" for t, p in zip(first["t_interaction"], first["p_interaction_one_tailed"])],
    }).reset_index().rename(columns={"measure_label": "measure"})

    extra = {}
    if s == 1:
        extra["scale_manipulation_check"] = pd.DataFrame([contrast_test(d, "scale_rating", "Scale high", "Scale low", "less")])
        extra["lottery_attention_checks"] = (d[d["technique"] == "Lottery"].groupby("condition", observed=True)
                                             .agg(pct_max_correct=("lottery_check_max_correct", lambda x: 100 * x.mean()),
                                                  pct_actual_correct=("lottery_check_actual_correct", lambda x: 100 * x.mean())).reset_index())

    rel = reliability_table(d, s)
    for name, obj in [("descriptives", descriptives), ("sample", sample), ("reliability", rel), ("anova", anovas),
                      ("income_groups", income), ("contrasts", contrasts), ("table", table_ms)] + list(extra.items()):
        obj.to_csv(DIR_TABLES / f"study{s}_{name}_python.csv", index=False)

    print(f"\n==================== Study {s} (N = {len(d)}) ====================")
    print("Reliability:"); print(rel[["scale", "k_items", "alpha"]].round(3).to_string(index=False))
    a = anovas.copy(); a["p"] = a["p"].map(fmt_p); a["F"] = a["F"].round(3); a["partial_eta2"] = a["partial_eta2"].round(3)
    print("\nANOVAs (Type III):"); print(a.drop(columns="study").to_string(index=False))
    print("\nIncome groups (high minus low):")
    print(income[["measure", "m_high_income", "m_low_income", "t", "df", "p", "d"]].round(3).to_string(index=False))
    print("\nHigh- versus low-scarcity contrasts (d with one-tailed p; interaction t with one-tailed p):")
    print(table_ms.drop(columns="study").to_string(index=False))
    for k, v in extra.items():
        print(f"\n{k}:"); print(v.round(3).to_string(index=False))
    return dict(contrasts=contrasts, anovas=anovas, income=income, reliability=rel, sample=sample)


def main():
    results = [run_study(s) for s in range(1, 6)]
    allc = pd.concat([r["contrasts"] for r in results], ignore_index=True)
    allc.to_csv(DIR_TABLES / "all_contrasts_python.csv", index=False)
    for key in ("anovas", "income", "reliability", "sample"):
        pd.concat([r[key] for r in results], ignore_index=True).to_csv(DIR_TABLES / f"all_{key}_python.csv", index=False)
    rc = allc[(allc["technique"] == "Recall") & (allc["measure"] == "concerns") & (allc["sample"] == "All")]
    nh, nl = int(rc["n_high"].sum()), int(rc["n_low"].sum())
    p = stats.binomtest(nh, nh + nl).pvalue
    print(f"\nRecall completions, high vs low scarcity: {nh} vs {nl}, binomial p = {p:.3f}")
    pd.DataFrame([dict(n_recall_high=nh, n_recall_low=nl, binomial_p=p)]).to_csv(DIR_TABLES / "recall_completion_binomial_python.csv", index=False)


if __name__ == "__main__":
    main()
