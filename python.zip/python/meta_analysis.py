"""
meta_analysis.py -- meta-analyses of the 18 high- versus low-scarcity
comparisons, Python version (mirrors R/03_meta_analysis.R)

Python has no equivalent of the metafor package, so this script implements
the models directly:
  * Hedges' g with its sampling variance, and the covariance between effect
    sizes that share a low-scarcity group (the formula used by metafor::vcalc
    with group sizes w1/w2)
  * multilevel random-effects models estimated by restricted maximum
    likelihood (REML) with a known sampling (co)variance matrix, t tests on
    k - p degrees of freedom (as metafor::rma.mv with test = "t")
  * single-level random-effects models with the Knapp-Hartung adjustment
  * equivalence tests against g = +/-0.20 (TOST)

Output: output/tables/meta_*_python.csv, and output/checks/meta_r_vs_python.csv
(a comparison with the R results).
Run from the project root:  python3 python/meta_analysis.py
"""
import numpy as np
import pandas as pd
from scipy import optimize, stats

from setup import (DIR_TABLES, DIR_CHECKS, COMPARISONS, MEASURES, hedges_g, contrast_test, interaction_test, read_processed, fmt_p, fmt2)

pd.set_option("display.width", 230)
pd.set_option("display.max_columns", 40)

DATA = {s: read_processed(s) for s in range(1, 6)}
REPEATED = ["Recall", "Scenario", "Generic pictures", "COVID-19 pictures"]


# ---- 1. effect sizes --------------------------------------------------------

def build_es(crs_var="crs5", income_var="income_group"):
    rows = []
    for i, cp in COMPARISONS.iterrows():
        d = DATA[cp["study"]]
        inc = d[income_var]
        for m in ["concerns", "crs", "fis", "reflection"]:
            col = crs_var if m == "crs" else m
            if col not in d.columns:
                continue
            for smp in ["All", "Low", "High"]:
                dd = d if smp == "All" else d[inc == smp]
                x = dd.loc[dd["condition"] == cp["high"], col].to_numpy(float)
                y = dd.loc[dd["condition"] == cp["low"], col].to_numpy(float)
                g, vi = hedges_g(x, y)
                rows.append(dict(study=cp["study"], technique=cp["technique"], comparison_id=i + 1, measure=m, sample=smp,
                                 yi=g, vi=vi, n_high=len(x), n_low=len(y), grp_high=cp["high"], grp_low=cp["low"]))
    es = pd.DataFrame(rows)
    es["row_id"] = np.arange(1, len(es) + 1)
    es["cluster"] = es["study"].astype(str) + " " + es["sample"]
    return es


def vcalc(sub):
    """Sampling variance-covariance matrix with covariance between contrasts
    that share a group within a cluster (metafor::vcalc with w1, w2)."""
    sub = sub.reset_index(drop=True)
    k = len(sub)
    V = np.diag(sub["vi"].to_numpy(float))
    for i in range(k):
        for j in range(i + 1, k):
            if sub.loc[i, "cluster"] != sub.loc[j, "cluster"]:
                continue
            w1i, w2i, w1j, w2j = sub.loc[i, "n_high"], sub.loc[i, "n_low"], sub.loc[j, "n_high"], sub.loc[j, "n_low"]
            num = ((sub.loc[i, "grp_high"] == sub.loc[j, "grp_high"]) * np.sqrt(1 / w1i / w1j)
                   - (sub.loc[i, "grp_high"] == sub.loc[j, "grp_low"]) * np.sqrt(1 / w1i / w2j)
                   - (sub.loc[i, "grp_low"] == sub.loc[j, "grp_high"]) * np.sqrt(1 / w2i / w1j)
                   + (sub.loc[i, "grp_low"] == sub.loc[j, "grp_low"]) * np.sqrt(1 / w2i / w2j))
            cor = num / (np.sqrt(1 / w1i + 1 / w2i) * np.sqrt(1 / w1j + 1 / w2j))
            V[i, j] = V[j, i] = cor * np.sqrt(sub.loc[i, "vi"] * sub.loc[j, "vi"])
    return V


# ---- 2. the model -----------------------------------------------------------

def indicator(values):
    codes, _ = pd.factorize(pd.Series(values))
    Z = np.zeros((len(codes), codes.max() + 1))
    Z[np.arange(len(codes)), codes] = 1
    return Z


class RandomEffectsModel:
    """y = X b + sum_k u_k + e, u_k ~ N(0, sigma2_k Z_k Z_k'), e ~ N(0, V).
    REML estimation; t tests with df = k - p (metafor's 'residual' dfs)."""

    def __init__(self, y, V, X, Z_list, knha=False):
        self.y, self.V, self.X = np.asarray(y, float), np.asarray(V, float), np.asarray(X, float)
        self.Z = [np.asarray(Z, float) for Z in Z_list]
        self.k, self.p = self.X.shape
        self.df = self.k - self.p
        self._fit(knha)

    def _M(self, s2):
        M = self.V.copy()
        for s, Z in zip(s2, self.Z):
            M += s * Z @ Z.T
        return M

    def _neg_reml(self, s2):
        M = self._M(s2)
        try:
            L = np.linalg.cholesky(M)
        except np.linalg.LinAlgError:
            return 1e10
        Mi = np.linalg.inv(M)
        XtMiX = self.X.T @ Mi @ self.X
        beta = np.linalg.solve(XtMiX, self.X.T @ Mi @ self.y)
        r = self.y - self.X @ beta
        logdetM = 2 * np.log(np.diag(L)).sum()
        return 0.5 * (logdetM + np.linalg.slogdet(XtMiX)[1] + r @ Mi @ r)

    def _fit(self, knha):
        q = len(self.Z)
        best = None
        for start in ([0.0] * q, [0.01] * q, [0.1] * q):
            res = optimize.minimize(self._neg_reml, np.array(start), method="L-BFGS-B", bounds=[(0, 5)] * q)
            if best is None or res.fun < best.fun:
                best = res
        self.sigma2 = best.x
        M = self._M(self.sigma2)
        Mi = np.linalg.inv(M)
        XtMiX = self.X.T @ Mi @ self.X
        self.cov = np.linalg.inv(XtMiX)
        self.beta = self.cov @ self.X.T @ Mi @ self.y
        r = self.y - self.X @ self.beta
        if knha:                                   # Knapp-Hartung adjustment
            self.cov = self.cov * (r @ Mi @ r) / self.df
        self.se = np.sqrt(np.diag(self.cov))
        self.t = self.beta / self.se
        self.pval = 2 * stats.t.sf(np.abs(self.t), self.df)
        crit = stats.t.ppf(0.975, self.df)
        self.ci_lb, self.ci_ub = self.beta - crit * self.se, self.beta + crit * self.se
        # residual heterogeneity (fixed-effects fit with V)
        Vi = np.linalg.inv(self.V)
        bfe = np.linalg.solve(self.X.T @ Vi @ self.X, self.X.T @ Vi @ self.y)
        rfe = self.y - self.X @ bfe
        self.QE = float(rfe @ Vi @ rfe)
        self.QEp = float(stats.chi2.sf(self.QE, self.df))
        w = 1 / np.diag(self.V)
        typical = (self.k - 1) * w.sum() / (w.sum() ** 2 - (w ** 2).sum())
        self.I2 = 100 * self.sigma2.sum() / (self.sigma2.sum() + typical)

    def coef(self, i=0):
        return dict(estimate=self.beta[i], se=self.se[i], ci_lb=self.ci_lb[i], ci_ub=self.ci_ub[i], t=self.t[i], df=self.df, p=self.pval[i])

    def ftest(self, L):
        """Wald-type F test of L b = 0 (as metafor::anova with test = 't')."""
        L = np.atleast_2d(L)
        Lb = L @ self.beta
        F = float(Lb @ np.linalg.solve(L @ self.cov @ L.T, Lb) / L.shape[0])
        return dict(F=F, df1=L.shape[0], df2=self.df, p=float(stats.f.sf(F, L.shape[0], self.df)))


def equivalence(b, se, df, bound=0.20):
    p = max(stats.t.sf((b + bound) / se, df), stats.t.cdf((b - bound) / se, df))
    crit = stats.t.ppf(0.95, df)
    return dict(p_equiv=p, ci90_lb=b - crit * se, ci90_ub=b + crit * se)


def fit_main(sub):
    sub = sub.reset_index(drop=True)
    return RandomEffectsModel(sub["yi"], vcalc(sub), np.ones((len(sub), 1)), [indicator(sub["study"]), np.eye(len(sub))])


def fit_income(sub, design):
    """design: 'groups' -> columns [High, Low]; 'diff' -> [intercept(High), Low - High]."""
    sub = sub.reset_index(drop=True)
    low = (sub["sample"] == "Low").to_numpy(float)
    X = np.column_stack([1 - low, low]) if design == "groups" else np.column_stack([np.ones(len(sub)), low])
    return RandomEffectsModel(sub["yi"], vcalc(sub), X, [indicator(sub["study"]), indicator(sub["comparison_id"]), np.eye(len(sub))])


def fmt_ci(b, lb, ub):
    return f"{fmt2(b)} [{fmt2(lb)}, {fmt2(ub)}]"


# ---- 3. pooled effects (Table 7) --------------------------------------------

def pooled_block(es, m, label, exclude_study=()):
    sub = es[(es["measure"] == m) & (es["sample"] == "All") & ~es["study"].isin(exclude_study)]
    fit = fit_main(sub); a = fit.coef(); eq = equivalence(a["estimate"], a["se"], a["df"])
    subI = es[(es["measure"] == m) & (es["sample"] != "All") & ~es["study"].isin(exclude_study)]
    fg, fd = fit_income(subI, "groups"), fit_income(subI, "diff")
    hi, lo, diff = fg.coef(0), fg.coef(1), fd.coef(1)
    eq_lo = equivalence(lo["estimate"], lo["se"], lo["df"])
    single = RandomEffectsModel(sub["yi"], np.diag(sub["vi"]), np.ones((len(sub), 1)), [np.eye(len(sub))])
    return dict(measure=label, k=len(sub),
                g_all=a["estimate"], ci_lb_all=a["ci_lb"], ci_ub_all=a["ci_ub"], p_all=a["p"], df_all=a["df"],
                p_equivalence_all=eq["p_equiv"], ci90_lb_all=eq["ci90_lb"], ci90_ub_all=eq["ci90_ub"],
                g_low=lo["estimate"], ci_lb_low=lo["ci_lb"], ci_ub_low=lo["ci_ub"], p_low=lo["p"], p_equivalence_low=eq_lo["p_equiv"],
                g_high=hi["estimate"], ci_lb_high=hi["ci_lb"], ci_ub_high=hi["ci_ub"], p_high=hi["p"],
                b_low_minus_high=diff["estimate"], ci_lb_diff=diff["ci_lb"], ci_ub_diff=diff["ci_ub"], p_diff=diff["p"],
                Q=fit.QE, Q_df=fit.df, Q_p=fit.QEp, I2=fit.I2, sigma2_study=fit.sigma2[0], sigma2_comparison=fit.sigma2[1],
                I2_single_level=single.I2,
                cell_all=fmt_ci(a["estimate"], a["ci_lb"], a["ci_ub"]), cell_low=fmt_ci(lo["estimate"], lo["ci_lb"], lo["ci_ub"]),
                cell_high=fmt_ci(hi["estimate"], hi["ci_lb"], hi["ci_ub"]),
                cell_diff=f"{fmt_ci(diff['estimate'], diff['ci_lb'], diff['ci_ub'])} ({fmt_p(diff['p'])})")


# ---- 4. techniques used in more than one study (Table 8) --------------------

def technique_design(sub, interaction=None):
    techs = list(dict.fromkeys(sub["technique"]))        # keeps order of appearance
    T = np.column_stack([(sub["technique"] == t).to_numpy(float) for t in techs])
    names = [f"technique{t}" for t in techs]
    if interaction is not None:
        T = np.column_stack([T, T * interaction[:, None]])
        names += [f"technique{t}:{'low' if True else ''}" for t in techs]
    return T, names, techs


def technique_block(es, m, label, exclude_study=()):
    sub = es[(es["measure"] == m) & (es["sample"] == "All") & ~es["study"].isin(exclude_study)].reset_index(drop=True)
    X, names, techs = technique_design(sub)
    fit = RandomEffectsModel(sub["yi"], vcalc(sub), X, [indicator(sub["study"]), np.eye(len(sub))])
    subI = es[(es["measure"] == m) & (es["sample"] != "All") & ~es["study"].isin(exclude_study)].reset_index(drop=True)
    low = (subI["sample"] == "Low").to_numpy(float)
    XI_hi, _, techsI = technique_design(subI, interaction=low)          # technique = high-income effect; technique:low = low - high
    XI_lo, _, _ = technique_design(subI, interaction=1 - low)           # technique = low-income effect
    Zs = [indicator(subI["study"]), indicator(subI["comparison_id"]), np.eye(len(subI))]
    fit_hi = RandomEffectsModel(subI["yi"], vcalc(subI), XI_hi, Zs)
    fit_lo = RandomEffectsModel(subI["yi"], vcalc(subI), XI_lo, Zs)
    present = [t for t in REPEATED if t in techs]
    L = np.array([[(1 if t == present[0] else 0) - (1 if t == other else 0) for t in techs] for other in present[1:]], float)
    ft = fit.ftest(L)
    rows = []
    nt = len(techsI)
    for tch in present:
        i = techs.index(tch); iI = techsI.index(tch)
        a = fit.coef(i); eq = equivalence(a["estimate"], a["se"], a["df"])
        hi, lo = fit_hi.coef(iI), fit_lo.coef(iI); diff = fit_hi.coef(nt + iI)
        eq_lo = equivalence(lo["estimate"], lo["se"], lo["df"])
        rows.append(dict(technique=tch, measure=label, k=int((sub["technique"] == tch).sum()),
                         g_all=a["estimate"], ci_lb_all=a["ci_lb"], ci_ub_all=a["ci_ub"], p_all=a["p"], p_equivalence_all=eq["p_equiv"],
                         g_low=lo["estimate"], ci_lb_low=lo["ci_lb"], ci_ub_low=lo["ci_ub"], p_low=lo["p"], p_equivalence_low=eq_lo["p_equiv"],
                         g_high=hi["estimate"], ci_lb_high=hi["ci_lb"], ci_ub_high=hi["ci_ub"], p_high=hi["p"],
                         b_low_minus_high=diff["estimate"], ci_lb_diff=diff["ci_lb"], ci_ub_diff=diff["ci_ub"], p_diff=diff["p"],
                         techniques_differ_F=ft["F"], F_df1=ft["df1"], F_df2=ft["df2"], techniques_differ_p=ft["p"],
                         cell_all=fmt_ci(a["estimate"], a["ci_lb"], a["ci_ub"]), cell_low=fmt_ci(lo["estimate"], lo["ci_lb"], lo["ci_ub"]),
                         cell_high=fmt_ci(hi["estimate"], hi["ci_lb"], hi["ci_ub"]),
                         cell_diff=f"{fmt_ci(diff['estimate'], diff['ci_lb'], diff['ci_ub'])} ({fmt_p(diff['p'])})"))
    return pd.DataFrame(rows)


def holm(p):
    p = np.asarray(p, float); n = len(p); order = np.argsort(p)
    adj = np.empty(n); running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, (n - rank) * p[idx]); adj[idx] = min(1.0, running)
    return adj


# ---- 5. main ----------------------------------------------------------------

def main():
    ES = build_es()
    ES.to_csv(DIR_TABLES / "meta_effect_sizes_python.csv", index=False)

    table7 = pd.DataFrame([
        pooled_block(ES, "concerns", "Scarcity concerns, all studies"),
        pooled_block(ES, "concerns", "Scarcity concerns, without Study 3", exclude_study=(3,)),
        pooled_block(ES, "crs", "Cognitive reflection"),
        pooled_block(ES, "fis", "Fluid intelligence"),
        pooled_block(ES, "reflection", "Reflection score"),
    ])
    table7.to_csv(DIR_TABLES / "meta_table7_pooled_effects_python.csv", index=False)
    print("\n==== Table 7: pooled effects (Hedges' g [95% CI]) ====")
    t7 = table7.assign(p=table7["p_all"].map(fmt_p), I2=table7["I2"].map(lambda x: f"{x:.0f}%"), p_equiv=table7["p_equivalence_all"].map(fmt_p),
                       ci90=[f"[{a:.2f}, {b:.2f}]" for a, b in zip(table7["ci90_lb_all"], table7["ci90_ub_all"])])
    print(t7[["measure", "k", "cell_all", "p", "cell_low", "cell_high", "cell_diff", "I2", "p_equiv", "ci90"]].to_string(index=False))

    # techniques differ on concerns (without Study 3)? model with intercept + technique
    sub = ES[(ES["measure"] == "concerns") & (ES["sample"] == "All") & (ES["study"] != 3)].reset_index(drop=True)
    X, names, techs = technique_design(sub)
    fit0 = RandomEffectsModel(sub["yi"], vcalc(sub), X, [indicator(sub["study"]), np.eye(len(sub))])
    L = np.array([[(1 if t == techs[0] else 0) - (1 if t == other else 0) for t in techs] for other in techs[1:]], float)
    ft = fit0.ftest(L)
    print(f"\nConcerns without Study 3: techniques differ? F({ft['df1']}, {ft['df2']}) = {ft['F']:.2f}, p = {fmt_p(ft['p'])}")
    sc = fit0.coef(techs.index("Scale"))
    print(f"Scale task (Study 1 only) on concerns, model-based estimate: g = {sc['estimate']:.2f}, 95% CI [{sc['ci_lb']:.2f}, {sc['ci_ub']:.2f}]")

    table8 = pd.concat([
        technique_block(ES, "concerns", "Scarcity concerns (without Study 3)", exclude_study=(3,)),
        technique_block(ES, "concerns", "Scarcity concerns (all studies)"),
        technique_block(ES, "crs", "Cognitive reflection"),
        technique_block(ES, "fis", "Fluid intelligence"),
        technique_block(ES, "reflection", "Reflection score"),
    ], ignore_index=True)
    cog = table8["measure"].isin(["Cognitive reflection", "Fluid intelligence", "Reflection score"])
    table8["p_low_holm"] = np.nan; table8.loc[cog, "p_low_holm"] = holm(table8.loc[cog, "p_low"])
    table8.to_csv(DIR_TABLES / "meta_table8_techniques_python.csv", index=False)
    print("\n==== Table 8: pooled effects of the techniques used in more than one study ====")
    t8 = table8.sort_values(["technique", "measure"]).assign(p_equiv_all=table8["p_equivalence_all"].map(fmt_p),
                                                             p_low_holm_f=table8["p_low_holm"].map(lambda x: "" if np.isnan(x) else fmt_p(x)),
                                                             techniques_differ=[f"F({a}, {b}) = {F:.2f}, p = {fmt_p(p)}" for a, b, F, p in zip(table8["F_df1"], table8["F_df2"], table8["techniques_differ_F"], table8["techniques_differ_p"])])
    print(t8[["technique", "measure", "k", "cell_all", "cell_low", "cell_high", "cell_diff", "p_equiv_all", "p_low_holm_f", "techniques_differ"]].to_string(index=False))

    # successful manipulation checks
    contr = pd.read_csv(DIR_TABLES / "all_contrasts_python.csv")
    success = contr[(contr["measure"] == "concerns") & (contr["sample"] == "All") & (contr["p_one_tailed"] < .05)][["study", "technique"]]
    print(f"\nComparisons with a successful manipulation check (k = {len(success)}): " + "; ".join(f"{t} (Study {s})" for s, t in zip(success["study"], success["technique"])))
    rows = []
    for m in ["crs", "reflection"]:
        sub = ES[(ES["measure"] == m) & (ES["sample"] == "All")].merge(success, on=["study", "technique"])
        a = fit_main(sub).coef()
        subI = ES[(ES["measure"] == m) & (ES["sample"] != "All")].merge(success, on=["study", "technique"])
        lo = fit_income(subI, "groups").coef(1)
        rows.append(dict(measure=m, k=len(sub), g_all=a["estimate"], ci_lb_all=a["ci_lb"], ci_ub_all=a["ci_ub"], p_all=a["p"],
                         g_low=lo["estimate"], ci_lb_low=lo["ci_lb"], ci_ub_low=lo["ci_ub"], p_low=lo["p"]))
    succ = pd.DataFrame(rows); succ.to_csv(DIR_TABLES / "meta_successful_manipulation_subset_python.csv", index=False)
    print("Pooled cognitive effects in that subset:"); print(succ.round(3).to_string(index=False))

    # meta-regression of cognitive effects on concern effects
    conc = ES[(ES["measure"] == "concerns") & (ES["sample"] == "All")][["study", "technique", "yi"]].rename(columns={"yi": "g_concerns"})
    rows = []
    for m in ["crs", "reflection"]:
        for drop3 in (False, True):
            sub = ES[(ES["measure"] == m) & (ES["sample"] == "All") & ~(drop3 & (ES["study"] == 3))].merge(conc, on=["study", "technique"]).reset_index(drop=True)
            X = np.column_stack([np.ones(len(sub)), sub["g_concerns"]])
            f = RandomEffectsModel(sub["yi"], vcalc(sub), X, [indicator(sub["study"]), np.eye(len(sub))]); c = f.coef(1)
            rows.append(dict(measure=m, without_study3=drop3, k=len(sub), b=c["estimate"], ci_lb=c["ci_lb"], ci_ub=c["ci_ub"], p=c["p"]))
    mreg = pd.DataFrame(rows); mreg.to_csv(DIR_TABLES / "meta_regression_concerns_on_cognition_python.csv", index=False)
    print("\nMeta-regression slopes:"); print(mreg.round(3).to_string(index=False))

    # leave one study out
    rows = []
    for m in ["crs", "reflection"]:
        for s in range(1, 6):
            sub = ES[(ES["measure"] == m) & (ES["sample"] == "All") & (ES["study"] != s)]
            if len(sub) == 0:
                continue
            c = fit_main(sub).coef(); rows.append(dict(measure=m, study_left_out=s, k=len(sub), g=c["estimate"], ci_lb=c["ci_lb"], ci_ub=c["ci_ub"], p=c["p"]))
    loo = pd.DataFrame(rows); loo.to_csv(DIR_TABLES / "meta_leave_one_study_out_python.csv", index=False)
    print("\nLeave-one-study-out:"); print(loo.round(3).to_string(index=False))

    # six-item Study 1 score
    ES6 = build_es(crs_var="crs")
    c6 = fit_main(ES6[(ES6["measure"] == "crs") & (ES6["sample"] == "All")]).coef()
    print(f"\nSix-item Study 1 score: cognitive reflection g = {c6['estimate']:.3f} [{c6['ci_lb']:.3f}, {c6['ci_ub']:.3f}]")

    # single-level models with Knapp-Hartung
    rows = []
    for m in ["concerns", "crs", "fis", "reflection"]:
        sub = ES[(ES["measure"] == m) & (ES["sample"] == "All")].reset_index(drop=True)
        f = RandomEffectsModel(sub["yi"], np.diag(sub["vi"]), np.ones((len(sub), 1)), [np.eye(len(sub))], knha=True); c = f.coef()
        rows.append(dict(measure=m, k=len(sub), g=c["estimate"], ci_lb=c["ci_lb"], ci_ub=c["ci_ub"], p=c["p"], I2=f.I2, tau2=f.sigma2[0]))
    kh = pd.DataFrame(rows); kh.to_csv(DIR_TABLES / "meta_single_level_knapp_hartung_python.csv", index=False)
    print("\nSingle-level models (Knapp-Hartung):"); print(kh.round(3).to_string(index=False))

    # participants at the median assigned to the low-income group
    ES_alt = build_es(income_var="income_group_ties_low")
    rows = []
    for m in ["crs", "fis", "reflection"]:
        subI = ES_alt[(ES_alt["measure"] == m) & (ES_alt["sample"] != "All")]
        fg, fd = fit_income(subI, "groups"), fit_income(subI, "diff"); lo, diff = fg.coef(1), fd.coef(1)
        rows.append(dict(measure=m, g_low=lo["estimate"], p_low=lo["p"], b_low_minus_high=diff["estimate"], ci_lb=diff["ci_lb"], ci_ub=diff["ci_ub"], p_diff=diff["p"]))
    alt = pd.DataFrame(rows); alt.to_csv(DIR_TABLES / "meta_income_ties_to_low_python.csv", index=False)
    print("\nIncome moderation with participants at the median in the low-income group:"); print(alt.round(3).to_string(index=False))

    def income_tests(income_var):
        rows = []
        for s in range(1, 6):
            d = DATA[s].copy(); d["income_group"] = d[income_var]
            for _, cp in COMPARISONS[COMPARISONS["study"] == s].iterrows():
                for _, mm in MEASURES[MEASURES["measure"].isin(d.columns)].iterrows():
                    m, direction = mm["measure"], mm["direction"]
                    rows.append(dict(p_low=contrast_test(d[d["income_group"] == "Low"], m, cp["high"], cp["low"], direction)["p_one_tailed"],
                                     p_high=contrast_test(d[d["income_group"] == "High"], m, cp["high"], cp["low"], direction)["p_one_tailed"],
                                     p_int=interaction_test(d, m, cp["high"], cp["low"], direction)["p_interaction_one_tailed"]))
        return pd.DataFrame(rows)
    tm, ta = income_tests("income_group"), income_tests("income_group_ties_low")
    changed = ((tm < .05) != (ta < .05)).to_numpy()
    print(f"Within-study tests by income group whose significance changes with the alternative split: {changed.sum()} of {changed.size}")
    cog_tests = contr[contr["measure"].isin(["crs", "fis"])]
    print(f"One-tailed tests on cognitive reflection and fluid intelligence: {(cog_tests['p_one_tailed'] < .05).sum()} of {len(cog_tests)} significant ({100 * (cog_tests['p_one_tailed'] < .05).mean():.1f}%)")
    print("Analyses without repeat participants: not reproduced (repeat participants are not identified in the exports).")

    # income and cognition pooled across studies
    rows = []
    for s in range(1, 6):
        d = DATA[s]
        for m in ["concerns", "crs5", "fis", "reflection"]:
            if m not in d.columns:
                continue
            g, vi = hedges_g(d.loc[d["income_group"] == "High", m].to_numpy(float), d.loc[d["income_group"] == "Low", m].to_numpy(float))
            rows.append(dict(study=s, measure="crs" if m == "crs5" else m, yi=g, vi=vi))
    inc = pd.DataFrame(rows); inc.to_csv(DIR_TABLES / "meta_income_group_effect_sizes_python.csv", index=False)
    rows = []
    for m in ["concerns", "crs", "fis", "reflection"]:
        sub = inc[inc["measure"] == m].reset_index(drop=True)
        f = RandomEffectsModel(sub["yi"], np.diag(sub["vi"]), np.ones((len(sub), 1)), [np.eye(len(sub))], knha=True); c = f.coef()
        rows.append(dict(measure=m, k=len(sub), g_high_minus_low_income=c["estimate"], ci_lb=c["ci_lb"], ci_ub=c["ci_ub"], p=c["p"], I2=f.I2))
    incp = pd.DataFrame(rows); incp.to_csv(DIR_TABLES / "meta_income_and_cognition_python.csv", index=False)
    print("\nIncome groups pooled across studies (high minus low income):"); print(incp.round(3).to_string(index=False))

    # ---- comparison with the R (metafor) results ----
    rows = []
    for name in ["meta_table7_pooled_effects", "meta_table8_techniques", "meta_leave_one_study_out", "meta_single_level_knapp_hartung",
                 "meta_income_and_cognition", "meta_regression_concerns_on_cognition", "meta_successful_manipulation_subset", "meta_income_ties_to_low"]:
        r = pd.read_csv(DIR_TABLES / f"{name}.csv"); p = pd.read_csv(DIR_TABLES / f"{name}_python.csv")
        num = [c for c in r.columns if c in p.columns and pd.api.types.is_numeric_dtype(r[c]) and pd.api.types.is_numeric_dtype(p[c])]
        diff = (r[num].to_numpy(float) - p[num].to_numpy(float))
        rows.append(dict(table=name, rows=len(r), numeric_columns=len(num), max_abs_difference=np.nanmax(np.abs(diff))))
    cmp = pd.DataFrame(rows); cmp.to_csv(DIR_CHECKS / "meta_r_vs_python.csv", index=False)
    print("\nR (metafor) versus Python implementation, maximum absolute difference per table:"); print(cmp.to_string(index=False))


if __name__ == "__main__":
    main()
