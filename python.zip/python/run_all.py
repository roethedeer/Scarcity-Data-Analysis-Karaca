"""
run_all.py -- runs the complete Python pipeline from the raw exports to the
tables and figures, then the replication checks.
Run from the project root:  python3 python/run_all.py
"""
import runpy
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
t0 = time.time()
for script in ["prepare_data.py", "study_analyses.py", "meta_analysis.py", "figures.py", "make_codebook.py", "compare_with_paper.py", "compare_text_statistics.py"]:
    print(f"\n\n############################ {script} ############################")
    runpy.run_path(str(HERE / script), run_name="__main__")
print(f"\nFinished in {(time.time() - t0) / 60:.1f} minutes")
