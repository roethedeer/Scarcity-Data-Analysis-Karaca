"""
Does Scarcity Impede Cognitive Function? Five Preregistered Experiments
Analysis code (Python) -- setup.py

Paths, study-design constants and the statistical helper functions shared by
all Python scripts. Mirrors R/00_setup.R.
Requires: pandas, numpy, scipy, statsmodels (see requirements.txt).
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf

# ---- paths ------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DIR_RAW = PROJECT_ROOT                      # St1.csv ... St5.csv
DIR_PROCESSED = PROJECT_ROOT / "data" / "processed"
DIR_TABLES = PROJECT_ROOT / "output" / "tables"
DIR_FIGURES = PROJECT_ROOT / "output" / "figures"
DIR_CHECKS = PROJECT_ROOT / "output" / "checks"
for _d in (DIR_PROCESSED, DIR_TABLES, DIR_FIGURES, DIR_CHECKS):
    _d.mkdir(parents=True, exist_ok=True)

# ---- study design constants -------------------------------------------------
# The 18 preregistered high- versus low-scarcity comparisons (Tables 2 to 6).
COMPARISONS = pd.DataFrame([
    (1, "Lottery", "Lottery high", "Lottery low"),
    (1, "Scale", "Scale high", "Scale low"),
    (1, "Recall", "Recall high", "Recall low"),
    (1, "Consequences", "Consequences high", "Consequences low"),
    (2, "Recall", "Recall high", "Recall low"),
    (2, "Scenario", "Scenario high", "Scenario low"),
    (2, "Generic pictures", "Generic pictures high", "Pictures low"),
    (2, "COVID-19 pictures", "COVID-19 pictures high", "Pictures low"),
    (3, "Generic pictures", "Generic pictures high", "Pictures low"),
    (3, "COVID-19 pictures", "COVID-19 pictures high", "Pictures low"),
    (4, "Recall", "Recall high", "Recall low"),
    (4, "Scenario", "Scenario high", "Scenario low"),
    (4, "Generic pictures", "Generic pictures high", "Pictures low"),
    (4, "COVID-19 pictures", "COVID-19 pictures high", "Pictures low"),
    (5, "Recall", "Recall high", "Recall low"),
    (5, "Scenario", "Scenario high", "Scenario low"),
    (5, "COVID-19 pictures", "COVID-19 pictures high", "COVID-19 pictures low"),
    (5, "Picture imagination", "Picture imagination high", "Picture imagination low"),
], columns=["study", "technique", "high", "low"])

# Outcome measures and the predicted direction of the high - low difference.
MEASURES = pd.DataFrame([
    ("concerns", "Scarcity concerns", "greater"),
    ("crs", "Cognitive reflection", "less"),
    ("fis", "Fluid intelligence", "less"),
    ("reflection", "Reflection score", "less"),
], columns=["measure", "label", "direction"])


def concern_label(study):
    return "Resource scarcity concerns" if study == 3 else "Financial concerns"


# ---- coding constants (see codebook) ----------------------------------------
INCOME_MIDPOINT = [5000, 15000, 25000, 35000, 45000, 55000, 65000, 75000, 85000, 95000, 125000, 150000]
US_INCOME_LABELS = ["Less than $10,000", "$10,000 - $19,999", "$20,000 - $29,999", "$30,000 - $39,999",
                    "$40,000 - $49,999", "$50,000 - $59,999", "$60,000 - $69,999", "$70,000 - $79,999",
                    "$80,000 - $89,999", "$90,000 - $99,999", "$100,000 - $149,999", "More than $150,000"]
AGREE7 = ["Strongly disagree", "Disagree", "Somewhat disagree", "Neither agree nor disagree",
          "Somewhat agree", "Agree", "Strongly agree"]
EDUCATION_LABELS_US = ["Some high school", "Graduated high school", "Some college (no degree)",
                       "Associate's degree or technical or vocational school", "Bachelor's degree",
                       "Some graduate or professional school", "Earned graduate or professional degree"]
KEY_NUMERIC = dict(crt1=1, crt2=1, crt3=1, belief_bias=2, base_rate=1, conjunction=1, raven_e6=5, raven_e8=6, raven_e9=3)
KEY_TEXT_STUDY3 = dict(crt1="5 pence", crt2="5 minutes", crt3="47 days", belief_bias="No", conjunction="Claire is a bank teller")
FINLIT_KEY = [2, 3, 1, 4, 3]

CONDITION_MAP = {
    1: {"Control_Passive": "Passive control",
        "Control_Lottery": "Lottery low", "Manipulation_Lottery": "Lottery high",
        "Control_Frame": "Scale low", "Manipulation_Frame": "Scale high",
        "Control_Recall": "Recall low", "Manipulation_Recall": "Recall high",
        "Control_Prime": "Consequences low", "Manipulation_Prime": "Consequences high"},
    2: {"Control": "Passive control", "Recall_Low": "Recall low", "Recall_High": "Recall high",
        "Imagine_Low": "Scenario low", "Imagine_High": "Scenario high",
        "Picture_Low": "Pictures low", "Picture_High": "Generic pictures high", "Picture_Covid": "COVID-19 pictures high"},
    3: {"Picture_Low": "Pictures low", "Picture_High": "Generic pictures high", "Picture_Covid": "COVID-19 pictures high"},
    4: {"Control": "Passive control", "Recall_Low": "Recall low", "Recall_High": "Recall high",
        "Imagine_Low": "Scenario low", "Imagine_High": "Scenario high",
        "Picture_Low": "Pictures low", "Picture_High": "Generic pictures high", "Picture_Covid": "COVID-19 pictures high"},
    5: {"Control": "Passive control", "Recall_Low": "Recall low", "Recall_High": "Recall high",
        "Imagine_Low": "Scenario low", "Imagine_High": "Scenario high",
        "Picture_Low_A": "COVID-19 pictures low", "Picture_High_A": "COVID-19 pictures high",
        "Picture_Low_B": "Picture imagination low", "Picture_High_B": "Picture imagination high"},
}
PANAS_POSITIVE = ["interested", "excited", "strong", "enthusiastic", "proud", "alert", "inspired", "determined", "attentive", "active"]
PANAS_NEGATIVE = ["distressed", "upset", "guilty", "scared", "hostile", "irritable", "ashamed", "nervous", "jittery", "afraid"]
FIRST_COLS = ["study", "id", "condition", "technique", "scarcity", "concerns", "crs", "crs5", "fis", "reflection",
              "income_group", "effective_income", "income_bracket", "income_midpoint", "household_size",
              "income_group_ties_low", "age", "gender", "education"]


# ---- statistical helpers ----------------------------------------------------

def cohens_d(x, y):
    """Mean(x) - mean(y) divided by the pooled SD."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    nx, ny = len(x), len(y)
    sp = np.sqrt(((nx - 1) * x.var(ddof=1) + (ny - 1) * y.var(ddof=1)) / (nx + ny - 2))
    return (x.mean() - y.mean()) / sp


def hedges_g(x, y):
    """Hedges' g (small-sample corrected d) and its sampling variance."""
    nx, ny = len(x), len(y)
    d = cohens_d(x, y)
    J = 1 - 3 / (4 * (nx + ny) - 9)
    g = J * d
    vg = (nx + ny) / (nx * ny) + g ** 2 / (2 * (nx + ny))
    return g, vg


def p_one_tailed(t, df, direction):
    return stats.t.sf(t, df) if direction == "greater" else stats.t.cdf(t, df)


def contrast_test(data, outcome, high, low, direction):
    """Student's t test (equal variances) of condition `high` versus `low`,
    with Cohen's d and the one-tailed p value in the predicted direction."""
    x = data.loc[data["condition"] == high, outcome].dropna().to_numpy(float)
    y = data.loc[data["condition"] == low, outcome].dropna().to_numpy(float)
    res = stats.ttest_ind(x, y, equal_var=True)
    t, df = float(res.statistic), len(x) + len(y) - 2
    return dict(n_high=len(x), n_low=len(y), m_high=x.mean(), sd_high=x.std(ddof=1), m_low=y.mean(), sd_low=y.std(ddof=1),
                d=cohens_d(x, y), t=t, df=df, p_one_tailed=float(p_one_tailed(t, df, direction)), p_two_tailed=float(res.pvalue))


def interaction_test(data, outcome, high, low, direction):
    """Condition x income-group interaction for one pair of conditions
    (OLS: outcome ~ scarcity_high * low_income), one-tailed p in the direction
    of a larger effect among low-income participants."""
    d = data[data["condition"].isin([high, low])].copy()
    d["scarcity_high"] = (d["condition"] == high).astype(float)
    d["low_income"] = (d["income_group"] == "Low").astype(float)
    fit = smf.ols(f"{outcome} ~ scarcity_high * low_income", data=d).fit()
    name = "scarcity_high:low_income"
    t, df = float(fit.tvalues[name]), int(fit.df_resid)
    return dict(b_interaction=float(fit.params[name]), t_interaction=t, df_interaction=df,
                p_interaction_one_tailed=float(p_one_tailed(t, df, direction)), p_interaction_two_tailed=float(fit.pvalues[name]))


def anova_type3(formula, data):
    """Type III ANOVA with sum-to-zero contrasts (as SPSS) and partial eta squared."""
    import re
    f = re.sub(r"\b(condition|income_group)\b", r"C(\1, Sum)", formula)
    fit = smf.ols(f, data=data).fit()
    tab = sm.stats.anova_lm(fit, typ=3)
    ss_err, df_err = tab.loc["Residual", "sum_sq"], tab.loc["Residual", "df"]
    rows = []
    for term in tab.index:
        if term in ("Intercept", "Residual"):
            continue
        clean = term.replace("C(condition, Sum)", "condition").replace("C(income_group, Sum)", "income_group")
        rows.append(dict(term=clean, df1=int(tab.loc[term, "df"]), df2=int(df_err), F=float(tab.loc[term, "F"]),
                         p=float(tab.loc[term, "PR(>F)"]), partial_eta2=float(tab.loc[term, "sum_sq"] / (tab.loc[term, "sum_sq"] + ss_err))))
    return pd.DataFrame(rows)


def cronbach_alpha(items):
    """Cronbach's alpha of a DataFrame of items (keyed in the same direction)."""
    X = np.asarray(items, float)
    k = X.shape[1]
    return k / (k - 1) * (1 - X.var(axis=0, ddof=1).sum() / X.sum(axis=1).var(ddof=1))


def group_test(x, y):
    """Two-tailed Student's t test of two groups (x minus y) with Cohen's d."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x[~np.isnan(x)], y[~np.isnan(y)]
    res = stats.ttest_ind(x, y, equal_var=True)
    return dict(n_x=len(x), n_y=len(y), m_x=x.mean(), sd_x=x.std(ddof=1), m_y=y.mean(), sd_y=y.std(ddof=1),
                d=cohens_d(x, y), t=float(res.statistic), df=len(x) + len(y) - 2, p=float(res.pvalue))


def fmt_p(p):
    return "< .001" if p < .001 else f"{p:.3f}".lstrip("0")


def fmt2(x):
    """Two decimals; a value that rounds to zero prints as 0.00, never -0.00."""
    s = f"{x:.2f}"
    return "0.00" if s == "-0.00" else s


def read_processed(study, suffix=""):
    d = pd.read_csv(DIR_PROCESSED / f"study{study}{suffix}.csv")
    d["income_group"] = pd.Categorical(d["income_group"], categories=["Low", "High"])
    return d
