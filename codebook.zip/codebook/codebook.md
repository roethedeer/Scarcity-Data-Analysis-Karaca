# Codebook: Does Scarcity Impede Cognitive Function? Five Preregistered Experiments

Processed analysis data sets built by `R/01_prepare_data.R` (identically by `python/prepare_data.py`) from the raw Qualtrics/Prolific exports of the five studies. One row per participant in the analysis sample of each study (N = 2,441; 2,198; 1,569; 2,242; 2,148; total 10,598). Files: `data/processed/study1.csv` to `study5.csv` (one per study) and `all_studies.csv` (all five stacked; variables that a study did not measure are empty).

Every score is recomputed from the item responses with the keys listed below, and the recomputation was verified against the scores stored in the original SPSS files (`output/checks/derived_vs_spss.csv`). Identifying information (Prolific IDs, IP addresses, geolocation, free-text answers from the manipulation tasks, open comments) was removed. The demographic fields of the participants' Prolific profiles (variables `prolific_*`) are included for Studies 2 to 5; Prolific's missing-value markers (DATA EXPIRED, CONSENT REVOKED, 0) are blank. The exclusions described in the paper (repeated attempts, invalid IDs, no consent, non-standard lottery bonus) were already applied in the exports.

## Variables

| Variable | Description | Coding / values | Studies | Range (n) | Source columns |
|---|---|---|---|---|---|
| `study` | Study number | 1 to 5 | 1, 2, 3, 4, 5 | 1 to 5 (10598) | file name |
| `id` | Participant number within the study | integer; Study 5: row number of the export (its ID column is empty) | 1, 2, 3, 4, 5 | 1 to 2444 (10598) | ID |
| `condition` | Experimental condition | Passive control; Lottery low/high; Scale low/high; Recall low/high; Consequences low/high; Scenario low/high; Pictures low (shared low-scarcity picture condition, Studies 2-4); Generic pictures high; COVID-19 pictures low/high; Picture imagination low/high | 1, 2, 3, 4, 5 | (10598) | Treatment (see condition table) |
| `technique` | Scarcity technique of the condition | Control; Lottery; Scale; Recall; Consequences; Scenario; Pictures; Generic pictures; COVID-19 pictures; Picture imagination | 1, 2, 3, 4, 5 | (10598) | derived from condition |
| `scarcity` | Scarcity version of the condition | High; Low; Control (passive control) | 1, 2, 3, 4, 5 | (10598) | derived from condition |
| `concerns` | Scarcity concerns (manipulation check): sum of the scale items | Study 1: Financial Concerns Scale, 5 items, 5-35; Studies 2, 4, 5: Financial Concerns Questionnaire, 15 items, 15-105; Study 3: Scarcity Concerns Scale, 4 items, 4-28; higher = more concerns | 1, 2, 3, 4, 5 | 4 to 105 (10598) | fcs_*, fcq_*, scs_* |
| `crs` | Cognitive reflection score: number of correct Cognitive Performance Test (CPT) answers | Study 1: 6 items, 0-6; Studies 2-5: 5 items, 0-5 | 1, 2, 3, 4, 5 | 0 to 6 (10598) | *_correct |
| `crs5` | Cognitive reflection score on the five CPT items common to all studies (used in the meta-analysis) | 0-5; equals crs in Studies 2-5; Study 1 omits the base-rate item | 1, 2, 3, 4, 5 | 0 to 5 (10598) | *_correct |
| `fis` | Fluid intelligence score: number of correct answers on three Raven items (E6, E8, E9) | 0-3; Studies 2-5 | 2, 3, 4, 5 | 0 to 3 (8157) | raven_*_correct |
| `reflection` | Reflection score: crs + fis | 0-8; Studies 2-5; not preregistered | 2, 3, 4, 5 | 0 to 8 (8157) | crs, fis |
| `income_group` | Preregistered income group: median split of effective_income within the study | Low; High (participants exactly at the median are in the High group) | 1, 2, 3, 4, 5 | (10598) | effective_income |
| `effective_income` | Effective income: household income after tax (bracket midpoint) divided by the square root of household size | GBP (Studies 1-2) or USD (Studies 3-5); medians: 25,000; 25,000; 37,500; 45,000; 43,301.27 | 1, 2, 3, 4, 5 | 1581.14 to 150000 (10598) | income_midpoint, household_size |
| `income_bracket` | Annual household income after tax, bracket | 1 = less than 10,000; 2 = 10,000-19,999; 3 = 20,000-29,999; 4 = 30,000-39,999; 5 = 40,000-49,999; 6 = 50,000-59,999; 7 = 60,000-69,999; 8 = 70,000-79,999; 9 = 80,000-89,999; 10 = 90,000-99,999; 11 = 100,000-149,999; 12 = 150,000 or more (GBP in Studies 1-2, USD in Studies 3-5) | 1, 2, 3, 4, 5 | 1 to 12 (10598) | Household_income (Studies 1-4; text labels in Study 3), Income (Study 5) |
| `income_midpoint` | Bracket midpoint used for effective income | 5,000; 15,000; ...; 95,000; 125,000; 150,000 (open top bracket set to 150,000) | 1, 2, 3, 4, 5 | 5000 to 150000 (10598) | income_bracket |
| `household_size` | Number of people in the household | integer | 1, 2, 3, 4, 5 | 1 to 11 (10598) | Household_size, Household_size_s (Study 3), Household (Study 5) |
| `income_group_ties_low` | Alternative income split for the sensitivity analysis: participants at the median in the Low group | Low; High | 1, 2, 3, 4, 5 | (10598) | effective_income |
| `age` | Age in years | integer | 1, 2, 3, 4, 5 | 18 to 88 (10598) | Age, age |
| `gender` | Gender | 1 = woman; 2 = man; 3 = other | 1, 2, 3, 4, 5 | 1 to 3 (10598) | Gender, gender (text in Study 3: Female/Male/Other) |
| `education` | Highest education | 1 = some high school; 2 = graduated high school; 3 = some college (no degree); 4 = associate's degree or technical/vocational school; 5 = bachelor's degree; 6 = some graduate or professional school; 7 = graduate or professional degree. These are the US labels exported in Study 3; Studies 1, 2, 4, 5 exported numeric codes 1-7 and the UK wording of Studies 1-2 is in the survey materials | 1, 2, 3, 4, 5 | 1 to 7 (10598) | Education |
| `treatment_raw` | Condition label as exported from Qualtrics | see condition table | 1, 2, 3, 4, 5 | (10598) | Treatment |
| `fcs_1` | FCS item 1: I am satisfied with my present financial situation (reverse-scored) | 1 = strongly disagree ... 7 = strongly agree; Study 1 | 1 | 1 to 7 (2441) | FCS_1 |
| `fcs_2` | FCS item 2: My income is enough for me to meet my monthly living expenses (reverse-scored) | 1-7; Study 1 | 1 | 1 to 7 (2441) | FCS_2 |
| `fcs_3` | FCS item 3: I worry about how much money I owe | 1-7; Study 1 | 1 | 1 to 7 (2441) | FCS_3 |
| `fcs_4` | FCS item 4: I am satisfied with the amount of money that I am saving and investing for retirement (reverse-scored) | 1-7; Study 1 | 1 | 1 to 7 (2441) | FCS_4 |
| `fcs_5` | FCS item 5: I am financially unprepared for negative life-events such as severe sickness, serious injury or long-term unemployment | 1-7; Study 1 | 1 | 1 to 7 (2441) | FCS_5 |
| `crt1_response` | CPT item 1 (bat and ball), option chosen | 1 = correct; 2 = intuitive answer (inferred from response frequencies); 3-4 = other options; four-option format; Studies 1, 2, 4, 5 (Study 3: see crt1_response_text) | 1, 2, 4, 5 | 1 to 4 (9029) | Q1_CRT1, Q1CRT1 |
| `crt2_response` | CPT item 2 (widgets), option chosen | as crt1_response | 1, 2, 4, 5 | 1 to 4 (9029) | Q2_CRT2, Q2CRT2 |
| `crt3_response` | CPT item 3 (lily pads), option chosen | as crt1_response | 1, 2, 4, 5 | 1 to 4 (9029) | Q3_CRT3, Q3CRT3 |
| `belief_bias_response` | CPT item 4 (belief-bias syllogism), option chosen | 1 = incorrect (Yes); 2 = correct (No); Studies 1, 2, 4, 5 | 1, 2, 4, 5 | 1 to 2 (9029) | Q4_Belief_Bias, Q4BeliefBias |
| `base_rate_response` | CPT item 5 (base-rate neglect), option chosen | 1 = correct; 2 = incorrect; Study 1 only | 1 | 1 to 2 (2441) | Q5_Base_rate_neglect |
| `conjunction_response` | CPT item (conjunction fallacy), option chosen | 1 = correct (Claire is a bank teller); 2 = incorrect (bank teller and active in the feminist movement); Studies 1, 2, 4, 5 | 1, 2, 4, 5 | 1 to 2 (9029) | Q6_Conjunction_Fall (Study 1), Q5_Conjunction_Fall, Q5ConjunctionFall |
| `crt1_response_text` | CPT item 1, option text as exported (Study 3) | 5 pence (correct); 10 pence; 9 pence; 1 pence | 3 | (1569) | Q1_CRT1 |
| `crt2_response_text` | CPT item 2, option text as exported (Study 3) | 5 minutes (correct); 100 minutes; 20 minutes; 500 minutes | 3 | (1569) | Q2_CRT2 |
| `crt3_response_text` | CPT item 3, option text as exported (Study 3) | 47 days (correct); 24 days; 12 days; 36 days | 3 | (1569) | Q3_CRT3 |
| `belief_bias_response_text` | CPT item 4, option text as exported (Study 3) | No (correct); Yes | 3 | (1569) | Q4_Belief_Bias |
| `conjunction_response_text` | CPT conjunction item, option text as exported (Study 3) | Claire is a bank teller (correct); Claire is a bank teller and is active in the feminist movement | 3 | (1569) | Q5_Conjunction_Fall |
| `crt1_correct` | CPT item 1 correct | 1 = correct; 0 = incorrect | 1, 2, 3, 4, 5 | 0 to 1 (10598) | derived |
| `crt2_correct` | CPT item 2 correct | 1/0 | 1, 2, 3, 4, 5 | 0 to 1 (10598) | derived |
| `crt3_correct` | CPT item 3 correct | 1/0 | 1, 2, 3, 4, 5 | 0 to 1 (10598) | derived |
| `belief_bias_correct` | CPT belief-bias item correct | 1/0 | 1, 2, 3, 4, 5 | 0 to 1 (10598) | derived |
| `base_rate_correct` | CPT base-rate item correct | 1/0; Study 1 only | 1 | 0 to 1 (2441) | derived |
| `conjunction_correct` | CPT conjunction item correct | 1/0 | 1, 2, 3, 4, 5 | 0 to 1 (10598) | derived |
| `raven_e6_response` | Raven's Standard Progressive Matrices item E6, option chosen | 1-8; correct = 5; Studies 2-5 | 2, 3, 4, 5 | 1 to 8 (8157) | E6 |
| `raven_e8_response` | Raven item E8, option chosen | 1-8; correct = 6; Studies 2-5 | 2, 3, 4, 5 | 1 to 8 (8157) | E8 |
| `raven_e9_response` | Raven item E9, option chosen | 1-8; correct = 3; Studies 2-5 | 2, 3, 4, 5 | 1 to 8 (8157) | E9 |
| `raven_e6_correct` | Raven item E6 correct | 1/0 | 2, 3, 4, 5 | 0 to 1 (8157) | derived |
| `raven_e8_correct` | Raven item E8 correct | 1/0 | 2, 3, 4, 5 | 0 to 1 (8157) | derived |
| `raven_e9_correct` | Raven item E9 correct | 1/0 | 2, 3, 4, 5 | 0 to 1 (8157) | derived |
| `fcq_1` | FCQ item 1 (reverse-scored: describes financial security) | 1 = strongly disagree ... 7 = strongly agree; Studies 2, 4, 5; item wording in Lee & Zietsch (2011) | 2, 4, 5 | 1 to 7 (6588) | FCS_1 |
| `fcq_2` | FCQ item 2 (reverse-scored) | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_2 |
| `fcq_3` | FCQ item 3 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_3 |
| `fcq_4` | FCQ item 4 (reverse-scored) | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_4 |
| `fcq_5` | FCQ item 5 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_5 |
| `fcq_6` | FCQ item 6 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_6 |
| `fcq_7` | FCQ item 7 (reverse-scored) | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_7 |
| `fcq_8` | FCQ item 8 (reverse-scored) | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_8 |
| `fcq_9` | FCQ item 9 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_9 |
| `fcq_10` | FCQ item 10 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_10 |
| `fcq_11` | FCQ item 11 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_11 |
| `fcq_12` | FCQ item 12 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_12 |
| `fcq_13` | FCQ item 13 (reverse-scored) | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_13 |
| `fcq_14` | FCQ item 14 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_14 |
| `fcq_15` | FCQ item 15 | 1-7 | 2, 4, 5 | 1 to 7 (6588) | FCS_15 |
| `scs_1` | SCS item 1: My resources are scarce | 1 = strongly disagree ... 7 = strongly agree; Study 3 (text labels in the export recoded to 1-7) | 3 | 1 to 7 (1569) | SCS_1 |
| `scs_2` | SCS item 2: I don't have enough resources | 1-7; Study 3 | 3 | 1 to 7 (1569) | SCS_2 |
| `scs_3` | SCS item 3: I need to protect the resources I have | 1-7; Study 3 | 3 | 1 to 7 (1569) | SCS_3 |
| `scs_4` | SCS item 4: I need to acquire more resources | 1-7; Study 3 | 3 | 1 to 7 (1569) | SCS_4 |
| `uk_us_resident` | Resident of the study country (UK in Studies 1-2, US in Studies 3-5) | 1 = yes; 2 = no (Study 3 exported the 'yes' option with the label 'UK') | 1, 2, 3, 4, 5 | 1 to 2 (10598) | Residency |
| `measure_order` | Order of the manipulation check and the CPT (Study 1) | Concerns first; Cognitive test first | 1 | (2441) | Order_FCS_First |
| `scale_rating` | Scale task (Study 1): rating of the combined amount in checking and savings accounts | 1-11; wide steps of 50,000 in the high-scarcity version, 5,000 in the low-scarcity version | 1 | 1 to 11 (551) | Nelson_S2_Prime, Nelson_S2_Control |
| `lottery_check_max_correct` | Lottery task (Study 1): correct answer to the question about the highest possible bonus | 1 = correct; 0 = incorrect | 1 | 0 to 1 (549) | Bonus_M_AC_Q1, Bonus_C_AC_Q1 |
| `lottery_check_actual_correct` | Lottery task (Study 1): correct answer to the question about the bonus received | 1/0 | 1 | 0 to 1 (549) | Bonus_M_AC_Q2, Bonus_C_AC_Q2 |
| `panas_positive` | PANAS positive affect: sum of 10 items | 10-50; Studies 1-2 | 1, 2 | 10 to 50 (4639) | interested, excited, strong, enthusiastic, proud, alert, inspired, determined, attentive, active |
| `panas_negative` | PANAS negative affect: sum of 10 items | 10-50; Studies 1-2 | 1, 2 | 10 to 49 (4639) | distressed, upset, guilty, scared, hostile, irritable, ashamed, nervous, jittery, afraid |
| `finlit_score` | Financial literacy test: number of correct answers (five items) | 0-5; Studies 1, 2, 4 | 1, 2, 4 | 0 to 5 (6881) | FinLit_Test_1-5, F1-F5 |
| `finlit_self_rating` | Self-rated financial literacy (Study 1) | see range | 1 | 0 to 10 (2441) | Fin_lit_perception |
| `finlit_self_estimate` | Estimated number of correct financial literacy answers (Studies 2, 4) | 0-5 | 2, 4 | 0 to 5 (4440) | OC_Absolute |
| `finlit_relative_estimate` | Estimated financial literacy relative to other participants (Studies 2, 4) | 0-100 | 2, 4 | 0 to 100 (4440) | OC_Relative, OC_Relative_12 |
| `affect_arousal` | Affective Slider, arousal (Studies 3-5) | 0-100; the Study 3 export names the items; Studies 4-5 exported them as Q1_1 and Q2_1 and are assumed to be in the same order (confirm against the survey) | 3, 4, 5 | 0 to 100 (5959) | AQ1_Arousal, Q1_1 |
| `affect_pleasure` | Affective Slider, pleasure (Studies 3-5) | 0-100; see affect_arousal | 3, 4, 5 | 0 to 100 (5959) | AQ2_Pleasure, Q2_1 |
| `sleep_hours` | Hours of sleep the previous night (Studies 2-5) | see range | 2, 3, 4, 5 | 1 to 11 (8143) | Sleep |
| `hours_since_meal` | Hours since the last meal (Studies 2-5) | 1-10; 11 = more than 10 | 2, 3, 4, 5 | 1 to 11 (8157) | Hunger |
| `covid_diagnosed` | Ever diagnosed with COVID-19 (Studies 2-5) | 1 = yes; 2 = no | 2, 3, 4, 5 | 1 to 2 (8157) | Self_Diagnosis, SelfDiagnosis |
| `covid_risk_1` | Perceived COVID-19 infection risk, item 1 (Studies 2-5) | 0-100 in steps of 10; wording in the survey materials | 2, 3, 4, 5 | 0 to 100 (8157) | Risk_perception_1, Riskperception_1 |
| `covid_risk_2` | Perceived COVID-19 infection risk, item 2 (Studies 2-5) | 0-100 in steps of 10 | 2, 3, 4, 5 | 0 to 100 (8157) | Risk_perception_2, Riskperception_2 |
| `ideology` | Political ideology (Studies 2, 4, 5) | see range; wording in the survey materials | 2, 4, 5 | 0 to 10 (6588) | Ideology |
| `religiosity` | Religiosity (Studies 2, 4, 5) | see range | 2, 4, 5 | 0 to 10 (6588) | Religiosity |
| `sample_pool` | Recruitment pool (Study 5) | Screened income pools; Full income range | 5 | (2148) | PART |
| `duration_seconds` | Time to complete the survey, seconds | integer | 1, 2, 3, 4, 5 | 97 to 9190 (10598) | Duration, Duration_in_seconds, Durationinseconds |
| `finished` | Reached the final survey screen (Studies 4-5) | 1 = yes; 0 = stopped before the final screen but completed all measures (kept, as described in the paper) | 4, 5 | 0 to 1 (4390) | Finished |
| `prolific_age` | Age recorded in the participant's Prolific profile | years; Studies 2-5 (Study 1 has no Prolific export) | 2, 3, 4, 5 | 0 to 88 (8119) | KB (Study 2), @GE (Study 3), KH (Study 4), Age_A or Fluentlanguages (Study 5, depending on the export layout) |
| `prolific_sex` | Sex recorded in the Prolific profile | Female; Male; Prefer not to say; Studies 2-5 | 2, 3, 4, 5 | (8118) | Sex |
| `prolific_gender_identity` | Gender identity recorded in the Prolific profile | text as exported; Studies 2-5 | 2, 3, 4, 5 | (8121) | Gender_identity, Genderidentity |
| `prolific_ethnicity` | Ethnicity (simplified) recorded in the Prolific profile | White; Black; Asian; Mixed; Other; Study 5 only | 5 | (2138) | Ethnicitysimplified |
| `prolific_country_of_birth` | Country of birth recorded in the Prolific profile | country name; Studies 2-5 | 2, 3, 4, 5 | (7973) | Country_of_Birth, Countryofbirth |
| `prolific_country_of_residence` | Country of residence recorded in the Prolific profile | country name; Studies 2-5 | 2, 3, 4, 5 | (8068) | Current_Country_of_Residence, Countryofresidence |
| `prolific_nationality` | Nationality recorded in the Prolific profile | country name; Studies 2-5 | 2, 3, 4, 5 | (8108) | Nationality |
| `prolific_first_language` | First language recorded in the Prolific profile | language name; Studies 2, 4, 5 (expired for every Study 3 participant) | 2, 4, 5 | (5590) | First_Language, Language |
| `prolific_fluent_languages` | Fluent languages recorded in the Prolific profile | comma-separated language names; Studies 2-5 | 2, 3, 4, 5 | (8118) | Fluent_languages, Fluentlanguages |
| `prolific_employment_status` | Employment status recorded in the Prolific profile | Full-Time; Part-Time; Unemployed (and job seeking); Not in paid work (e.g. homemaker, retired or disabled); Due to start a new job within the next month; Other; Studies 2-5 | 2, 3, 4, 5 | (7347) | Employment_Status, Employmentstatus |
| `prolific_student_status` | Student status recorded in the Prolific profile | Yes; No; Studies 2-5 | 2, 3, 4, 5 | (7446) | Student_Status, Studentstatus |
| `prolific_household_income` | Household income bracket from Prolific's screening survey, the basis of the income screening at recruitment | GBP brackets (Study 2) or USD brackets (Studies 4-5); Study 3 did not screen on income | 2, 4, 5 | (6533) | Household_Income_GBP, Household_Income_USD_US_parti, Householdincomeusdusparti |

## Conditions by study

| Study | Condition | Technique | Scarcity | Export label | n |
|---|---|---|---|---|---|
| 1 | Consequences high | Consequences | High | Manipulation_Prime | 268 |
| 1 | Consequences low | Consequences | Low | Control_Prime | 265 |
| 1 | Lottery high | Lottery | High | Manipulation_Lottery | 271 |
| 1 | Lottery low | Lottery | Low | Control_Lottery | 278 |
| 1 | Passive control | Control | Control | Control_Passive | 277 |
| 1 | Recall high | Recall | High | Manipulation_Recall | 255 |
| 1 | Recall low | Recall | Low | Control_Recall | 276 |
| 1 | Scale high | Scale | High | Manipulation_Frame | 277 |
| 1 | Scale low | Scale | Low | Control_Frame | 274 |
| 2 | COVID-19 pictures high | COVID-19 pictures | High | Picture_Covid | 296 |
| 2 | Generic pictures high | Generic pictures | High | Picture_High | 289 |
| 2 | Passive control | Control | Control | Control | 296 |
| 2 | Pictures low | Pictures | Low | Picture_Low | 301 |
| 2 | Recall high | Recall | High | Recall_High | 213 |
| 2 | Recall low | Recall | Low | Recall_Low | 246 |
| 2 | Scenario high | Scenario | High | Imagine_High | 275 |
| 2 | Scenario low | Scenario | Low | Imagine_Low | 282 |
| 3 | COVID-19 pictures high | COVID-19 pictures | High | Picture_Covid | 528 |
| 3 | Generic pictures high | Generic pictures | High | Picture_High | 519 |
| 3 | Pictures low | Pictures | Low | Picture_Low | 522 |
| 4 | COVID-19 pictures high | COVID-19 pictures | High | Picture_Covid | 295 |
| 4 | Generic pictures high | Generic pictures | High | Picture_High | 299 |
| 4 | Passive control | Control | Control | Control | 311 |
| 4 | Pictures low | Pictures | Low | Picture_Low | 290 |
| 4 | Recall high | Recall | High | Recall_High | 221 |
| 4 | Recall low | Recall | Low | Recall_Low | 250 |
| 4 | Scenario high | Scenario | High | Imagine_High | 279 |
| 4 | Scenario low | Scenario | Low | Imagine_Low | 297 |
| 5 | COVID-19 pictures high | COVID-19 pictures | High | Picture_High_A | 260 |
| 5 | COVID-19 pictures low | COVID-19 pictures | Low | Picture_Low_A | 254 |
| 5 | Passive control | Control | Control | Control | 263 |
| 5 | Picture imagination high | Picture imagination | High | Picture_High_B | 247 |
| 5 | Picture imagination low | Picture imagination | Low | Picture_Low_B | 254 |
| 5 | Recall high | Recall | High | Recall_High | 167 |
| 5 | Recall low | Recall | Low | Recall_Low | 205 |
| 5 | Scenario high | Scenario | High | Imagine_High | 247 |
| 5 | Scenario low | Scenario | Low | Imagine_Low | 251 |

The 18 preregistered comparisons pair each high-scarcity condition with the low-scarcity version of the same technique. In Studies 2 to 4 the generic and the COVID-19 picture conditions share the low-scarcity picture condition (`Pictures low`). In Study 5 the COVID-19 pictures and the picture-imagination task each have their own low-scarcity condition.

## Scoring keys

- **Scarcity concerns.** Study 1 (FCS): items 1, 2 and 4 reverse-scored (8 - response), then summed (5-35). Studies 2, 4, 5 (FCQ): items 1, 2, 4, 7, 8 and 13 reverse-scored, then summed (15-105). Study 3 (SCS): four items summed (4-28).
- **Cognitive reflection (CPT).** Correct options: CRT items 1-3 = option 1 (Study 3: '5 pence', '5 minutes', '47 days'); belief-bias syllogism = option 2 ('No'); base-rate problem (Study 1 only) = option 1; conjunction problem = option 1 ('Claire is a bank teller'). `crs` counts all items of the study; `crs5` counts the five items common to all studies.
- **Fluid intelligence.** Raven items E6, E8, E9: correct options 5, 6, 3. `fis` = number correct (0-3). `reflection` = `crs` + `fis`.
- **Financial literacy (Studies 1, 2, 4).** Correct options for the five items: 2, 3, 1, 4, 3.
- **Effective income.** Bracket midpoint (see `income_bracket`) divided by the square root of household size; median split within study, ties to the high-income group (`income_group`); `income_group_ties_low` assigns ties to the low-income group for the sensitivity analysis.

## Notes and open points for the authors

- The exported Prolific IDs do not overlap between studies, although the paper identifies 259 (Study 4) and 81 (Study 5) repeat participants; the IDs in the exports appear to have been pseudonymised per study. The data therefore carry no repeat-participant flag, and the paper's analyses without repeat participants are not part of this package.
- Study 3 was exported with option texts instead of numeric codes (CPT, SCS, gender, education, income, residency, hunger); the codes above were assigned from the texts. Its residency question exported the label 'UK' for the 'yes' option.
- The order of the two Affective Slider items in Studies 4 and 5 (exported as `Q1_1`, `Q2_1`) is assumed to match Study 3 (arousal, pleasure).
- Option texts for CPT options 3 and 4 in Studies 1, 2, 4 and 5 and the UK wording of the education and income questions are not in the exports; see the survey materials on OSF.
- The Study 5 export has an empty `ID` column; `id` is the row number.
- The Prolific block of the Study 5 export mixes two export formats: for the screened pools (September 2022) every field sits under its own header, whereas for the full-income-range pool (November 2022) the export had no 'Total rejections' and 'Approval rate' fields and every demographic value sits two columns to the left of its header. The preparation scripts detect the format from the 'Approval rate' column and read each field from the right column; four Study 5 participants have no Prolific record in the export.